-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 30, 2020 at 10:42 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `first_laravel_ecomerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `adds`
--

CREATE TABLE `adds` (
  `adds_id` int(11) NOT NULL,
  `adds_title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `adds_link` varchar(555) CHARACTER SET utf8 DEFAULT '#',
  `media_path` varchar(500) NOT NULL,
  `adds_type` varchar(7) DEFAULT 'sidebar',
  `created_time` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adds`
--

INSERT INTO `adds` (`adds_id`, `adds_title`, `adds_link`, `media_path`, `adds_type`, `created_time`) VALUES
(1, 'tt', 'ttt', 'uploads/30-50-05-19-11-2019-2.jpg', 'home', ''),
(2, 'watch collection', 'http://demo.aynabd.net/category/watch', 'uploads/17-50-05-19-11-2019-3.jpg', 'home', 'watch collection'),
(3, 'Baby Products', 'http://demo.aynabd.net/category/helth-care', 'uploads/44-50-05-19-11-2019-1.jpg', 'home', 'Baby Products'),
(4, 'sidebar add', '#', 'uploads/05-51-05-11-11-2019-17-09-2019-offer_banner_21.png', 'sidebar', ''),
(5, 'sidebar two', '#', 'uploads/25-51-05-11-11-2019-17-09-2019-offer_banner_21.png', 'sidebar', ''),
(6, 'sidebar tree', 'd', 'uploads/42-51-05-11-11-2019-17-09-2019-offer_banner_21.png', 'sidebar', '');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `status` varchar(50) NOT NULL,
  `picture` varchar(250) DEFAULT NULL,
  `registered_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `email`, `password`, `status`, `picture`, `registered_date`) VALUES
(2, 'milobn', 'suzonicdde15@gmail.com', '3d5e4a8842e2017424e2fb1919385006admin', 'super-admin', '1589194547.jpg', '0000-00-00'),
(3, 'hhhhh', 'suzonice105@gmail.com', 'c1181aacf646b97f0a0a782db351a405admin', 'super-admin', '1589196251.jpg', '0000-00-00'),
(6, 'suzonice15@gmail.com', 'suzonice15@gmail.com', 'e613512a5b50cbf793bae4a75117dd30admin', 'office-staff', '1589196549.jpg', '0000-00-00'),
(7, 'kajol', 'kajol@gmail.com', '5c507e9e2570cde33febf07d8440d181admin', 'super-admin', '1589213562.PNG', '0000-00-00'),
(8, 'suzond', 'ssssssss@ggg.jjj', 'ba248c985ace94863880921d8900c53fadmin', 'office-staff', '1589229669.jpg', '2020-05-11'),
(9, 'ss', 'sss@fff.hhh', 'd41d8cd98f00b204e9800998ecf8427eadmin', 'office-staff', '1589952313.jpg', '2020-05-20');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `media_id` int(11) DEFAULT NULL,
  `medium_banner` int(11) DEFAULT NULL,
  `category_title` varchar(155) CHARACTER SET utf8 NOT NULL,
  `category_name` varchar(155) CHARACTER SET utf8 NOT NULL,
  `parent_id` int(11) DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `rank_order` int(11) DEFAULT '0',
  `seo_title` text CHARACTER SET utf8,
  `seo_meta_title` text CHARACTER SET utf8,
  `seo_keywords` text CHARACTER SET utf8,
  `seo_content` text CHARACTER SET utf8,
  `seo_meta_content` text CHARACTER SET utf8,
  `registered_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `media_id`, `medium_banner`, `category_title`, `category_name`, `parent_id`, `status`, `rank_order`, `seo_title`, `seo_meta_title`, `seo_keywords`, `seo_content`, `seo_meta_content`, `registered_date`) VALUES
(58, 6572, 2452, 'All Product', 'all-product', 0, 1, 15, 'All Product', 'All Products', 'All Products', 'All Products', 'All Products', '2020-06-28 00:00:00'),
(63, NULL, NULL, 'electronics1a', 'electronics1a', 61, 1, 0, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00'),
(65, 6558, 2294, 'Electronic & security ', 'electronic-security', 0, 1, 12, 'Electronic & security ', 'Electronic & security ', 'Electronic & security ', 'Electronic & security ', 'Electronic & security ', '0000-00-00 00:00:00'),
(66, 520, 351, 'Saver & Trimmer ', 'saver-trimmer', 66, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(67, 6561, 1951, 'Watch Collection ', 'watch-collection', 0, 1, 10, 'Watch Collection ', 'Watch Collection ', 'Watch Collection ', 'Watch Collection ', 'Watch Collection ', '0000-00-00 00:00:00'),
(68, 6560, 2330, 'Saver & Trimmer', 'saver-trimmer', 0, 1, 6, 'Saver & Trimmer', 'Saver & Trimmer', 'Saver & Trimmer', 'Saver & Trimmer', 'Saver & Trimmer', '0000-00-00 00:00:00'),
(70, 6562, 2331, 'Shoe Fashions', 'shoe-fashions', 0, 1, 6, 'Shoe Fashions', 'Shoe Fashions', 'Shoe Fashions', 'Shoe Fashions', 'Shoe Fashions', '0000-00-00 00:00:00'),
(71, 524, 349, 'Three Pieces ', 'three-pieces', 71, 1, 2, '', '', '', '', '', '0000-00-00 00:00:00'),
(72, 524, 384, 'Fitness & Sports', 'fitness-sports', 133, 1, 0, 'Fitness & Sports', 'Fitness & Sports', 'Fitness & Sports', 'Fitness & Sports', 'Fitness & Sports', '0000-00-00 00:00:00'),
(73, 6563, 505, 'Home & living', 'home-living', 0, 1, 0, 'Home and living', 'Home and living', 'Home and living', 'Home and living', 'Home and living', '0000-00-00 00:00:00'),
(75, 500, 501, 'All Products ', 'all-products', 75, 1, 12, '', '', '', '', '', '0000-00-00 00:00:00'),
(77, NULL, NULL, 'Bed Cover ', 'bed-cover', 71, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(78, NULL, NULL, 'Nighty For Women ', 'nighty-for-women', 71, 1, 1, '', '', '', '', '', '0000-00-00 00:00:00'),
(79, 6564, 2462, 'Clothing Items', 'clothing-items', 0, 1, 13, 'Clothing Items', 'Clothing Items', 'Clothing Items', 'Clothing Items', 'Clothing Items', '0000-00-00 00:00:00'),
(80, NULL, NULL, 'three pices', 'three-pices', 79, 1, 5, '', '', '', '', '', '0000-00-00 00:00:00'),
(81, NULL, NULL, 'Bed Cover ', 'bed-cover', 73, 1, 0, 'Bed Cover ', 'Bed Cover ', 'Bed Cover ', 'Bed Cover ', 'Bed Cover ', '0000-00-00 00:00:00'),
(83, NULL, NULL, 'Bed Cover ', 'bed-cover', 79, 1, 1, '', '', '', '', '', '0000-00-00 00:00:00'),
(84, NULL, NULL, 'Night wear', 'night-wear', 79, 1, 2, '', '', '', '', '', '0000-00-00 00:00:00'),
(85, NULL, NULL, 'Sharee Fashion ', 'sharee-fashion', 79, 1, 3, '', '', '', '', '', '0000-00-00 00:00:00'),
(86, NULL, NULL, 'Men\'s Saver', 'men-s-saver', 66, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(87, NULL, NULL, 'Women\'s Shaver & Trimmer ', 'women-s-shaver-trimmer', 66, 1, 1, '', '', '', '', '', '0000-00-00 00:00:00'),
(88, NULL, NULL, 'Men\'s Shaver & Trimmer ', 'men-s-shaver-trimmer', 68, 1, 1, '', '', '', '', '', '0000-00-00 00:00:00'),
(89, NULL, NULL, 'Women\'s Shaver & Trimmer ', 'women-s-shaver-trimmer', 68, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(90, NULL, NULL, 'Wifi IP Camera ', 'wifi-ip-camera', 65, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(91, NULL, NULL, 'Mobile Accessories ', 'mobile-accessories', 65, 1, 1, '', '', '', '', '', '0000-00-00 00:00:00'),
(92, NULL, NULL, 'CC TV Camera ', 'cc-tv-camera', 65, 1, 2, '', '', '', '', '', '0000-00-00 00:00:00'),
(93, NULL, NULL, 'Disk Phone ', 'disk-phone', 65, 1, 3, '', '', '', '', '', '0000-00-00 00:00:00'),
(94, NULL, NULL, 'Mobile Phone ', 'mobile-phone', 65, 1, 4, '', '', '', '', '', '0000-00-00 00:00:00'),
(95, NULL, NULL, 'Mobile Headphone ', 'mobile-headphone', 91, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(96, NULL, NULL, 'Mobile Cover ', 'mobile-cover', 91, 1, 1, '', '', '', '', '', '0000-00-00 00:00:00'),
(97, NULL, NULL, 'Computer Accessories ', 'computer-accessories', 65, 1, 5, '', '', '', '', '', '0000-00-00 00:00:00'),
(99, NULL, NULL, 'Slicer & Cutter ', 'slicer-cutter', 137, 1, 0, 'Slicer & Cutter ', 'Slicer & Cutter ', 'Slicer & Cutter ', 'Slicer & Cutter ', 'Slicer & Cutter ', '0000-00-00 00:00:00'),
(100, NULL, NULL, 'Rice Cooker ', 'rice-cooker', 137, 1, 1, 'Rice Cooker ', 'Rice Cooker ', 'Rice Cooker ', 'Rice Cooker ', 'Rice Cooker ', '0000-00-00 00:00:00'),
(101, NULL, NULL, 'Juicer & Blender ', 'juicer-blender', 137, 1, 2, 'Juicer & Blender ', 'Juicer & Blender ', 'Juicer & Blender ', 'Juicer & Blender ', 'Juicer & Blender ', '0000-00-00 00:00:00'),
(102, NULL, NULL, 'Fan & Cooler ', 'fan-cooler', 65, 1, 6, '', '', '', '', '', '0000-00-00 00:00:00'),
(103, NULL, NULL, 'Sound Box , Speaker & Microphone ', 'sound-box-speaker-microphone', 65, 1, 7, '', '', '', '', '', '0000-00-00 00:00:00'),
(104, NULL, NULL, 'kitchen Shelf ', 'kitchen-shelf', 137, 1, 3, 'kitchen Shelf ', 'kitchen Shelf ', 'kitchen Shelf ', 'kitchen Shelf ', 'kitchen Shelf ', '0000-00-00 00:00:00'),
(105, 6681, 6678, 'Smart Watch ', 'smart-watch', 67, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(106, 6682, 6679, 'Men\'s Watch ', 'men-s-watch', 67, 1, 1, '', '', '', '', '', '0000-00-00 00:00:00'),
(107, 6683, 6680, 'Women\'s Watch ', 'women-s-watch', 67, 1, 2, '', '', '', '', '', '0000-00-00 00:00:00'),
(108, NULL, NULL, 'Laptop ', 'laptop', 65, 1, 8, '', '', '', '', '', '0000-00-00 00:00:00'),
(109, 6573, 2454, 'Women Fashion', 'women-fashion', 0, 1, 5, 'Women Fashion', 'Women Fashion', 'Women Fashion', 'Women Fashion', 'Women Fashion', '0000-00-00 00:00:00'),
(110, 6565, 2453, 'Winter collection', 'winter-collection', 0, 1, 11, 'winter collection', 'winter collection', 'winter collection', 'winter collection', 'winter collection', '0000-00-00 00:00:00'),
(112, NULL, NULL, 'Room heater', 'room-heater', 110, 1, 20, 'Room heater', 'Room heater', 'Room heater', 'Room heater', 'Room heater', '0000-00-00 00:00:00'),
(113, NULL, NULL, 'Hot water tap', 'hot-water-tap', 110, 1, 19, 'Hot water tap', 'Hot water tap', 'Hot water tap', 'Hot water  tap', 'Hot water  tap', '0000-00-00 00:00:00'),
(114, NULL, NULL, 'Hot water  bag', 'hot-water-bag', 110, 1, 2, 'Hot water bag', 'Hot water bag', 'Hot water bag', 'Hot water bag', 'Hot water bag', '0000-00-00 00:00:00'),
(115, NULL, NULL, 'Gents hoodie', 'gents-hoodie', 110, 1, 4, 'gents hoodies', 'gents hoodies', 'gents hoodies', 'gents hoodies', 'gents hoodies', '0000-00-00 00:00:00'),
(116, NULL, NULL, 'Women hoodies', 'women-hoodies', 110, 1, 5, 'Womans hoodies', 'Womans hoodies', 'Womans hoodies', 'Womans hoodies', 'Womans hoodies', '0000-00-00 00:00:00'),
(117, NULL, NULL, 'Kids hoodie', 'kids-hoodie', 110, 1, 5, 'Kids hoodies', 'Kids hoodies', 'Kids hoodies', 'Kids hoodies', 'Kids hoodies', '0000-00-00 00:00:00'),
(118, NULL, NULL, 'Jacket', 'jacket', 110, 1, 18, 'jacket', 'jacket', 'jacket', 'jacket', 'jacket', '0000-00-00 00:00:00'),
(119, NULL, NULL, 'mens', 'mens', 118, 1, 1, 'jaket for mens', 'jaket for mens', 'jaket for mens', 'jaket for mens', 'jaket for mens', '0000-00-00 00:00:00'),
(120, NULL, NULL, 'womens', 'womens', 118, 1, 2, 'jaket for womens', 'jaket for womens', 'jaket for womens', 'jaket for womens', 'jaket for womens', '0000-00-00 00:00:00'),
(121, NULL, NULL, 'leather', 'leather', 118, 1, 3, 'leather', 'leather', 'leather', 'leather', 'leather', '0000-00-00 00:00:00'),
(122, NULL, NULL, 'Denim', 'Denim', 118, 1, 4, 'Denim', 'Denim', 'Denim', 'Denim', 'Denim', '0000-00-00 00:00:00'),
(123, NULL, NULL, 'gents sweater', 'gents-sweater', 110, 1, 10, 'gents sweater', 'gents sweater', 'gents sweater', 'gents sweater', 'gents sweater', '0000-00-00 00:00:00'),
(124, NULL, NULL, 'ladies sweater', 'ladies-sweater', 110, 1, 11, 'ladies sweater', 'ladies sweater', 'ladies sweater', 'ladies sweater', 'ladies sweater', '0000-00-00 00:00:00'),
(125, NULL, NULL, 'Saal/chador', 'saal-chador', 110, 1, 12, 'saal-chador', 'saal-chador', 'saal-chador', 'saal-chador', 'saal-chador', '0000-00-00 00:00:00'),
(126, NULL, NULL, 'Maflar & glavs', 'maflar-glavs', 110, 1, 13, 'Maflar & glavs', 'Maflar & glavs', 'Maflar & glavs', 'Maflar & glavs', 'Maflar & glavs', '0000-00-00 00:00:00'),
(127, NULL, NULL, 'Winter Cap', 'winter-cap', 110, 1, 14, 'Winter Cap', 'Winter Cap', 'Winter Cap', 'Winter Cap', 'Winter Cap', '0000-00-00 00:00:00'),
(128, NULL, NULL, 'Womens Shrug', 'womens-shrug', 110, 1, 15, 'Womens Shrug', 'Womens Shrug', 'Womens Shrug', 'Womens Shrug', 'Womens Shrug', '0000-00-00 00:00:00'),
(129, NULL, NULL, 'Winter Jogging Suit/ Trousers', 'winter-jogging-suit-trousers', 110, 1, 16, 'Winter Jogging Suit/ Trousers', 'Winter Jogging Suit/ Trousers', 'Winter Jogging Suit/ Trousers', 'Winter Jogging Suit/ Trousers', 'Winter Jogging Suit/ Trousers', '0000-00-00 00:00:00'),
(130, NULL, NULL, ' Winter Cosmetics', 'winter-cosmetics', 110, 1, 16, ' Winter Cosmetics', ' Winter Cosmetics', ' Winter Cosmetics', '\r\nWinter Cosmetics', '\r\nWinter Cosmetics', '0000-00-00 00:00:00'),
(131, NULL, NULL, 'Blazer', 'blazer', 110, 1, 17, 'Blazer', 'Blazer', 'Blazer', 'Blazer', 'Blazer', '0000-00-00 00:00:00'),
(132, 6566, 2011, 'Baby & toy Zone', 'baby-toy-zone', 0, 1, 4, 'Baby & toy Zone', 'Baby & toy Zone', 'Baby & toy Zone', 'Baby & toy Zone', 'Baby & toy Zone', '0000-00-00 00:00:00'),
(133, 6567, 2092, 'health-care', 'health-care', 0, 1, 3, 'HEALTH CARE', 'HEALTH CARE', 'HEALTH CARE', 'HEALTH CARE', 'HEALTH CARE', '0000-00-00 00:00:00'),
(134, NULL, NULL, 'microphone', 'microphone', 65, 1, 19, 'microphone', 'microphone', 'microphone', 'microphone', 'microphone', '0000-00-00 00:00:00'),
(135, 6568, 2377, 'Bag & bagese ', 'bag-bagese', 0, 1, 6, 'bag and bagese', 'bag and bagese', 'bag and bagese', 'bag and bagese', 'bag and bagese', '0000-00-00 00:00:00'),
(136, NULL, NULL, 'Sofa set', 'sofa-set', 73, 1, 3, 'Sofa set', 'Sofa set', 'Sofa set', 'air bed Sofa set', '', '0000-00-00 00:00:00'),
(137, 6569, 2463, ' Kitchen & Dining ', 'kitchen-dining', 0, 1, 14, ' Kitchen & Dining ', ' Kitchen & Dining ', ' Kitchen & Dining ', ' Kitchen  & Dining ', ' Kitchen  & Dining   goods hear', '0000-00-00 00:00:00'),
(138, NULL, NULL, 'T-shirt', 't-shirt', 79, 1, 4, 't shirt', 't shirt', 't shirt', 't shirt', 't shirt', '0000-00-00 00:00:00'),
(139, NULL, NULL, 'Mens shoes', 'mens-shoes', 70, 1, 5, 'mens Shoes', 'mens Shoes', 'mens Shoes', 'mens Shoes', 'mens Shoes in Dhaka', '0000-00-00 00:00:00'),
(140, NULL, NULL, 'Women Shoes', 'women-shoes', 70, 1, 4, 'Women Shoes', 'Women Shoes', 'Women Shoes', 'Women Shoes', 'Women Shoes', '0000-00-00 00:00:00'),
(141, NULL, NULL, 'Sandal & siliper', 'sandal-siliper', 70, 1, 3, 'Shoe fashions', 'Shoe fashions', 'Shoe fashions', 'Shoe fashions', 'Shoe fashions', '0000-00-00 00:00:00'),
(142, NULL, NULL, ' Casual Shoes', 'casual-shoes', 70, 1, 3, ' Casual Shoes', ' Casual Shoes', ' Casual Shoes', '\r\nCasual Shoes', '\r\nCasual Shoes', '0000-00-00 00:00:00'),
(143, NULL, NULL, 'Formal Shoes', 'formal-shoes', 70, 1, 2, 'Formal Shoes', 'Formal Shoes', 'Formal Shoes', 'Formal Shoes', 'Formal Shoes', '0000-00-00 00:00:00'),
(144, NULL, NULL, 'Loofer', 'loofer', 70, 1, 1, 'loofer', 'loofer', 'loofer', 'loofer', '', '0000-00-00 00:00:00'),
(145, NULL, NULL, 'Mens bagpack', 'mens-bagpack', 135, 1, 5, 'Mens bagpack', 'Mens bagpack', 'Mens bagpack', 'Mens bagpack', 'Mens bagpack', '0000-00-00 00:00:00'),
(146, NULL, NULL, 'Womens bagpack', 'womens-bagpack', 135, 1, 4, 'Mens bagpack', 'Mens bagpack', 'Mens bagpack', 'Mens bagpack', 'Mens bagpack', '0000-00-00 00:00:00'),
(147, NULL, NULL, 'Casual Bagpack', 'casual-bagpack', 135, 1, 3, 'Casual Bagpack', 'Casual Bagpack', 'Casual Bagpack', 'Casual Bagpack', 'Casual Bagpack', '0000-00-00 00:00:00'),
(148, NULL, NULL, ' Office Bagpack', 'office-bagpack', 135, 1, 3, ' Office Bagpack', ' Office Bagpack', ' Office Bagpack', '\r\nOffice Bagpack', '\r\nOffice Bagpack', '0000-00-00 00:00:00'),
(149, NULL, NULL, 'Laptop Bags', 'laptop-bags', 135, 1, 2, 'Laptop Bags', 'Laptop Bags', 'Laptop Bags', 'Laptop Bags', 'Laptop Bags', '0000-00-00 00:00:00'),
(150, NULL, NULL, 'Baby Bouncer', 'baby-bouncer', 132, 1, 6, 'Baby Bouncer', 'Baby Bouncer', 'Baby Bouncer', 'Baby Bouncer', 'Baby Bouncer', '0000-00-00 00:00:00'),
(151, NULL, NULL, 'Baby Carrier', 'baby-carrier', 132, 1, 5, 'Baby Carrier', 'Baby Carrier', 'Baby Carrier', 'Baby Carrier', 'Baby Carrier', '0000-00-00 00:00:00'),
(152, NULL, NULL, 'Kid\'s Learning', 'kid-s-learning', 132, 1, 4, 'Kid\'s Learning', 'Kid\'s Learning', 'Kid\'s Learning', 'Kid\'s Learning', 'Kid\'s Learning', '0000-00-00 00:00:00'),
(153, NULL, NULL, 'Kid\'s Toy', 'kid-s-toy', 132, 1, 3, 'Kid\'s Toy', 'Kid\'s Toy', 'Kid\'s Toy', 'Kid\'s Toy', 'Kid\'s Toy', '0000-00-00 00:00:00'),
(154, NULL, NULL, 'Kid\'s Dresses', 'kid-s-dresses', 132, 1, 2, 'Kid\'s Dresses', 'Kid\'s Dresses', 'Kid\'s Dresses', 'Kid\'s Dresses', 'Kid\'s Dresses', '0000-00-00 00:00:00'),
(155, NULL, NULL, 'Kid\'s Accessories', 'kid-s-accessories', 132, 1, 1, 'Kid\'s Accessories', 'Kid\'s Accessories', 'Kid\'s Accessories', 'Kid\'s Accessories', 'Kid\'s Accessories', '0000-00-00 00:00:00'),
(156, NULL, NULL, 'Skin care', 'skin-care', 133, 1, 5, 'Skin care', 'Skin care', 'Skin care', 'Skin care', 'Skin care', '0000-00-00 00:00:00'),
(157, NULL, NULL, 'Hair care', 'hair-care', 133, 1, 4, 'Hair care', 'Hair care', 'Hair care', 'Hair care', 'Hair care', '0000-00-00 00:00:00'),
(158, NULL, NULL, 'Beauty', 'beauty', 133, 1, 3, 'Hair care', 'Hair care', 'Hair care', 'Hair care', 'Hair care', '0000-00-00 00:00:00'),
(159, 6570, 2270, 'Mens Fashion', 'mens-fashion', 0, 1, 5, 'mens Fashion', 'mens Fashion', 'mens Fashion', 'mens Fashion', 'mens Fashion', '0000-00-00 00:00:00'),
(160, NULL, NULL, 'Sahree', 'sahree', 109, 1, 5, 'Sahree', 'Sahree', 'Sahree', 'Sahree', 'Sahree', '0000-00-00 00:00:00'),
(161, NULL, NULL, 'three pices', 'three-pices', 109, 1, 4, 'three pices', 'three pices', 'three pices', 'three pices', 'three pices', '0000-00-00 00:00:00'),
(162, NULL, NULL, 'Shirt', 'shirt', 159, 1, 5, 'shirt', 'shirt', 'shirt', 'shirt', 'shirt', '0000-00-00 00:00:00'),
(163, NULL, NULL, 'T-shirt', 't-shirt', 159, 1, 4, 't shirt', 't shirt', 't shirt', 't shirt', 't shirt', '0000-00-00 00:00:00'),
(164, NULL, NULL, 'Shoe', 'shoe', 159, 1, 3, 'Mens shoes', 'Mens shoes', 'Mens shoes', 'Mens shoes', 'Mens shoes', '0000-00-00 00:00:00'),
(165, NULL, NULL, 'pant', 'pant', 159, 1, 2, 'pant ', 'pant ', 'pant ', 'pant ', 'pant ', '0000-00-00 00:00:00'),
(166, NULL, NULL, 'panjabi', 'panjabi', 159, 1, 1, 'panjabi ', 'panjabi ', 'panjabi ', 'panjabi ', 'panjabi ', '0000-00-00 00:00:00'),
(167, NULL, NULL, 'Stylish Borka', 'stylish-borka', 79, 1, 2, 'Stylish borka', 'Stylish borka', 'Stylish borka', 'Stylish borka', 'Stylish borka', '0000-00-00 00:00:00'),
(168, NULL, NULL, 'Stylish Borka', 'stylish-borka', 109, 1, 2, 'Stylish borka', 'stylish borka', 'Stylish borka', 'Stylish borka', 'Stylish borka', '0000-00-00 00:00:00'),
(171, NULL, NULL, 'Fitness', 'fitness', 133, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(172, NULL, NULL, 'Cleaning', 'cleaning', 73, 1, 3, '', '', '', '', '', '0000-00-00 00:00:00'),
(173, NULL, NULL, 'Jewellery', 'jewellery', 109, 1, 4, '', '', '', '', '', '0000-00-00 00:00:00'),
(174, NULL, NULL, 'Kitchen  Accessories', 'kitchen-accessories', 137, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(175, 6684, NULL, 'latest watch ', 'latest-watch', 67, 1, 5, '', '', '', '', '', '0000-00-00 00:00:00'),
(176, NULL, NULL, 'Power Bank ', 'power-bank', 65, 1, 11, '', '', '', '', '', '0000-00-00 00:00:00'),
(179, 6685, NULL, 'Curren Watch ', 'curren-watch', 67, 1, 4, '', '', '', '', '', '0000-00-00 00:00:00'),
(180, NULL, NULL, 'Water Heater Pot ', 'water-heater-pot', 137, 1, 5, '', '', '', '', '', '0000-00-00 00:00:00'),
(181, NULL, NULL, 'Ruti Maker ', 'ruti-maker', 137, 1, 6, 'ruti maker ', '', '', '', '', '0000-00-00 00:00:00'),
(182, 6688, NULL, 'LED Watch ', 'led-watch', 67, 1, 5, '', '', '', '', '', '0000-00-00 00:00:00'),
(183, NULL, NULL, 'BBQ Grill Maker ', 'bbq-grill-maker', 137, 1, 7, '', '', '', '', '', '0000-00-00 00:00:00'),
(184, NULL, NULL, 'Baby Bath ', 'baby-bath', 132, 1, 6, '', '', '', '', '', '0000-00-00 00:00:00'),
(185, NULL, NULL, 'Latest Three Piece ', 'latest-three-piece', 71, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(186, NULL, NULL, 'Cloth Rack', 'cloth-rack', 73, 1, 4, '', '', '', '', '', '0000-00-00 00:00:00'),
(187, NULL, NULL, 'Paint Accessories', 'paint-accessories', 73, 1, 5, '', '', '', '', '', '0000-00-00 00:00:00'),
(188, NULL, NULL, 'Spy Camera ', 'spy-camera', 65, 1, 12, '', '', '', '', '', '0000-00-00 00:00:00'),
(189, NULL, NULL, 'Makeup Accessories', 'makeup-accessories', 109, 1, 6, 'Makeup Accessories', 'Makeup Accessories', 'Makeup Accessories', 'Makeup Accessories', 'Makeup Accessories', '0000-00-00 00:00:00'),
(190, NULL, NULL, 'Latest three pieces', 'latest-three-pieces', 71, 1, 1, 'Latest three pieces', 'Latest three pieces', 'Latest three pieces', 'Latest three pieces', 'Latest three pieces', '0000-00-00 00:00:00'),
(191, NULL, NULL, 'Latest salwar-kameez', 'latest-salwar-kameez', 80, 1, 6, '', '', '', '', '', '0000-00-00 00:00:00'),
(192, NULL, NULL, 'Latest salwar-kameez', 'latest-salwar-kameez', 161, 1, 5, '', '', '', '', '', '0000-00-00 00:00:00'),
(193, NULL, NULL, 'Groun', 'groun', 109, 1, 6, 'Groun', 'Groun', 'Groun', 'Groun', 'Groun', '0000-00-00 00:00:00'),
(194, NULL, NULL, 'Groun', 'groun', 79, 1, 5, '', '', '', '', '', '0000-00-00 00:00:00'),
(195, NULL, NULL, 'Latest two pieces', 'latest-two-pieces', 80, 1, 6, '', '', '', '', '', '0000-00-00 00:00:00'),
(196, NULL, NULL, 'Latest two pieces', 'latest-two-pieces', 161, 1, 5, '', '', '', '', '', '0000-00-00 00:00:00'),
(197, NULL, NULL, 'Latest one pieces', 'latest-one-pieces', 80, 1, 1, '', '', '', '', '', '0000-00-00 00:00:00'),
(198, NULL, NULL, 'Latest one pieces', 'latest-one-pieces', 161, 1, 1, '', '', '', '', '', '0000-00-00 00:00:00'),
(199, NULL, NULL, 'Home decorate', 'home-decorate', 73, 1, 5, '', '', '', '', '', '0000-00-00 00:00:00'),
(200, NULL, NULL, ' Fan', 'fan', 73, 1, 5, '', '', '', '', '', '0000-00-00 00:00:00'),
(201, NULL, NULL, 'Cooler fan', 'cooler-fan', 73, 1, 6, '', '', '', '', '', '0000-00-00 00:00:00'),
(202, NULL, NULL, 'Night wear', 'night-wear', 109, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(203, NULL, NULL, 'Latest mens shoes', 'latest-mens-shoes', 70, 1, 3, '', '', '', '', '', '0000-00-00 00:00:00'),
(204, 6686, NULL, 'Nibosi', 'nibosi', 67, 1, 4, '', '', '', '', '', '0000-00-00 00:00:00'),
(205, NULL, NULL, 'Projector', 'projector', 65, 1, 10, '', '', '', '', '', '0000-00-00 00:00:00'),
(206, 6687, NULL, 'Naviforce', 'naviforce', 67, 1, 12, '', '', '', '', '', '0000-00-00 00:00:00'),
(207, NULL, NULL, 'Exclusive  Watchs', 'exclusive-watchs', 67, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(208, NULL, NULL, 'practice category', 'practice-category', 208, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(212, NULL, NULL, 'Latest Sahree', 'latest-sahree', 160, 1, 10, '', '', '', '', '', '0000-00-00 00:00:00'),
(214, NULL, NULL, 'Stylish Bed Cover', 'stylish-bed-cover', 81, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(215, NULL, NULL, 'Stylish Bed Cover', 'stylish-bed-cover', 77, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(216, NULL, NULL, 'Stylish Bed Cover', 'stylish-bed-cover', 83, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(217, NULL, NULL, 'Stylish jewelry set   ', 'stylish-jewelry-set', 173, 1, 1, '', '', '', '', '', '0000-00-00 00:00:00'),
(218, NULL, NULL, 'Exclusive Trimmer Collection ', 'exclusive-trimmer-collection', 66, 1, 3, 'saver & trimmer collection ', '', '', '', '', '0000-00-00 00:00:00'),
(219, NULL, NULL, 'Exclusive Trimmer Collection ', 'exclusive-trimmer-collection', 66, 1, 4, '', '', '', '', '', '0000-00-00 00:00:00'),
(220, NULL, NULL, 'Exclusive Trimmer Collection ', 'exclusive-trimmer-collection', 66, 1, 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(221, NULL, NULL, 'exclusive  trimmer', 'exclusive-trimmer', 66, 1, 5, '', '', '', '', '', '0000-00-00 00:00:00'),
(222, NULL, NULL, 'exclusive   trimmer', 'exclusive-trimmer', 66, 1, 9, '', '', '', '', '', '0000-00-00 00:00:00'),
(223, NULL, NULL, 'Exclusive Trimmer ', 'exclusive-trimmer', 66, 1, 3, 'Exclusive Trimmer ', 'Exclusive Trimmer ', 'Exclusive Trimmer ', 'Exclusive Trimmer ', 'Exclusive Trimmer ', '0000-00-00 00:00:00'),
(224, NULL, NULL, 'Exclusive Hair Trimmer ', 'exclusive-hair-trimmer', 68, 1, 2, '', '', '', '', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `category1`
--

CREATE TABLE `category1` (
  `category_id` int(11) NOT NULL,
  `medium_banner` int(11) DEFAULT NULL,
  `category_title` varchar(155) NOT NULL,
  `category_name` varchar(155) NOT NULL,
  `parent_id` int(11) DEFAULT '0',
  `rank_order` int(11) DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `seo_title` varchar(500) DEFAULT NULL,
  `seo_meta_title` varchar(500) DEFAULT NULL,
  `seo_keywords` text,
  `seo_content` text,
  `seo_meta_content` text,
  `registered_date` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category1`
--

INSERT INTO `category1` (`category_id`, `medium_banner`, `category_title`, `category_name`, `parent_id`, `rank_order`, `status`, `seo_title`, `seo_meta_title`, `seo_keywords`, `seo_content`, `seo_meta_content`, `registered_date`) VALUES
(1, 6, 'Electronics', 'electronics-items', 0, 2, 1, '', '', '', '', '', ''),
(2, 7, 'Gadget & Gears', 'gadget--gears', 0, 3, 1, '', '', '', '', '', ''),
(3, 8, 'Beauty Products', 'beauty-products', 0, 4, 1, '', '', '', '', '', ''),
(4, 9, 'Smart Kitchen', 'smart-kitchen', 0, 5, 1, '', '', '', '', '', ''),
(5, 10, 'Fitness products', 'fitness-products', 0, 6, 1, '', '', '', '', '', ''),
(8, 11, 'Baby & Kids', 'baby-kids-item', 0, 7, 1, '', '', '', '', '', ''),
(10, 13, 'Women\'s Collection', 'womens-collection', 0, 9, 1, '', '', '', '', '', ''),
(11, NULL, 'Home Appliances', 'home-appliances', 0, 11, 1, '', '', '', '', '', ''),
(12, NULL, 'Home & Office Security', 'home-office-security', 0, 11, 1, '', '', '', '', '', ''),
(13, NULL, 'YouTube Gears', 'youtube-gears', 0, 12, 1, '', '', '', '', '', ''),
(14, NULL, 'Microphone Collection', 'microphone-collection', 1, 0, 1, '', '', '', '', '', ''),
(16, NULL, 'new category', 'new-category', 3, 5, 0, 'd', 'f', 'd', NULL, 'f', '2020-05-14'),
(17, NULL, 'practice category', 'practice-category', 8, 22, 1, 'Quran Shikkha | Learn Quran in Bangla with Quran Campus', NULL, NULL, NULL, NULL, '2020-05-14'),
(21, NULL, 'new hot', 'new-hot', 14, NULL, 1, NULL, NULL, NULL, NULL, NULL, '2020-05-19'),
(22, NULL, 'Parent category', 'parent-category', 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, '2020-05-19'),
(23, NULL, 'sub parentt category', 'sub-parentt-category', 22, NULL, 1, NULL, NULL, NULL, NULL, NULL, '2020-05-19'),
(24, NULL, 'chaild sub parent', 'chaild-sub-parent', 23, NULL, 1, NULL, NULL, NULL, NULL, NULL, '2020-05-19'),
(25, NULL, 'hot product', 'hot-product', 0, 5, 1, NULL, NULL, NULL, NULL, NULL, '2020-06-06');

-- --------------------------------------------------------

--
-- Table structure for table `courier`
--

CREATE TABLE `courier` (
  `courier_id` int(11) NOT NULL,
  `courier_name` varchar(255) NOT NULL,
  `courier_status` tinyint(4) NOT NULL COMMENT '1 for inside 2 outside',
  `created_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `courier`
--

INSERT INTO `courier` (`courier_id`, `courier_name`, `courier_status`, `created_time`) VALUES
(2, 'sundor bon g', 2, '2020-05-29 06:21:24'),
(3, 'rupali ggggg', 1, '0000-00-00 00:00:00'),
(4, 'milon lai', 1, '2020-05-29 06:21:20');

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `id` int(2) UNSIGNED NOT NULL,
  `division_id` int(2) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `bn_name` varchar(50) NOT NULL,
  `lat` double NOT NULL,
  `lon` double NOT NULL,
  `website` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `division_id`, `name`, `bn_name`, `lat`, `lon`, `website`) VALUES
(1, 3, 'Dhaka', 'ঢাকা', 23.7115253, 90.4111451, 'www.dhaka.gov.bd'),
(2, 3, 'Faridpur', 'ফরিদপুর', 23.6070822, 89.8429406, 'www.faridpur.gov.bd'),
(3, 3, 'Gazipur', 'গাজীপুর', 24.0022858, 90.4264283, 'www.gazipur.gov.bd'),
(4, 3, 'Gopalganj', 'গোপালগঞ্জ', 23.0050857, 89.8266059, 'www.gopalganj.gov.bd'),
(5, 8, 'Jamalpur', 'জামালপুর', 24.937533, 89.937775, 'www.jamalpur.gov.bd'),
(6, 3, 'Kishoreganj', 'কিশোরগঞ্জ', 24.444937, 90.776575, 'www.kishoreganj.gov.bd'),
(7, 3, 'Madaripur', 'মাদারীপুর', 23.164102, 90.1896805, 'www.madaripur.gov.bd'),
(8, 3, 'Manikganj', 'মানিকগঞ্জ', 0, 0, 'www.manikganj.gov.bd'),
(9, 3, 'Munshiganj', 'মুন্সিগঞ্জ', 0, 0, 'www.munshiganj.gov.bd'),
(10, 8, 'Mymensingh', 'ময়মনসিংহ', 0, 0, 'www.mymensingh.gov.bd'),
(11, 3, 'Narayanganj', 'নারায়াণগঞ্জ', 23.63366, 90.496482, 'www.narayanganj.gov.bd'),
(12, 3, 'Narsingdi', 'নরসিংদী', 23.932233, 90.71541, 'www.narsingdi.gov.bd'),
(13, 8, 'Netrokona', 'নেত্রকোণা', 24.870955, 90.727887, 'www.netrokona.gov.bd'),
(14, 3, 'Rajbari', 'রাজবাড়ি', 23.7574305, 89.6444665, 'www.rajbari.gov.bd'),
(15, 3, 'Shariatpur', 'শরীয়তপুর', 0, 0, 'www.shariatpur.gov.bd'),
(16, 8, 'Sherpur', 'শেরপুর', 25.0204933, 90.0152966, 'www.sherpur.gov.bd'),
(17, 3, 'Tangail', 'টাঙ্গাইল', 0, 0, 'www.tangail.gov.bd'),
(18, 5, 'Bogura', 'বগুড়া', 24.8465228, 89.377755, 'www.bogra.gov.bd'),
(19, 5, 'Joypurhat', 'জয়পুরহাট', 0, 0, 'www.joypurhat.gov.bd'),
(20, 5, 'Naogaon', 'নওগাঁ', 0, 0, 'www.naogaon.gov.bd'),
(21, 5, 'Natore', 'নাটোর', 24.420556, 89.000282, 'www.natore.gov.bd'),
(22, 5, 'Chapainawabganj', 'চাঁপাইনবাবগঞ্জ', 24.5965034, 88.2775122, 'www.chapainawabganj.gov.bd'),
(23, 5, 'Pabna', 'পাবনা', 23.998524, 89.233645, 'www.pabna.gov.bd'),
(24, 5, 'Rajshahi', 'রাজশাহী', 0, 0, 'www.rajshahi.gov.bd'),
(25, 5, 'Sirajgonj', 'সিরাজগঞ্জ', 24.4533978, 89.7006815, 'www.sirajganj.gov.bd'),
(26, 6, 'Dinajpur', 'দিনাজপুর', 25.6217061, 88.6354504, 'www.dinajpur.gov.bd'),
(27, 6, 'Gaibandha', 'গাইবান্ধা', 25.328751, 89.528088, 'www.gaibandha.gov.bd'),
(28, 6, 'Kurigram', 'কুড়িগ্রাম', 25.805445, 89.636174, 'www.kurigram.gov.bd'),
(29, 6, 'Lalmonirhat', 'লালমনিরহাট', 0, 0, 'www.lalmonirhat.gov.bd'),
(30, 6, 'Nilphamari', 'নীলফামারী', 25.931794, 88.856006, 'www.nilphamari.gov.bd'),
(31, 6, 'Panchagarh', 'পঞ্চগড়', 26.3411, 88.5541606, 'www.panchagarh.gov.bd'),
(32, 6, 'Rangpur', 'রংপুর', 25.7558096, 89.244462, 'www.rangpur.gov.bd'),
(33, 6, 'Thakurgaon', 'ঠাকুরগাঁও', 26.0336945, 88.4616834, 'www.thakurgaon.gov.bd'),
(34, 1, 'Barguna', 'বরগুনা', 0, 0, 'www.barguna.gov.bd'),
(35, 1, 'Barishal', 'বরিশাল', 0, 0, 'www.barisal.gov.bd'),
(36, 1, 'Bhola', 'ভোলা', 22.685923, 90.648179, 'www.bhola.gov.bd'),
(37, 1, 'Jhalokati', 'ঝালকাঠি', 0, 0, 'www.jhalakathi.gov.bd'),
(38, 1, 'Patuakhali', 'পটুয়াখালী', 22.3596316, 90.3298712, 'www.patuakhali.gov.bd'),
(39, 1, 'Pirojpur', 'পিরোজপুর', 0, 0, 'www.pirojpur.gov.bd'),
(40, 2, 'Bandarban', 'বান্দরবান', 22.1953275, 92.2183773, 'www.bandarban.gov.bd'),
(41, 2, 'Brahmanbaria', 'ব্রাহ্মণবাড়িয়া', 23.9570904, 91.1119286, 'www.brahmanbaria.gov.bd'),
(42, 2, 'Chandpur', 'চাঁদপুর', 23.2332585, 90.6712912, 'www.chandpur.gov.bd'),
(43, 2, 'Chattogram', 'চট্টগ্রাম', 22.335109, 91.834073, 'www.chittagong.gov.bd'),
(44, 2, 'Cumilla', 'কুমিল্লা', 23.4682747, 91.1788135, 'www.comilla.gov.bd'),
(45, 2, 'Cox\'s Bazar', 'কক্স বাজার', 0, 0, 'www.coxsbazar.gov.bd'),
(46, 2, 'Feni', 'ফেনী', 23.023231, 91.3840844, 'www.feni.gov.bd'),
(47, 2, 'Khagrachhari', 'খাগড়াছড়ি', 23.119285, 91.984663, 'www.khagrachhari.gov.bd'),
(48, 2, 'Lakshmipur', 'লক্ষ্মীপুর', 22.942477, 90.841184, 'www.lakshmipur.gov.bd'),
(49, 2, 'Noakhali', 'নোয়াখালী', 22.869563, 91.099398, 'www.noakhali.gov.bd'),
(50, 2, 'Rangamati', 'রাঙ্গামাটি', 0, 0, 'www.rangamati.gov.bd'),
(51, 7, 'Habiganj', 'হবিগঞ্জ', 24.374945, 91.41553, 'www.habiganj.gov.bd'),
(52, 7, 'Moulvibazar', 'মৌলভীবাজার', 24.482934, 91.777417, 'www.moulvibazar.gov.bd'),
(53, 7, 'Sunamganj', 'সুনামগঞ্জ', 25.0658042, 91.3950115, 'www.sunamganj.gov.bd'),
(54, 7, 'Sylhet', 'সিলেট', 24.8897956, 91.8697894, 'www.sylhet.gov.bd'),
(55, 4, 'Bagerhat', 'বাগেরহাট', 22.651568, 89.785938, 'www.bagerhat.gov.bd'),
(56, 4, 'Chuadanga', 'চুয়াডাঙ্গা', 23.6401961, 88.841841, 'www.chuadanga.gov.bd'),
(57, 4, 'Jashore', 'যশোর', 23.16643, 89.2081126, 'www.jessore.gov.bd'),
(58, 4, 'Jhenaidah', 'ঝিনাইদহ', 23.5448176, 89.1539213, 'www.jhenaidah.gov.bd'),
(59, 4, 'Khulna', 'খুলনা', 22.815774, 89.568679, 'www.khulna.gov.bd'),
(60, 4, 'Kushtia', 'কুষ্টিয়া', 23.901258, 89.120482, 'www.kushtia.gov.bd'),
(61, 4, 'Magura', 'মাগুরা', 23.487337, 89.419956, 'www.magura.gov.bd'),
(62, 4, 'Meherpur', 'মেহেরপুর', 23.762213, 88.631821, 'www.meherpur.gov.bd'),
(63, 4, 'Narail', 'নড়াইল', 23.172534, 89.512672, 'www.narail.gov.bd'),
(64, 4, 'Satkhira', 'সাতক্ষীরা', 0, 0, 'www.satkhira.gov.bd');

-- --------------------------------------------------------

--
-- Table structure for table `divisions`
--

CREATE TABLE `divisions` (
  `id` int(2) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `bn_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `divisions`
--

INSERT INTO `divisions` (`id`, `name`, `bn_name`) VALUES
(1, 'Barishal', 'বরিশাল'),
(2, 'Chattogram', 'চট্টগ্রাম'),
(3, 'Dhaka', 'ঢাকা'),
(4, 'Khulna', 'খুলনা'),
(5, 'Rajshahi', 'রাজশাহী'),
(6, 'Rangpur', 'রংপুর'),
(7, 'Sylhet', 'সিলেট'),
(8, 'Mymensingh', 'ময়মনসিংহ');

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `expense_id` int(11) NOT NULL,
  `expense_type` text,
  `expense_title` text,
  `expense_total` float DEFAULT NULL,
  `expense_data` longtext,
  `expense_summary` text,
  `expense_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `expense_category`
--

CREATE TABLE `expense_category` (
  `expense_cat_id` int(11) NOT NULL,
  `expense_cat_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `hitcounter`
--

CREATE TABLE `hitcounter` (
  `hitcounter_id` int(11) NOT NULL,
  `client_ip` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `platform` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `agent` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `hitcounter`
--

INSERT INTO `hitcounter` (`hitcounter_id`, `client_ip`, `date`, `platform`, `agent`) VALUES
(701, '::1', '2020-01-23', 'Windows 10', 'Firefox 72.0'),
(700, '::1', '2020-01-21', 'Windows 10', 'Firefox 72.0'),
(699, '::1', '2020-01-20', 'Windows 10', 'Firefox 72.0'),
(698, '103.198.171.255', '2020-01-20', 'Windows 10', 'Firefox 72.0'),
(697, '210.138.184.59', '2020-01-19', 'Windows 10', 'Firefox 72.0'),
(696, '127.0.0.1', '2020-01-18', 'Windows 10', 'Firefox 72.0'),
(695, '::1', '2020-01-15', 'Windows 10', 'Firefox 72.0'),
(694, '127.0.0.1', '2020-01-15', 'Windows 10', 'Firefox 72.0'),
(693, '::1', '2020-01-14', 'Windows 10', 'Firefox 72.0'),
(692, '::1', '2020-01-13', 'Windows 10', 'Firefox 72.0'),
(691, '127.0.0.1', '2020-01-12', 'Windows 10', 'Firefox 72.0'),
(690, '127.0.0.1', '2020-01-12', 'Windows 10', 'Firefox 72.0'),
(689, '::1', '2020-01-13', 'Windows 10', 'Firefox 72.0'),
(688, '::1', '2020-01-14', 'Windows 10', 'Firefox 72.0'),
(687, '127.0.0.1', '2020-01-15', 'Windows 10', 'Firefox 72.0'),
(686, '::1', '2020-01-15', 'Windows 10', 'Firefox 72.0'),
(685, '127.0.0.1', '2020-01-18', 'Windows 10', 'Firefox 72.0'),
(684, '210.138.184.59', '2020-01-19', 'Windows 10', 'Firefox 72.0'),
(683, '103.198.171.255', '2020-01-20', 'Windows 10', 'Firefox 72.0'),
(682, '::1', '2020-01-20', 'Windows 10', 'Firefox 72.0'),
(681, '::1', '2020-01-21', 'Windows 10', 'Firefox 72.0'),
(680, '::1', '2020-01-23', 'Windows 10', 'Firefox 72.0'),
(675, '::1', '2020-01-23', 'Windows 10', 'Firefox 72.0'),
(674, '::1', '2020-01-21', 'Windows 10', 'Firefox 72.0'),
(673, '::1', '2020-01-20', 'Windows 10', 'Firefox 72.0'),
(672, '103.198.171.255', '2020-01-20', 'Windows 10', 'Firefox 72.0'),
(671, '210.138.184.59', '2020-01-19', 'Windows 10', 'Firefox 72.0'),
(670, '127.0.0.1', '2020-01-18', 'Windows 10', 'Firefox 72.0'),
(669, '::1', '2020-01-15', 'Windows 10', 'Firefox 72.0'),
(668, '127.0.0.1', '2020-01-15', 'Windows 10', 'Firefox 72.0'),
(667, '::1', '2020-01-14', 'Windows 10', 'Firefox 72.0'),
(666, '::1', '2020-01-13', 'Windows 10', 'Firefox 72.0'),
(665, '127.0.0.1', '2020-01-12', 'Windows 10', 'Firefox 72.0'),
(651, '127.0.0.1', '2020-01-12', 'Windows 10', 'Firefox 72.0'),
(652, '::1', '2020-01-13', 'Windows 10', 'Firefox 72.0'),
(653, '::1', '2020-01-14', 'Windows 10', 'Firefox 72.0'),
(654, '127.0.0.1', '2020-01-15', 'Windows 10', 'Firefox 72.0'),
(655, '::1', '2020-01-15', 'Windows 10', 'Firefox 72.0'),
(656, '127.0.0.1', '2020-01-18', 'Windows 10', 'Firefox 72.0'),
(657, '210.138.184.59', '2020-01-19', 'Windows 10', 'Firefox 72.0'),
(658, '103.198.171.255', '2020-01-20', 'Windows 10', 'Firefox 72.0'),
(659, '::1', '2020-01-20', 'Windows 10', 'Firefox 72.0'),
(660, '::1', '2020-01-21', 'Windows 10', 'Firefox 72.0'),
(661, '::1', '2020-01-23', 'Windows 10', 'Firefox 72.0'),
(703, '::1', '2020-02-05', 'Windows 10', 'Firefox 72.0');

-- --------------------------------------------------------

--
-- Table structure for table `homeslider`
--

CREATE TABLE `homeslider` (
  `homeslider_id` int(11) NOT NULL,
  `homeslider_title` varchar(555) CHARACTER SET utf8 NOT NULL DEFAULT '#',
  `homeslider_text` text CHARACTER SET utf8,
  `target_url` varchar(555) CHARACTER SET utf8 NOT NULL DEFAULT '#',
  `homeslider_picture` varchar(555) CHARACTER SET utf8 NOT NULL,
  `created_time` datetime NOT NULL,
  `modified_time` datetime NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homeslider`
--

INSERT INTO `homeslider` (`homeslider_id`, `homeslider_title`, `homeslider_text`, `target_url`, `homeslider_picture`, `created_time`, `modified_time`, `status`) VALUES
(11, 'Slider one', NULL, 'ddggg', '1591289809.jpg', '0000-00-00 00:00:00', '2020-06-04 00:00:00', 0),
(12, 'fff', NULL, 'ffff', '1591289358.jpg', '2020-06-04 00:00:00', '2020-06-04 00:00:00', 1),
(13, 'hot', NULL, 'ddd', '1591289563.jpg', '2020-06-04 00:00:00', '2020-06-04 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `inquiry`
--

CREATE TABLE `inquiry` (
  `inquiry_id` int(11) NOT NULL,
  `name` varchar(155) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(250) NOT NULL,
  `subject` varchar(555) CHARACTER SET utf8 NOT NULL,
  `status` varchar(6) NOT NULL DEFAULT '0',
  `message` text CHARACTER SET utf8 NOT NULL,
  `created_time` datetime NOT NULL,
  `modified_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inquiry`
--

INSERT INTO `inquiry` (`inquiry_id`, `name`, `phone`, `subject`, `status`, `message`, `created_time`, `modified_time`) VALUES
(4, 'Md Shahinul Islam Suzon', '01731692631', 'I need html template', '0', 'ddd', '2019-12-02 04:33:06', '0000-00-00 00:00:00'),
(5, 'Md Shahinul Islam Suzon', '01731692631', 'I need html template', '0', 'ddd', '2019-12-02 09:35:15', '0000-00-00 00:00:00'),
(6, 'Md Shahinul Islam Suzon', '01731692631', 'I need html template', '1', 'fffffff', '2019-12-02 09:45:07', '0000-00-00 00:00:00'),
(7, 'Md Shahinul Islam Suzon', '01711000000', 'I need html template', '0', 'rrr', '2019-12-02 09:45:41', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `media_id` int(11) NOT NULL,
  `media_title` varchar(555) DEFAULT '#',
  `product_code` varchar(50) DEFAULT NULL,
  `media_path` varchar(555) NOT NULL,
  `media_type` varchar(200) DEFAULT NULL,
  `product_id` int(15) DEFAULT NULL,
  `created_time` datetime NOT NULL,
  `modified_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`media_id`, `media_title`, `product_code`, `media_path`, `media_type`, `product_id`, `created_time`, `modified_time`) VALUES
(3, 'Site Logo', '', 'uploads/07-01-2020-ES Logo 64x64.png', '', 0, '2020-01-07 01:07:13', '0000-00-00 00:00:00'),
(4, 'Ekusheyshop Logo ', '', 'uploads/07-01-2020-ES Logo 280x80.png', '', 0, '2020-01-07 01:07:33', '0000-00-00 00:00:00'),
(6, 'Electronics Items', '', 'uploads/electronics_items_318x624.jpg', '', 0, '2020-01-07 02:11:27', '2020-01-07 02:11:27'),
(7, 'Gadget & Gears', '', 'uploads/gadget_items_318x624.jpg', '', 0, '2020-01-07 04:42:23', '2020-01-07 04:42:23'),
(8, 'Beauty Products', '', 'uploads/beauty_items_318x624.jpg', '', 0, '2020-01-07 04:43:14', '2020-01-07 04:43:14'),
(9, 'Smart Kitchen', '', 'uploads/smart_kitchen_318x624.jpg', '', 0, '2020-01-07 04:43:42', '2020-01-07 04:43:42'),
(10, 'Fitness products', '', 'uploads/Fitness_items_318x624.jpg', '', 0, '2020-01-07 04:44:29', '2020-01-07 04:44:29'),
(11, 'Baby & Kids Item', '', 'uploads/baby_kids_318x624.jpg', '', 0, '2020-01-07 04:49:06', '2020-01-07 04:49:06'),
(12, 'Home Decor', '', 'uploads/home_decor_318x624.jpg', '', 0, '2020-01-07 04:49:24', '2020-01-07 04:49:24'),
(13, 'Women\'s Collection', '', 'uploads/women_collection_318x624.jpg', '', 0, '2020-01-07 04:49:54', '2020-01-07 04:49:54'),
(14, 'WiFi IP Security Camera -wireless CCTV Camera for home and office security', '', 'uploads/1578414877wifi-ip-security-camera-wireless-cctv-camera-for-home-and-office-security 1001-5.jpg', '', 0, '2020-01-07 22:34:37', '2020-01-07 22:34:37'),
(15, 'WiFi IP Security Camera -wireless CCTV Camera for home and office security', '', 'uploads/1578414877wifi-ip-security-camera-wireless-cctv-camera-for-home-and-office-security 1001-3.jpg', '', 0, '2020-01-07 22:34:37', '2020-01-07 22:34:37'),
(16, 'WiFi IP Security Camera -wireless CCTV Camera for home and office security', '', 'uploads/1578414877wifi-ip-security-camera-wireless-cctv-camera-for-home-and-office-security 1001-2.jpg', '', 0, '2020-01-07 22:34:37', '2020-01-07 22:34:37'),
(17, 'WiFi IP Security Camera -wireless CCTV Camera for home and office security', '', 'uploads/1578414877wifi-ip-security-camera-wireless-cctv-camera-for-home-and-office-security 1001-7.jpg', '', 0, '2020-01-07 22:34:37', '2020-01-07 22:34:37'),
(18, 'WiFi IP Security Camera -wireless CCTV Camera for home and office security', '', 'uploads/1578414877wifi-ip-security-camera-wireless-cctv-camera-for-home-and-office-security 1001-6.jpg', '', 0, '2020-01-07 22:34:37', '2020-01-07 22:34:37'),
(19, 'Single Antenna WiFi IP Security Camera- wireless CCTV Camera for home and office security', '', 'uploads/1578416153Single Antenna WiFi IP Security Camera- wireless CCTV Camera for home and office security 1002-2.jpg', '', 0, '2020-01-07 22:55:53', '2020-01-07 22:55:53'),
(20, 'Single Antenna WiFi IP Security Camera- wireless CCTV Camera for home and office security', '', 'uploads/1578416153Single Antenna WiFi IP Security Camera- wireless CCTV Camera for home and office security 1002-5.jpg', '', 0, '2020-01-07 22:55:53', '2020-01-07 22:55:53'),
(21, 'Single Antenna WiFi IP Security Camera- wireless CCTV Camera for home and office security', '', 'uploads/1578416153Single Antenna WiFi IP Security Camera- wireless CCTV Camera for home and office security 1002-3.jpg', '', 0, '2020-01-07 22:55:53', '2020-01-07 22:55:53'),
(22, 'Single Antenna WiFi IP Security Camera- wireless CCTV Camera for home and office security', '', 'uploads/1578416153Single Antenna WiFi IP Security Camera- wireless CCTV Camera for home and office security 1002-4.jpg', '', 0, '2020-01-07 22:55:53', '2020-01-07 22:55:53'),
(23, 'Double Antenna WiFi IP Security Camera- wireless CCTV Camera for home and office security', '', 'uploads/1578416456Double Antenna WiFi IP Security Camera wireless CCTV Camera for home and office Security 1003-1.jpg', '', 0, '2020-01-07 23:00:56', '2020-01-07 23:00:56'),
(24, 'Double Antenna WiFi IP Security Camera- wireless CCTV Camera for home and office security', '', 'uploads/1578416456Double Antenna WiFi IP Security Camera wireless CCTV Camera for home and office Security 1003-4.jpg', '', 0, '2020-01-07 23:00:56', '2020-01-07 23:00:56'),
(25, 'Double Antenna WiFi IP Security Camera- wireless CCTV Camera for home and office security', '', 'uploads/1578416456Double Antenna WiFi IP Security Camera wireless CCTV Camera for home and office Security 1003-3.jpg', '', 0, '2020-01-07 23:00:56', '2020-01-07 23:00:56'),
(26, 'Aluminium alloy hand operate keema machine manual meat grinder sausage beef meet mincer machine with tabletop clamp kitchen home tool', '', 'uploads/1578417457Aluminium alloy hand operate keema machine manual meat grinder sausage beef meet mincer machine with tabletop clamp kitch 1005-1.jpg', '', 0, '2020-01-07 23:17:37', '2020-01-07 23:17:37'),
(27, 'Aluminium alloy hand operate keema machine manual meat grinder sausage beef meet mincer machine with tabletop clamp kitchen home tool', '', 'uploads/1578417457Aluminium alloy hand operate keema machine manual meat grinder sausage beef meet mincer machine with tabletop clamp kitch 1005-5.jpg', '', 0, '2020-01-07 23:17:37', '2020-01-07 23:17:37'),
(28, 'Aluminium alloy hand operate keema machine manual meat grinder sausage beef meet mincer machine with tabletop clamp kitchen home tool', '', 'uploads/1578417457Aluminium alloy hand operate keema machine manual meat grinder sausage beef meet mincer machine with tabletop clamp kitchen home tool 1005-2.jpg', '', 0, '2020-01-07 23:17:37', '2020-01-07 23:17:37'),
(29, 'Aluminium alloy hand operate keema machine manual meat grinder sausage beef meet mincer machine with tabletop clamp kitchen home tool', '', 'uploads/1578417457Aluminium alloy hand operate keema machine manual meat grinder sausage beef meet mincer machine with tabletop clamp kitch 1005-4.jpg', '', 0, '2020-01-07 23:17:37', '2020-01-07 23:17:37'),
(30, 'Clever Cutter 2 in 1 Stainless Steel Knife with Cutting Board, Smart vegetable Cutter, kitchen scissors for Quick and Easy Cutting, Food Scissors, Vegetable Slicer', '', 'uploads/1578450993Clever Cutter 2 in 1 Stainless Steel Knife with Cutting Board, Smart vegetable Cutter, kitchen scissors for Quick and Eas 1006-5.jpg', '', 0, '2020-01-08 08:36:33', '2020-01-08 08:36:33'),
(31, 'Clever Cutter 2 in 1 Stainless Steel Knife with Cutting Board, Smart vegetable Cutter, kitchen scissors for Quick and Easy Cutting, Food Scissors, Vegetable Slicer', '', 'uploads/1578450993Clever Cutter 2 in 1 Stainless Steel Knife with Cutting Board, Smart vegetable Cutter, kitchen scissors for Quick and Eas 1006-3.jpg', '', 0, '2020-01-08 08:36:33', '2020-01-08 08:36:33'),
(32, 'Clever Cutter 2 in 1 Stainless Steel Knife with Cutting Board, Smart vegetable Cutter, kitchen scissors for Quick and Easy Cutting, Food Scissors, Vegetable Slicer', '', 'uploads/1578450993Clever Cutter 2 in 1 Stainless Steel Knife with Cutting Board, Smart vegetable Cutter, kitchen scissors for Quick and Eas 1006-2.jpg', '', 0, '2020-01-08 08:36:33', '2020-01-08 08:36:33'),
(33, 'Clever Cutter 2 in 1 Stainless Steel Knife with Cutting Board, Smart vegetable Cutter, kitchen scissors for Quick and Easy Cutting, Food Scissors, Vegetable Slicer', '', 'uploads/1578450993Clever Cutter 2 in 1 Stainless Steel Knife with Cutting Board, Smart vegetable Cutter, kitchen scissors for Quick and Eas 1006-4.jpg', '', 0, '2020-01-08 08:36:33', '2020-01-08 08:36:33'),
(34, 'Clever Cutter 2 in 1 Stainless Steel Knife with Cutting Board, Smart vegetable Cutter, kitchen scissors for Quick and Easy Cutting, Food Scissors, Vegetable Slicer', '', 'uploads/1578450993Clever Cutter 2 in 1 Stainless Steel Knife with Cutting Board, Smart vegetable Cutter, kitchen scissors for Quick and Eas 1006-1.jpg', '', 0, '2020-01-08 08:36:33', '2020-01-08 08:36:33'),
(35, 'Automatic Doi Maker - Electric Yogurt Maker, Kitchen Appliances, Stainless Steel Yogurt Maker', '', 'uploads/1578451322Automatic Doi Maker - Electric Yogurt Maker, Kitchen Appliances, Stainless Steel Yogurt Maker 1007-6.jpg', '', 0, '2020-01-08 08:42:02', '2020-01-08 08:42:02'),
(36, 'Automatic Doi Maker - Electric Yogurt Maker, Kitchen Appliances, Stainless Steel Yogurt Maker', '', 'uploads/1578451322Automatic Doi Maker - Electric Yogurt Maker, Kitchen Appliances, Stainless Steel Yogurt Maker 1007-1.jpg', '', 0, '2020-01-08 08:42:02', '2020-01-08 08:42:02'),
(37, 'Automatic Doi Maker - Electric Yogurt Maker, Kitchen Appliances, Stainless Steel Yogurt Maker', '', 'uploads/1578451322Automatic Doi Maker - Electric Yogurt Maker, Kitchen Appliances, Stainless Steel Yogurt Maker 1007-4.jpg', '', 0, '2020-01-08 08:42:02', '2020-01-08 08:42:02'),
(38, 'Automatic Doi Maker - Electric Yogurt Maker, Kitchen Appliances, Stainless Steel Yogurt Maker', '', 'uploads/1578451322Automatic Doi Maker - Electric Yogurt Maker, Kitchen Appliances, Stainless Steel Yogurt Maker 1007-4.jpg', '', 0, '2020-01-08 08:42:02', '2020-01-08 08:42:02'),
(39, 'Water Spray Mop With Reusable Microfiber Pads 360 Degree Metal Handle Mop For Home Kitchen Laminate Wood Ceramic Tiles Floor Cleaning, Quick floor Cleaner with Refillable Water Bottle', '', 'uploads/1578451547Water Spray Mop With Reusable Microfiber Pads 360 Degree Metal Handle Mop For Home Kitchen Laminate Wood Ceramic Tiles Fl 1008-1.jpg', '', 0, '2020-01-08 08:45:47', '2020-01-08 08:45:47'),
(40, 'Water Spray Mop With Reusable Microfiber Pads 360 Degree Metal Handle Mop For Home Kitchen Laminate Wood Ceramic Tiles Floor Cleaning, Quick floor Cleaner with Refillable Water Bottle', '', 'uploads/1578451548Water Spray Mop With Reusable Microfiber Pads 360 Degree Metal Handle Mop For Home Kitchen Laminate Wood Ceramic Tiles Fl 1008-4.jpg', '', 0, '2020-01-08 08:45:48', '2020-01-08 08:45:48'),
(41, 'Water Spray Mop With Reusable Microfiber Pads 360 Degree Metal Handle Mop For Home Kitchen Laminate Wood Ceramic Tiles Floor Cleaning, Quick floor Cleaner with Refillable Water Bottle', '', 'uploads/1578451548Water Spray Mop With Reusable Microfiber Pads 360 Degree Metal Handle Mop For Home Kitchen Laminate Wood Ceramic Tiles Fl 1008-3.jpg', '', 0, '2020-01-08 08:45:48', '2020-01-08 08:45:48'),
(42, 'Water Spray Mop With Reusable Microfiber Pads 360 Degree Metal Handle Mop For Home Kitchen Laminate Wood Ceramic Tiles Floor Cleaning, Quick floor Cleaner with Refillable Water Bottle', '', 'uploads/1578451548Water Spray Mop With Reusable Microfiber Pads 360 Degree Metal Handle Mop For Home Kitchen Laminate Wood Ceramic Tiles Fl 1008-2.jpg', '', 0, '2020-01-08 08:45:48', '2020-01-08 08:45:48'),
(43, 'Stainless Steel Kitchen Bathroom Shelf Wall-mounted Storage Rack Single Layer', '', 'uploads/1578452066Stainless Steel Kitchen Bathroom Shelf Wall-mounted Storage Rack Single Layer 1009-1-2.jpg', '', 0, '2020-01-08 08:54:26', '2020-01-08 08:54:26'),
(44, 'Stainless Steel Kitchen Bathroom Shelf Wall-mounted Storage Rack Single Layer', '', 'uploads/1578452066Stainless Steel Kitchen Bathroom Shelf Wall-mounted Storage Rack Single Layer 1009-1-1.jpg', '', 0, '2020-01-08 08:54:26', '2020-01-08 08:54:26'),
(45, 'Stainless Steel Kitchen Bathroom Shelf Wall-mounted Storage Rack Single Layer Corner Tray', '', 'uploads/1578452226Stainless Steel Kitchen Bathroom Shelf Wall-mounted Storage Rack Single Layer Corner Tray 1009-2-4.jpg', '', 0, '2020-01-08 08:57:06', '2020-01-08 08:57:06'),
(46, 'Stainless Steel Kitchen Bathroom Shelf Wall-mounted Storage Rack Single Layer Corner Tray', '', 'uploads/1578452226Stainless Steel Kitchen Bathroom Shelf Wall-mounted Storage Rack Single Layer Corner Tray 1009-2-5.jpg', '', 0, '2020-01-08 08:57:06', '2020-01-08 08:57:06'),
(47, 'Stainless Steel Kitchen Bathroom Shelf Wall-mounted Storage Rack Single Layer Corner Tray', '', 'uploads/1578452226Stainless Steel Kitchen Bathroom Shelf Wall-mounted Storage Rack Single Layer Corner Tray 1009-2-1.jpg', '', 0, '2020-01-08 08:57:06', '2020-01-08 08:57:06'),
(58, 'Epilator, Finishing Touch Hair Remover Instant With Sensor Light, Women\'s Pain Free Hair Removal', '', 'uploads/1578462113epilator-finishing-touch-hair-remover-instant-with-sensor-light-womens-pain-free-hair-removal 1010-4.jpg', '', 0, '2020-01-08 11:41:53', '2020-01-08 11:41:53'),
(59, 'Epilator, Finishing Touch Hair Remover Instant With Sensor Light, Women\'s Pain Free Hair Removal', '', 'uploads/1578462113epilator-finishing-touch-hair-remover-instant-with-sensor-light-womens-pain-free-hair-removal 1010-1.jpg', '', 0, '2020-01-08 11:41:53', '2020-01-08 11:41:53'),
(60, 'Epilator, Finishing Touch Hair Remover Instant With Sensor Light, Women\'s Pain Free Hair Removal', '', 'uploads/1578462113epilator-finishing-touch-hair-remover-instant-with-sensor-light-womens-pain-free-hair-removal 1010-2.jpg', '', 0, '2020-01-08 11:41:53', '2020-01-08 11:41:53'),
(61, 'Epilator, Finishing Touch Hair Remover Instant With Sensor Light, Women\'s Pain Free Hair Removal', '', 'uploads/1578462113epilator-finishing-touch-hair-remover-instant-with-sensor-light-womens-pain-free-hair-removal 1010-3.jpg', '', 0, '2020-01-08 11:41:53', '2020-01-08 11:41:53'),
(62, 'GSM 3G WiFi Modem For Any Device, Portable Mini Wi-fi Mobile Device 3G Wireless Dongle with TF SIM Card Slot', '', 'uploads/1578466857GSM 3G WiFi Modem For Any Device, Portable Mini Wi-fi Mobile Device 3G Wireless Dongle with TF SIM Card Slot 1011-5.jpg', '', 0, '2020-01-08 13:00:57', '2020-01-08 13:00:57'),
(63, 'GSM 3G WiFi Modem For Any Device, Portable Mini Wi-fi Mobile Device 3G Wireless Dongle with TF SIM Card Slot', '', 'uploads/1578466857GSM 3G WiFi Modem For Any Device, Portable Mini Wi-fi Mobile Device 3G Wireless Dongle with TF SIM Card Slot 1011-1.jpg', '', 0, '2020-01-08 13:00:57', '2020-01-08 13:00:57'),
(64, 'GSM 3G WiFi Modem For Any Device, Portable Mini Wi-fi Mobile Device 3G Wireless Dongle with TF SIM Card Slot', '', 'uploads/1578466857GSM 3G WiFi Modem For Any Device, Portable Mini Wi-fi Mobile Device 3G Wireless Dongle with TF SIM Card Slot 1011-3.jpg', '', 0, '2020-01-08 13:00:57', '2020-01-08 13:00:57'),
(65, 'Multifunction baby carrier 3-18 months for baby, baby sling breathable fabric baby backpack wrapping kangaroo front face Adjustable baby Carrier', '', 'uploads/1578468044Multifunction baby carrier 3-18 months for baby, baby sling breathable fabric baby backpack wrapping kangaroo front face Adjustable baby Carrier 1012-2.jpg', '', 0, '2020-01-08 13:20:44', '2020-01-08 13:20:44'),
(66, 'Multifunction baby carrier 3-18 months for baby, baby sling breathable fabric baby backpack wrapping kangaroo front face Adjustable baby Carrier', '', 'uploads/1578468044Multifunction baby carrier 3-18 months for baby, baby sling breathable fabric baby backpack wrapping kangaroo front face Adjustable baby Carrier 1012-5.jpg', '', 0, '2020-01-08 13:20:44', '2020-01-08 13:20:44'),
(67, 'Multifunction baby carrier 3-18 months for baby, baby sling breathable fabric baby backpack wrapping kangaroo front face Adjustable baby Carrier', '', 'uploads/1578468044Multifunction baby carrier 3-18 months for baby, baby sling breathable fabric baby backpack wrapping kangaroo front face Adjustable baby Carrier 1012-6.jpg', '', 0, '2020-01-08 13:20:44', '2020-01-08 13:20:44'),
(68, 'Multifunction baby carrier 3-18 months for baby, baby sling breathable fabric baby backpack wrapping kangaroo front face Adjustable baby Carrier', '', 'uploads/1578468044Multifunction baby carrier 3-18 months for baby, baby sling breathable fabric baby backpack wrapping kangaroo front face Adjustable baby Carrier 1012-4.jpg', '', 0, '2020-01-08 13:20:44', '2020-01-08 13:20:44'),
(69, 'Electric Digital Therapy Machine Massager Pulse Acupuncture Stiumlator Body Slimming Eletrode Treatment Device Relax Muscle Pain Relief Therapy ', '', 'uploads/1578468272Electric Digital Therapy Machine Massager Pulse Acupuncture Stiumlator Body Slimming Eletrode Treatment Device Relax Muscle Pain Relief Therapy  1022-1.jpg', '', 0, '2020-01-08 13:24:32', '2020-01-08 13:24:32'),
(70, 'Electric Digital Therapy Machine Massager Pulse Acupuncture Stiumlator Body Slimming Eletrode Treatment Device Relax Muscle Pain Relief Therapy ', '', 'uploads/1578468272Electric Digital Therapy Machine Massager Pulse Acupuncture Stiumlator Body Slimming Eletrode Treatment Device Relax Muscle Pain Relief Therapy  1022-2.jpg', '', 0, '2020-01-08 13:24:32', '2020-01-08 13:24:32'),
(71, 'Electric Digital Therapy Machine Massager Pulse Acupuncture Stiumlator Body Slimming Eletrode Treatment Device Relax Muscle Pain Relief Therapy ', '', 'uploads/1578468272Electric Digital Therapy Machine Massager Pulse Acupuncture Stiumlator Body Slimming Eletrode Treatment Device Relax Muscle Pain Relief Therapy  1022-5.jpg', '', 0, '2020-01-08 13:24:32', '2020-01-08 13:24:32'),
(72, 'Electric Digital Therapy Machine Massager Pulse Acupuncture Stiumlator Body Slimming Eletrode Treatment Device Relax Muscle Pain Relief Therapy ', '', 'uploads/1578468272Electric Digital Therapy Machine Massager Pulse Acupuncture Stiumlator Body Slimming Eletrode Treatment Device Relax Muscle Pain Relief Therapy  1022-4.jpg', '', 0, '2020-01-08 13:24:32', '2020-01-08 13:24:32'),
(73, 'VIBRO shape high performance slimming belt, Vibration massage slimming belt, massager to loose weight waist belt power plate massageador for slimming', '', 'uploads/1578468566VIBRO shape high performance slimming belt, Vibration massage slimming belt, massager to loose weight waist belt power plate massageador for slimming 1023-3.jpg', '', 0, '2020-01-08 13:29:26', '2020-01-08 13:29:26'),
(74, 'VIBRO shape high performance slimming belt, Vibration massage slimming belt, massager to loose weight waist belt power plate massageador for slimming', '', 'uploads/1578468566VIBRO shape high performance slimming belt, Vibration massage slimming belt, massager to loose weight waist belt power plate massageador for slimming 1023-4.jpg', '', 0, '2020-01-08 13:29:26', '2020-01-08 13:29:26'),
(75, 'VIBRO shape high performance slimming belt, Vibration massage slimming belt, massager to loose weight waist belt power plate massageador for slimming', '', 'uploads/1578468566VIBRO shape high performance slimming belt, Vibration massage slimming belt, massager to loose weight waist belt power plate massageador for slimming 1023-5.jpg', '', 0, '2020-01-08 13:29:26', '2020-01-08 13:29:26'),
(76, 'VIBRO shape high performance slimming belt, Vibration massage slimming belt, massager to loose weight waist belt power plate massageador for slimming', '', 'uploads/1578468566VIBRO shape high performance slimming belt, Vibration massage slimming belt, massager to loose weight waist belt power plate massageador for slimming 1023-2.jpg', '', 0, '2020-01-08 13:29:26', '2020-01-08 13:29:26'),
(77, 'Digital Quran learning Pen Reader, Quran Pen', '', 'uploads/1578468777Digital Quran learning Pen Reader, Quran Pen 1027-6.jpg', '', 0, '2020-01-08 13:32:57', '2020-01-08 13:32:57'),
(78, 'Digital Quran learning Pen Reader, Quran Pen', '', 'uploads/1578468777Digital Quran learning Pen Reader, Quran Pen 1027-5.jpg', '', 0, '2020-01-08 13:32:57', '2020-01-08 13:32:57'),
(79, 'Digital Quran learning Pen Reader, Quran Pen', '', 'uploads/1578468777Digital Quran learning Pen Reader, Quran Pen 1027-1.jpg', '', 0, '2020-01-08 13:32:57', '2020-01-08 13:32:57'),
(80, 'Digital Quran learning Pen Reader, Quran Pen', '', 'uploads/1578468777Digital Quran learning Pen Reader, Quran Pen 1027-7.jpg', '', 0, '2020-01-08 13:32:57', '2020-01-08 13:32:57'),
(81, 'Car and Home Relaxation Massage Pillow Vibrator Electric Shoulder Back Heating Kneading Massage Pillow with Heat for Shoulders, Massage Tool Relieve Stress Pillow', '', 'uploads/1578472045Car and Home Relaxation Massage Pillow Vibrator Electric Shoulder Back Heating Kneading Massage Pillow with Heat for Shoulders, Massage Tool Relieve Stress Pillow 1029-6.jpg', '', 0, '2020-01-08 14:27:25', '2020-01-08 14:27:25'),
(82, 'Car and Home Relaxation Massage Pillow Vibrator Electric Shoulder Back Heating Kneading Massage Pillow with Heat for Shoulders, Massage Tool Relieve Stress Pillow', '', 'uploads/1578472045Car and Home Relaxation Massage Pillow Vibrator Electric Shoulder Back Heating Kneading Massage Pillow with Heat for Shoulders, Massage Tool Relieve Stress Pillow 1029-4.jpg', '', 0, '2020-01-08 14:27:25', '2020-01-08 14:27:25'),
(83, 'Car and Home Relaxation Massage Pillow Vibrator Electric Shoulder Back Heating Kneading Massage Pillow with Heat for Shoulders, Massage Tool Relieve Stress Pillow', '', 'uploads/1578472045Car and Home Relaxation Massage Pillow Vibrator Electric Shoulder Back Heating Kneading Massage Pillow with Heat for Shoulders, Massage Tool Relieve Stress Pillow 1029-2.jpg', '', 0, '2020-01-08 14:27:25', '2020-01-08 14:27:25'),
(84, 'Car and Home Relaxation Massage Pillow Vibrator Electric Shoulder Back Heating Kneading Massage Pillow with Heat for Shoulders, Massage Tool Relieve Stress Pillow', '', 'uploads/1578472045Car and Home Relaxation Massage Pillow Vibrator Electric Shoulder Back Heating Kneading Massage Pillow with Heat for Shoulders, Massage Tool Relieve Stress Pillow 1029-5.jpg', '', 0, '2020-01-08 14:27:25', '2020-01-08 14:27:25'),
(85, 'Car and Home Relaxation Massage Pillow Vibrator Electric Shoulder Back Heating Kneading Massage Pillow with Heat for Shoulders, Massage Tool Relieve Stress Pillow', '', 'uploads/1578472045Car and Home Relaxation Massage Pillow Vibrator Electric Shoulder Back Heating Kneading Massage Pillow with Heat for Shoulders, Massage Tool Relieve Stress Pillow 1029-1.jpg', '', 0, '2020-01-08 14:27:25', '2020-01-08 14:27:25'),
(86, 'Paint Zoom Professional Electric Paint Sprayer Gun Adjustable Flow Control For Cars Furniture Woodworking painting machine tool', '', 'uploads/1578472434Paint Zoom Professional Electric Paint Sprayer GunAdjustable Flow Control For Cars Furniture Woodworking painting machine tool 1033-2.jpg', '', 0, '2020-01-08 14:33:54', '2020-01-08 14:33:54'),
(87, 'Paint Zoom Professional Electric Paint Sprayer Gun Adjustable Flow Control For Cars Furniture Woodworking painting machine tool', '', 'uploads/1578472435Paint Zoom Professional Electric Paint Sprayer GunAdjustable Flow Control For Cars Furniture Woodworking painting machine tool 1033-1.jpg', '', 0, '2020-01-08 14:33:55', '2020-01-08 14:33:55'),
(88, 'Paint Zoom Professional Electric Paint Sprayer Gun Adjustable Flow Control For Cars Furniture Woodworking painting machine tool', '', 'uploads/1578472435Paint Zoom Professional Electric Paint Sprayer GunAdjustable Flow Control For Cars Furniture Woodworking painting machine tool 1033-3.jpg', '', 0, '2020-01-08 14:33:55', '2020-01-08 14:33:55'),
(89, 'Paint Zoom Professional Electric Paint Sprayer Gun Adjustable Flow Control For Cars Furniture Woodworking painting machine tool', '', 'uploads/1578472435Paint Zoom Professional Electric Paint Sprayer GunAdjustable Flow Control For Cars Furniture Woodworking painting machine tool 1033-4.jpg', '', 0, '2020-01-08 14:33:55', '2020-01-08 14:33:55'),
(90, 'Fast Hair Straightener Hair Brush Comb hair Electric brush comb Irons Auto Straight Hair Comb brush', '', 'uploads/1578473137Fast Hair Straightener Hair Brush Comb hair Electric brush comb Irons Auto Straight Hair Comb brush 1034-2.jpg', '', 0, '2020-01-08 14:45:37', '2020-01-08 14:45:37'),
(91, 'Fast Hair Straightener Hair Brush Comb hair Electric brush comb Irons Auto Straight Hair Comb brush', '', 'uploads/1578473137Fast Hair Straightener Hair Brush Comb hair Electric brush comb Irons Auto Straight Hair Comb brush 1034-3.jpg', '', 0, '2020-01-08 14:45:37', '2020-01-08 14:45:37'),
(92, 'Fast Hair Straightener Hair Brush Comb hair Electric brush comb Irons Auto Straight Hair Comb brush', '', 'uploads/1578473137Fast Hair Straightener Hair Brush Comb hair Electric brush comb Irons Auto Straight Hair Comb brush 1034-1.jpg', '', 0, '2020-01-08 14:45:37', '2020-01-08 14:45:37'),
(93, 'Deep Cleaning Facial Osenjie Professional Facial Steamer - Thermal Sprayer Skin Care Tool household Spa beauty instrument', '', 'uploads/1578473512Deep Cleaning Facial Osenjie Professional Facial Steamer - Thermal Sprayer Skin Care Tool household Spa beauty instrument 1035-5.jpg', '', 0, '2020-01-08 14:51:52', '2020-01-08 14:51:52'),
(94, 'Deep Cleaning Facial Osenjie Professional Facial Steamer - Thermal Sprayer Skin Care Tool household Spa beauty instrument', '', 'uploads/1578473512Deep Cleaning Facial Osenjie Professional Facial Steamer - Thermal Sprayer Skin Care Tool household Spa beauty instrument 1035-4.jpg', '', 0, '2020-01-08 14:51:52', '2020-01-08 14:51:52'),
(95, 'Deep Cleaning Facial Osenjie Professional Facial Steamer - Thermal Sprayer Skin Care Tool household Spa beauty instrument', '', 'uploads/1578473512Deep Cleaning Facial Osenjie Professional Facial Steamer - Thermal Sprayer Skin Care Tool household Spa beauty instrument 1035-1.jpg', '', 0, '2020-01-08 14:51:52', '2020-01-08 14:51:52'),
(96, 'Deep Cleaning Facial Osenjie Professional Facial Steamer - Thermal Sprayer Skin Care Tool household Spa beauty instrument', '', 'uploads/1578473512Deep Cleaning Facial Osenjie Professional Facial Steamer - Thermal Sprayer Skin Care Tool household Spa beauty instrument 1035-2.jpg', '', 0, '2020-01-08 14:51:52', '2020-01-08 14:51:52'),
(97, 'Kemei KM-531 Dry Professional Electric Hair Straightener Curling Iron Styling Hair Fast Heating Hair Splint', '', 'uploads/1578478254Kemei KM-531 Professional Electric Hair Straightener Curling Iron Styling Hair Fast Heating Hair Splint 1036-1.jpg', '', 0, '2020-01-08 16:10:54', '2020-01-08 16:10:54'),
(98, 'Kemei KM-531 Dry Professional Electric Hair Straightener Curling Iron Styling Hair Fast Heating Hair Splint', '', 'uploads/1578478255Kemei KM-531 Professional Electric Hair Straightener Curling Iron Styling Hair Fast Heating Hair Splint 1036-2.jpg', '', 0, '2020-01-08 16:10:55', '2020-01-08 16:10:55'),
(99, 'Kemei KM-531 Dry Professional Electric Hair Straightener Curling Iron Styling Hair Fast Heating Hair Splint', '', 'uploads/1578478255Kemei KM-531 Professional Electric Hair Straightener Curling Iron Styling Hair Fast Heating Hair Splint 1036-5.jpg', '', 0, '2020-01-08 16:10:55', '2020-01-08 16:10:55'),
(100, '50 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '', 'uploads/1578478754Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer 1037-1.jpg', '', 0, '2020-01-08 16:19:14', '2020-01-08 16:19:14'),
(101, '50 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '', 'uploads/1578478754Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer 1037-6.jpg', '', 0, '2020-01-08 16:19:14', '2020-01-08 16:19:14'),
(102, '50 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '', 'uploads/1578478754Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer 1037-5.jpg', '', 0, '2020-01-08 16:19:14', '2020-01-08 16:19:14'),
(103, '75 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '', 'uploads/1578478927Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer 1037-5.jpg', '', 0, '2020-01-08 16:22:07', '2020-01-08 16:22:07'),
(104, '75 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '', 'uploads/1578478927Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer 1037-7.jpg', '', 0, '2020-01-08 16:22:07', '2020-01-08 16:22:07'),
(105, '75 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '', 'uploads/1578478927Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer 1037-3.jpg', '', 0, '2020-01-08 16:22:07', '2020-01-08 16:22:07'),
(106, '100 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '', 'uploads/1578479332Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer 1037-1.jpg', '', 0, '2020-01-08 16:28:52', '2020-01-08 16:28:52'),
(107, '100 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '', 'uploads/1578479332Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer 1037-4.jpg', '', 0, '2020-01-08 16:28:52', '2020-01-08 16:28:52'),
(108, '100 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '', 'uploads/1578479332Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer 1037-8.jpg', '', 0, '2020-01-08 16:28:52', '2020-01-08 16:28:52'),
(109, '150 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '', 'uploads/1578479447Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer 1037-5.jpg', '', 0, '2020-01-08 16:30:47', '2020-01-08 16:30:47'),
(110, '150 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '', 'uploads/1578479447Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer 1037-9.jpg', '', 0, '2020-01-08 16:30:47', '2020-01-08 16:30:47'),
(111, '150 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '', 'uploads/1578479447Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer 1037-7.jpg', '', 0, '2020-01-08 16:30:47', '2020-01-08 16:30:47'),
(112, 'Sound Amplifier Hearing Aid Adjustable Tone Battery Mini In Ear Aids', '', 'uploads/1578479572Sound Amplifier Hearing Aid Adjustable Tone Battery Mini In Ear Aids 1038-2.jpg', '', 0, '2020-01-08 16:32:52', '2020-01-08 16:32:52'),
(113, 'Sound Amplifier Hearing Aid Adjustable Tone Battery Mini In Ear Aids', '', 'uploads/1578479572Sound Amplifier Hearing Aid Adjustable Tone Battery Mini In Ear Aids 1038-3.jpg', '', 0, '2020-01-08 16:32:52', '2020-01-08 16:32:52'),
(114, 'Sound Amplifier Hearing Aid Adjustable Tone Battery Mini In Ear Aids', '', 'uploads/1578479572Sound Amplifier Hearing Aid Adjustable Tone Battery Mini In Ear Aids 1038-1.jpg', '', 0, '2020-01-08 16:32:52', '2020-01-08 16:32:52'),
(115, 'Infrared Foot Massager, Vibrating Massage Blood Circulation Pain Relief Pedicure Machine Electric 220V Infrared Treatment Magnetic Wave Heating Therapy', '', 'uploads/1578479892Infrared Foot Massager, Vibrating Massage Blood Circulation Pain Relief Pedicure Machine Electric 220V Infrared Treatment Magnetic Wave Heating Therapy 1039-2.jpg', '', 0, '2020-01-08 16:38:12', '2020-01-08 16:38:12'),
(116, 'Infrared Foot Massager, Vibrating Massage Blood Circulation Pain Relief Pedicure Machine Electric 220V Infrared Treatment Magnetic Wave Heating Therapy', '', 'uploads/1578479892Infrared Foot Massager, Vibrating Massage Blood Circulation Pain Relief Pedicure Machine Electric 220V Infrared Treatment Magnetic Wave Heating Therapy 1039-4.jpg', '', 0, '2020-01-08 16:38:12', '2020-01-08 16:38:12'),
(117, 'Infrared Foot Massager, Vibrating Massage Blood Circulation Pain Relief Pedicure Machine Electric 220V Infrared Treatment Magnetic Wave Heating Therapy', '', 'uploads/1578479893Infrared Foot Massager, Vibrating Massage Blood Circulation Pain Relief Pedicure Machine Electric 220V Infrared Treatment Magnetic Wave Heating Therapy 1039-3.jpg', '', 0, '2020-01-08 16:38:13', '2020-01-08 16:38:13'),
(118, 'Multifunction Hot Water Bag, Electric Rechargeable Heat Water Bag, Electric Hand Warmer Long Heat Stability', '', 'uploads/1578481196Multifunction Hot Water Bag, Electric Rechargeable Heat Water Bag, Electric Hand Warmer Long Heat Stability 1040-6.jpg', '', 0, '2020-01-08 16:59:56', '2020-01-08 16:59:56'),
(119, 'Multifunction Hot Water Bag, Electric Rechargeable Heat Water Bag, Electric Hand Warmer Long Heat Stability', '', 'uploads/1578481196Multifunction Hot Water Bag, Electric Rechargeable Heat Water Bag, Electric Hand Warmer Long Heat Stability 1040-5.jpg', '', 0, '2020-01-08 16:59:56', '2020-01-08 16:59:56'),
(120, 'Multifunction Hot Water Bag, Electric Rechargeable Heat Water Bag, Electric Hand Warmer Long Heat Stability', '', 'uploads/1578481196Multifunction Hot Water Bag, Electric Rechargeable Heat Water Bag, Electric Hand Warmer Long Heat Stability 1040-2.jpg', '', 0, '2020-01-08 16:59:56', '2020-01-08 16:59:56'),
(121, 'Mini Digital Scale Luggage Travel Weighing Scale Hanging Electronic Hook Scales Portable Weighing Tool with LCD display', '', 'uploads/1578481534Mini Digital Scale Luggage Travel Weighing Scale Hanging Electronic Hook Scales Portable Weighing Tool with LCD display 1041-7.jpg', '', 0, '2020-01-08 17:05:34', '2020-01-08 17:05:34'),
(122, 'Mini Digital Scale Luggage Travel Weighing Scale Hanging Electronic Hook Scales Portable Weighing Tool with LCD display', '', 'uploads/1578481534Mini Digital Scale Luggage Travel Weighing Scale Hanging Electronic Hook Scales Portable Weighing Tool with LCD display 1041-1.jpg', '', 0, '2020-01-08 17:05:34', '2020-01-08 17:05:34'),
(123, 'Mini Digital Scale Luggage Travel Weighing Scale Hanging Electronic Hook Scales Portable Weighing Tool with LCD display', '', 'uploads/1578481534Mini Digital Scale Luggage Travel Weighing Scale Hanging Electronic Hook Scales Portable Weighing Tool with LCD display 1041-6.jpg', '', 0, '2020-01-08 17:05:34', '2020-01-08 17:05:34'),
(124, 'Wax Vac Gentle and Effective Ear Cleaner, Ear Wax Remover Electric Vac Vacuum Cordless Earwax Removal Painlessly Tool', '', 'uploads/1578481646Wax Vac Gentle and Effective Ear Cleaner, Ear Wax Remover Electric Vac Vacuum Cordless Earwax Removal Painlessly Tool 1042-2.jpg', '', 0, '2020-01-08 17:07:26', '2020-01-08 17:07:26'),
(125, 'Wax Vac Gentle and Effective Ear Cleaner, Ear Wax Remover Electric Vac Vacuum Cordless Earwax Removal Painlessly Tool', '', 'uploads/1578481647Wax Vac Gentle and Effective Ear Cleaner, Ear Wax Remover Electric Vac Vacuum Cordless Earwax Removal Painlessly Tool 1042-1.jpg', '', 0, '2020-01-08 17:07:27', '2020-01-08 17:07:27'),
(126, 'Real Time Mini GPS Tracker for Vehicles - Smart Magnetic Car Tracker Locator Device Voice Recorder - Location Tracker for Cars, Boats, Motorcycle', '', 'uploads/1578481807Real Time Mini GPS Tracker for Vehicles - Smart Magnetic Car Tracker Locator Device Voice Recorder - Location Tracker for Cars, Boats, Motorcycle 1043-5.jpg', '', 0, '2020-01-08 17:10:07', '2020-01-08 17:10:07'),
(127, 'Real Time Mini GPS Tracker for Vehicles - Smart Magnetic Car Tracker Locator Device Voice Recorder - Location Tracker for Cars, Boats, Motorcycle', '', 'uploads/1578481807Real Time Mini GPS Tracker for Vehicles - Smart Magnetic Car Tracker Locator Device Voice Recorder - Location Tracker for Cars, Boats, Motorcycle 1043-3.jpg', '', 0, '2020-01-08 17:10:07', '2020-01-08 17:10:07'),
(128, 'Real Time Mini GPS Tracker for Vehicles - Smart Magnetic Car Tracker Locator Device Voice Recorder - Location Tracker for Cars, Boats, Motorcycle', '', 'uploads/1578481807Real Time Mini GPS Tracker for Vehicles - Smart Magnetic Car Tracker Locator Device Voice Recorder - Location Tracker for Cars, Boats, Motorcycle 1043-1.jpg', '', 0, '2020-01-08 17:10:07', '2020-01-08 17:10:07'),
(129, 'Multifunctional Manual Hand Juicer', '', 'uploads/1578481946Multifunctional Manual Hand Juicer 1044-1.jpg', '', 0, '2020-01-08 17:12:26', '2020-01-08 17:12:26'),
(130, 'Multifunctional Manual Hand Juicer', '', 'uploads/1578481946Multifunctional Manual Hand Juicer 1044-3.jpg', '', 0, '2020-01-08 17:12:26', '2020-01-08 17:12:26'),
(131, 'Multifunctional Manual Hand Juicer', '', 'uploads/1578481946Multifunctional Manual Hand Juicer 1044-4.jpg', '', 0, '2020-01-08 17:12:26', '2020-01-08 17:12:26'),
(132, 'Digital LCD Upper Arm Blood Pressure Monitor Medical Equipment Heart Beat Meter Machine Adjustable Wrist Cuffs for Health Monitoring', '', 'uploads/1578482111Digital Electric Wrist Blood Pressure Monitor, Fully Automatic Blood Pressure Machine, Portable Smart Medical equipment Pulse Rate Diagnostic-tool 1046-3.jpg', '', 0, '2020-01-08 17:15:11', '2020-01-08 17:15:11'),
(133, 'Digital LCD Upper Arm Blood Pressure Monitor Medical Equipment Heart Beat Meter Machine Adjustable Wrist Cuffs for Health Monitoring', '', 'uploads/1578482112Digital Electric Wrist Blood Pressure Monitor, Fully Automatic Blood Pressure Machine, Portable Smart Medical equipment Pulse Rate Diagnostic-tool 1046-2.jpg', '', 0, '2020-01-08 17:15:12', '2020-01-08 17:15:12'),
(134, 'Hot Sweat Neoprene Body Shaper Slimming Belt Waist for Weight Loss Women & Men ', '', 'uploads/1578482997Sweat Slim Belt, Slimming Waist Belts Neoprene Body Shaper, slimming belt for Weight Loss 1048-2.jpg', '', 0, '2020-01-08 17:29:57', '2020-01-08 17:29:57'),
(135, 'Hot Sweat Neoprene Body Shaper Slimming Belt Waist for Weight Loss Women & Men ', '', 'uploads/1578482997Sweat Slim Belt, Slimming Waist Belts Neoprene Body Shaper, slimming belt for Weight Loss 1048-3.jpg', '', 0, '2020-01-08 17:29:57', '2020-01-08 17:29:57'),
(136, 'Hot Sweat Neoprene Body Shaper Slimming Belt Waist for Weight Loss Women & Men ', '', 'uploads/1578482997Sweat Slim Belt, Slimming Waist Belts Neoprene Body Shaper, slimming belt for Weight Loss 1048-4.jpg', '', 0, '2020-01-08 17:29:57', '2020-01-08 17:29:57'),
(137, 'Single Air Bed Air Mattress Camping Mat Inflatable Mattress Camping Bed Beach mat With Electric Pump', '', 'uploads/1578483177Single Air Bed Air Mattress Camping Mat Inflatable Mattress Camping Bed Beach mat With Electric Pump 1049-2.jpg', '', 0, '2020-01-08 17:32:57', '2020-01-08 17:32:57'),
(138, 'Single Air Bed Air Mattress Camping Mat Inflatable Mattress Camping Bed Beach mat With Electric Pump', '', 'uploads/1578483177Single Air Bed Air Mattress Camping Mat Inflatable Mattress Camping Bed Beach mat With Electric Pump 1049-1.jpg', '', 0, '2020-01-08 17:32:57', '2020-01-08 17:32:57'),
(139, 'Single Air Bed Air Mattress Camping Mat Inflatable Mattress Camping Bed Beach mat With Electric Pump', '', 'uploads/1578483177Single Air Bed Air Mattress Camping Mat Inflatable Mattress Camping Bed Beach mat With Electric Pump 1049-3.jpg', '', 0, '2020-01-08 17:32:57', '2020-01-08 17:32:57'),
(140, 'Round shape Inflatable air Sofa Bed for 2 person, Creative Lazy Sofa Home Air Bed Household Products', '', 'uploads/1578483309Round shape Inflatable air Sofa Bed for 2 person, Creative Lazy Sofa Home Air Bed Household Products 1050-3.jpg', '', 0, '2020-01-08 17:35:09', '2020-01-08 17:35:09'),
(141, 'Round shape Inflatable air Sofa Bed for 2 person, Creative Lazy Sofa Home Air Bed Household Products', '', 'uploads/1578483310Round shape Inflatable air Sofa Bed for 2 person, Creative Lazy Sofa Home Air Bed Household Products 1050-1.jpg', '', 0, '2020-01-08 17:35:10', '2020-01-08 17:35:10'),
(142, 'Round shape Inflatable air Sofa Bed for 2 person, Creative Lazy Sofa Home Air Bed Household Products', '', 'uploads/1578483310Round shape Inflatable air Sofa Bed for 2 person, Creative Lazy Sofa Home Air Bed Household Products 1050-2.jpg', '', 0, '2020-01-08 17:35:10', '2020-01-08 17:35:10'),
(143, 'Kemei KM-1055 2 in 1 Professional Hair Straightener Iron Hair Curler, Hair Straightening Styling Tools', '', 'uploads/1578483397Kemei KM-1055 2 in 1 Professional Hair Straightener Iron Hair Curler, Hair Straightening Styling Tools 1051-1.jpg', '', 0, '2020-01-08 17:36:37', '2020-01-08 17:36:37'),
(144, 'Kemei KM-1055 2 in 1 Professional Hair Straightener Iron Hair Curler, Hair Straightening Styling Tools', '', 'uploads/1578483397Kemei KM-1055 2 in 1 Professional Hair Straightener Iron Hair Curler, Hair Straightening Styling Tools 1051-3.jpg', '', 0, '2020-01-08 17:36:37', '2020-01-08 17:36:37'),
(145, 'Kemei KM-1055 2 in 1 Professional Hair Straightener Iron Hair Curler, Hair Straightening Styling Tools', '', 'uploads/1578483397Kemei KM-1055 2 in 1 Professional Hair Straightener Iron Hair Curler, Hair Straightening Styling Tools 1051-2.jpg', '', 0, '2020-01-08 17:36:37', '2020-01-08 17:36:37'),
(146, 'Easy Egg Cracker - Creative Kitchen Egg Tools  with Egg White Separator Cooking Tool', '', 'uploads/1578483478Easy Egg Cracker - Creative Kitchen Egg Tools  with Egg White Separator Cooking Tool 1052-1.jpg', '', 0, '2020-01-08 17:37:58', '2020-01-08 17:37:58'),
(147, 'Easy Egg Cracker - Creative Kitchen Egg Tools  with Egg White Separator Cooking Tool', '', 'uploads/1578483478Easy Egg Cracker - Creative Kitchen Egg Tools  with Egg White Separator Cooking Tool 1052-3.jpg', '', 0, '2020-01-08 17:37:58', '2020-01-08 17:37:58'),
(148, 'Easy Egg Cracker - Creative Kitchen Egg Tools  with Egg White Separator Cooking Tool', '', 'uploads/1578483478Easy Egg Cracker - Creative Kitchen Egg Tools  with Egg White Separator Cooking Tool 1052-2.jpg', '', 0, '2020-01-08 17:37:58', '2020-01-08 17:37:58'),
(149, 'Aluminum Hack Saw Handsaw Frame Blade Dual Rubber Handles ', '', 'uploads/1578483545Aluminum Hack Saw Handsaw Frame Blade Dual Rubber Handles  1053-2.jpg', '', 0, '2020-01-08 17:39:05', '2020-01-08 17:39:05'),
(150, 'Aluminum Hack Saw Handsaw Frame Blade Dual Rubber Handles ', '', 'uploads/1578483545Aluminum Hack Saw Handsaw Frame Blade Dual Rubber Handles  1053-1.jpg', '', 0, '2020-01-08 17:39:05', '2020-01-08 17:39:05'),
(151, 'Multi-function Adjustable Wrench Snap\'N Grip Tools (2Pcs 9-32mm Spanner Set)', '', 'uploads/1578483721Multi-function Adjustable Wrench Snap N Grip Tools (2Pcs 9-32mm Spanner Set) 1054-4.jpg', '', 0, '2020-01-08 17:42:01', '2020-01-08 17:42:01'),
(152, 'Multi-function Adjustable Wrench Snap\'N Grip Tools (2Pcs 9-32mm Spanner Set)', '', 'uploads/1578483721Multi-function Adjustable Wrench Snap N Grip Tools (2Pcs 9-32mm Spanner Set) 1054-1.jpg', '', 0, '2020-01-08 17:42:01', '2020-01-08 17:42:01'),
(153, 'Multi-function Adjustable Wrench Snap\'N Grip Tools (2Pcs 9-32mm Spanner Set)', '', 'uploads/1578483721Multi-function Adjustable Wrench Snap N Grip Tools (2Pcs 9-32mm Spanner Set) 1054-3.jpg', '', 0, '2020-01-08 17:42:01', '2020-01-08 17:42:01'),
(154, 'USB Mini Fish Tank Desktop Aquarium With Lamp Light, Clock, Water Recirculation Best Gift Item', '', 'uploads/1578484553USB Mini Fish Tank Desktop Aquarium With Lamp Light, Clock, Water Recirculation Best Gift Item 1055-7.jpg', '', 0, '2020-01-08 17:55:53', '2020-01-08 17:55:53'),
(155, 'USB Mini Fish Tank Desktop Aquarium With Lamp Light, Clock, Water Recirculation Best Gift Item', '', 'uploads/1578484554USB Mini Fish Tank Desktop Aquarium With Lamp Light, Clock, Water Recirculation Best Gift Item 1055-2.jpg', '', 0, '2020-01-08 17:55:54', '2020-01-08 17:55:54'),
(156, 'USB Mini Fish Tank Desktop Aquarium With Lamp Light, Clock, Water Recirculation Best Gift Item', '', 'uploads/1578484554USB Mini Fish Tank Desktop Aquarium With Lamp Light, Clock, Water Recirculation Best Gift Item 1055-1.jpg', '', 0, '2020-01-08 17:55:54', '2020-01-08 17:55:54'),
(157, 'Flawless Hair Remover, Facial Hair Removal for Women, Painless Electric Hair Remover for Women\'s Cheeks, Lips, Chin and Neck Built-in LED Light', '', 'uploads/1578484838Flawless Hair Remover  Facial Hair Removal for Women, Painless Electric Hair Remover for Womens Cheeks, Lips, Chin and Neck Built-in LED Light 1056-2.jpg', '', 0, '2020-01-08 18:00:38', '2020-01-08 18:00:38'),
(158, 'Flawless Hair Remover, Facial Hair Removal for Women, Painless Electric Hair Remover for Women\'s Cheeks, Lips, Chin and Neck Built-in LED Light', '', 'uploads/1578484839Flawless Hair Remover  Facial Hair Removal for Women, Painless Electric Hair Remover for Womens Cheeks, Lips, Chin and Neck Built-in LED Light 1056-1.jpg', '', 0, '2020-01-08 18:00:39', '2020-01-08 18:00:39'),
(159, 'Flawless Hair Remover, Facial Hair Removal for Women, Painless Electric Hair Remover for Women\'s Cheeks, Lips, Chin and Neck Built-in LED Light', '', 'uploads/1578484839Flawless Hair Remover  Facial Hair Removal for Women, Painless Electric Hair Remover for Womens Cheeks, Lips, Chin and Neck Built-in LED Light 1056-3.jpg', '', 0, '2020-01-08 18:00:39', '2020-01-08 18:00:39'),
(160, 'Pain Relief Vibrating Massage Bed / Electric Vibrator Heating Back Neck Massager Mattress Leg Waist Cushion Mat Home Office Relax Bed  Health Care', '', 'uploads/1578485077Pain Relief Vibrating Massage Bed  Electric Vibrator Heating Back Neck Massager Mattress Leg Waist Cushion Mat Home Office Relax Bed  Health Care 1057-2.jpg', '', 0, '2020-01-08 18:04:37', '2020-01-08 18:04:37'),
(161, 'Pain Relief Vibrating Massage Bed / Electric Vibrator Heating Back Neck Massager Mattress Leg Waist Cushion Mat Home Office Relax Bed  Health Care', '', 'uploads/1578485078Pain Relief Vibrating Massage Bed  Electric Vibrator Heating Back Neck Massager Mattress Leg Waist Cushion Mat Home Office Relax Bed  Health Care 1057-1.jpg', '', 0, '2020-01-08 18:04:38', '2020-01-08 18:04:38'),
(162, 'Pain Relief Vibrating Massage Bed / Electric Vibrator Heating Back Neck Massager Mattress Leg Waist Cushion Mat Home Office Relax Bed  Health Care', '', 'uploads/1578485078Pain Relief Vibrating Massage Bed  Electric Vibrator Heating Back Neck Massager Mattress Leg Waist Cushion Mat Home Office Relax Bed  Health Care 1057-3.jpg', '', 0, '2020-01-08 18:04:38', '2020-01-08 18:04:38'),
(163, 'Power Extension Socket Outlet Portable Travel Power Strip Surge Protector With 4 USB port Smart Charger Wall', '', 'uploads/1578485176Power Extension Socket Outlet Portable Travel Power Strip Surge Protector With 4 USB port Smart Charger Wall 1058-1.jpg', '', 0, '2020-01-08 18:06:16', '2020-01-08 18:06:16'),
(164, 'Power Extension Socket Outlet Portable Travel Power Strip Surge Protector With 4 USB port Smart Charger Wall', '', 'uploads/1578485176Power Extension Socket Outlet Portable Travel Power Strip Surge Protector With 4 USB port Smart Charger Wall 1058-2.jpg', '', 0, '2020-01-08 18:06:16', '2020-01-08 18:06:16'),
(165, '5 in 1 Large Inflatable Sofa cum bed, Double Sofa Bed Double Air Bed Multifunction Couch Camping Mattress', '', 'uploads/15784853355 in 1 Large Inflatable Sofa cum bed, Double Sofa Bed Double Air Bed Multifunction Couch Camping Mattress 1059-4.jpg', '', 0, '2020-01-08 18:08:55', '2020-01-08 18:08:55'),
(166, '5 in 1 Large Inflatable Sofa cum bed, Double Sofa Bed Double Air Bed Multifunction Couch Camping Mattress', '', 'uploads/15784853355 in 1 Large Inflatable Sofa cum bed, Double Sofa Bed Double Air Bed Multifunction Couch Camping Mattress 1059-1.jpg', '', 0, '2020-01-08 18:08:55', '2020-01-08 18:08:55'),
(167, '5 in 1 Large Inflatable Sofa cum bed, Double Sofa Bed Double Air Bed Multifunction Couch Camping Mattress', '', 'uploads/15784853355 in 1 Large Inflatable Sofa cum bed, Double Sofa Bed Double Air Bed Multifunction Couch Camping Mattress 1059-5.jpg', '', 0, '2020-01-08 18:08:55', '2020-01-08 18:08:55'),
(168, '5 in 1 Large Inflatable Sofa cum bed, Double Sofa Bed Double Air Bed Multifunction Couch Camping Mattress', '', 'uploads/15784853365 in 1 Large Inflatable Sofa cum bed, Double Sofa Bed Double Air Bed Multifunction Couch Camping Mattress 1059-2.jpg', '', 0, '2020-01-08 18:08:56', '2020-01-08 18:08:56'),
(169, 'Professional Drill Machine Set with 100 pcs Tool Kit', '', 'uploads/1578485453Professional Drill Machine Set with 100 pcs Tool Kit 1060-1.jpg', '', 0, '2020-01-08 18:10:53', '2020-01-08 18:10:53'),
(170, 'Stainless Steel 8 inches Roti Maker/Puri Press/Puri Maker/Papad maker/Khakhra Maker/paratha maker', '', 'uploads/1578485600Stainless Steel 8 inches Roti MakerPuri PressPuri MakerPapad makerKhakhra Makerparatha maker 1061-3.jpg', '', 0, '2020-01-08 18:13:20', '2020-01-08 18:13:20'),
(171, 'Stainless Steel 8 inches Roti Maker/Puri Press/Puri Maker/Papad maker/Khakhra Maker/paratha maker', '', 'uploads/1578485600Stainless Steel 8 inches Roti MakerPuri PressPuri MakerPapad makerKhakhra Makerparatha maker 1061-2.jpg', '', 0, '2020-01-08 18:13:20', '2020-01-08 18:13:20'),
(172, 'Waterproof Siren Alarm Padlock Alarm Lock for Motorcycle Bike Bicycle Perfect Security with 110dB Alarm Pad locks', '', 'uploads/1578485739Waterproof Siren Alarm Padlock Alarm Lock for Motorcycle Bike Bicycle Perfect Security with 110dB Alarm Pad locks 1063-5.jpg', '', 0, '2020-01-08 18:15:39', '2020-01-08 18:15:39'),
(173, 'Waterproof Siren Alarm Padlock Alarm Lock for Motorcycle Bike Bicycle Perfect Security with 110dB Alarm Pad locks', '', 'uploads/1578485740Waterproof Siren Alarm Padlock Alarm Lock for Motorcycle Bike Bicycle Perfect Security with 110dB Alarm Pad locks 1063-4.jpg', '', 0, '2020-01-08 18:15:40', '2020-01-08 18:15:40');
INSERT INTO `media` (`media_id`, `media_title`, `product_code`, `media_path`, `media_type`, `product_id`, `created_time`, `modified_time`) VALUES
(174, 'Waterproof Siren Alarm Padlock Alarm Lock for Motorcycle Bike Bicycle Perfect Security with 110dB Alarm Pad locks', '', 'uploads/1578485740Waterproof Siren Alarm Padlock Alarm Lock for Motorcycle Bike Bicycle Perfect Security with 110dB Alarm Pad locks 1063-1.jpg', '', 0, '2020-01-08 18:15:40', '2020-01-08 18:15:40'),
(175, 'KeySmart Compact Key Holder(2 to 10 Keys) Pocket Key Wallet Smart keychain Key Ring Wallets Portable Compact Aluminum key clip Multi-functional Smart Clip', '', 'uploads/1578485870KeySmart Compact Key Holder(2 to 10 Keys) Pocket Key Wallet Smart keychain Key Ring Wallets Portable Compact Aluminum key clip Multi-functional Smart Clip 1064-2.jpg', '', 0, '2020-01-08 18:17:50', '2020-01-08 18:17:50'),
(176, 'KeySmart Compact Key Holder(2 to 10 Keys) Pocket Key Wallet Smart keychain Key Ring Wallets Portable Compact Aluminum key clip Multi-functional Smart Clip', '', 'uploads/1578485870KeySmart Compact Key Holder(2 to 10 Keys) Pocket Key Wallet Smart keychain Key Ring Wallets Portable Compact Aluminum key clip Multi-functional Smart Clip 1064-4.jpg', '', 0, '2020-01-08 18:17:50', '2020-01-08 18:17:50'),
(177, 'KeySmart Compact Key Holder(2 to 10 Keys) Pocket Key Wallet Smart keychain Key Ring Wallets Portable Compact Aluminum key clip Multi-functional Smart Clip', '', 'uploads/1578485870KeySmart Compact Key Holder(2 to 10 Keys) Pocket Key Wallet Smart keychain Key Ring Wallets Portable Compact Aluminum key clip Multi-functional Smart Clip 1064-3.jpg', '', 0, '2020-01-08 18:17:50', '2020-01-08 18:17:50'),
(178, 'KeySmart Compact Key Holder(2 to 10 Keys) Pocket Key Wallet Smart keychain Key Ring Wallets Portable Compact Aluminum key clip Multi-functional Smart Clip', '', 'uploads/1578485870KeySmart Compact Key Holder(2 to 10 Keys) Pocket Key Wallet Smart keychain Key Ring Wallets Portable Compact Aluminum key clip Multi-functional Smart Clip 1064-1.jpg', '', 0, '2020-01-08 18:17:50', '2020-01-08 18:17:50'),
(179, 'ECO Fire Stop Aluminum Flame Retardant Fuild Portable Fire Extinguisher for home and car,500ml', '', 'uploads/1578486001ECO Fire Stop Aluminum Flame Retardant Fuild Portable Fire Extinguisher for home and car,500ml 1065-4.jpg', '', 0, '2020-01-08 18:20:01', '2020-01-08 18:20:01'),
(180, 'ECO Fire Stop Aluminum Flame Retardant Fuild Portable Fire Extinguisher for home and car,500ml', '', 'uploads/1578486001ECO Fire Stop Aluminum Flame Retardant Fuild Portable Fire Extinguisher for home and car,500ml 1065-3.jpg', '', 0, '2020-01-08 18:20:01', '2020-01-08 18:20:01'),
(181, 'ECO Fire Stop Aluminum Flame Retardant Fuild Portable Fire Extinguisher for home and car,500ml', '', 'uploads/1578486001ECO Fire Stop Aluminum Flame Retardant Fuild Portable Fire Extinguisher for home and car,500ml 1065-2.jpg', '', 0, '2020-01-08 18:20:01', '2020-01-08 18:20:01'),
(182, 'Dual SIM supported GSM landphone wireless Phone  Desktop cordless phone', '', 'uploads/1578486196Dual SIM supported GSM landphone wireless Phone  Desktop cordless phone 1066-2.jpg', '', 0, '2020-01-08 18:23:16', '2020-01-08 18:23:16'),
(183, 'Dual SIM supported GSM landphone wireless Phone  Desktop cordless phone', '', 'uploads/1578486196Dual SIM supported GSM landphone wireless Phone  Desktop cordless phone 1066-1.jpg', '', 0, '2020-01-08 18:23:16', '2020-01-08 18:23:16'),
(184, 'Double Air Bed Air Mattress Camping Mat Inflatable Mattress Camping Bed Beach mat With Electric Pump', '', 'uploads/1578487083Double Air Bed Air Mattress Camping Mat Inflatable Mattress Camping Bed Beach mat With Electric Pump 1068-4.jpg', '', 0, '2020-01-08 18:38:03', '2020-01-08 18:38:03'),
(185, 'Double Air Bed Air Mattress Camping Mat Inflatable Mattress Camping Bed Beach mat With Electric Pump', '', 'uploads/1578487083Double Air Bed Air Mattress Camping Mat Inflatable Mattress Camping Bed Beach mat With Electric Pump 1068-1.jpg', '', 0, '2020-01-08 18:38:03', '2020-01-08 18:38:03'),
(186, 'Double Air Bed Air Mattress Camping Mat Inflatable Mattress Camping Bed Beach mat With Electric Pump', '', 'uploads/1578487083Double Air Bed Air Mattress Camping Mat Inflatable Mattress Camping Bed Beach mat With Electric Pump 1068-2.jpg', '', 0, '2020-01-08 18:38:03', '2020-01-08 18:38:03'),
(187, 'Tolsen Rechargeable Drill Machine / cordless screwdriver', '', 'uploads/1578487249Tolsen Rechargeable Drill Machine  cordless screwdriver 1069-2.jpg', '', 0, '2020-01-08 18:40:49', '2020-01-08 18:40:49'),
(188, 'Tolsen Rechargeable Drill Machine / cordless screwdriver', '', 'uploads/1578487249Tolsen Rechargeable Drill Machine  cordless screwdriver 1069-3.jpg', '', 0, '2020-01-08 18:40:49', '2020-01-08 18:40:49'),
(189, 'Professional Bluetooth Wireless Microphone Karaoke Speaker, Music Player Singing Recorder Handheld Microphone', '', 'uploads/1578487630Professional Bluetooth Wireless Microphone Karaoke Speaker, Music Player Singing Recorder Handheld Microphone 1070-1.jpg', '', 0, '2020-01-08 18:47:10', '2020-01-08 18:47:10'),
(190, 'Professional Bluetooth Wireless Microphone Karaoke Speaker, Music Player Singing Recorder Handheld Microphone', '', 'uploads/1578487630Professional Bluetooth Wireless Microphone Karaoke Speaker, Music Player Singing Recorder Handheld Microphone 1070-4.jpg', '', 0, '2020-01-08 18:47:10', '2020-01-08 18:47:10'),
(191, 'Professional Bluetooth Wireless Microphone Karaoke Speaker, Music Player Singing Recorder Handheld Microphone', '', 'uploads/1578487630Professional Bluetooth Wireless Microphone Karaoke Speaker, Music Player Singing Recorder Handheld Microphone 1070-3.jpg', '', 0, '2020-01-08 18:47:10', '2020-01-08 18:47:10'),
(192, 'U-shaped Neck Massage Pillow, electric Battery Operated Vibrating Ergonomic Neck & Head Rest Massager Health Care Tools', '', 'uploads/1578487702U-shaped Neck Massage Pillow, electric Battery Operated Vibrating Ergonomic Neck & Head Rest Massager Health Care Tools 1072-2.jpg', '', 0, '2020-01-08 18:48:22', '2020-01-08 18:48:22'),
(193, 'U-shaped Neck Massage Pillow, electric Battery Operated Vibrating Ergonomic Neck & Head Rest Massager Health Care Tools', '', 'uploads/1578487702U-shaped Neck Massage Pillow, electric Battery Operated Vibrating Ergonomic Neck & Head Rest Massager Health Care Tools 1072-1.jpg', '', 0, '2020-01-08 18:48:22', '2020-01-08 18:48:22'),
(194, 'Electronics Mosquito Killer Lamp LED Electric Bug Zapper Lamp Anti Mosquito Repeller Electronic Mosquito Trap Killer', '', 'uploads/1578487806Electronics Mosquito Killer Lamp LED Electric Bug Zapper Lamp Anti Mosquito Repeller Electronic Mosquito Trap Killer 1073-2.jpg', '', 0, '2020-01-08 18:50:06', '2020-01-08 18:50:06'),
(195, 'Electronics Mosquito Killer Lamp LED Electric Bug Zapper Lamp Anti Mosquito Repeller Electronic Mosquito Trap Killer', '', 'uploads/1578487806Electronics Mosquito Killer Lamp LED Electric Bug Zapper Lamp Anti Mosquito Repeller Electronic Mosquito Trap Killer 1073-5.jpg', '', 0, '2020-01-08 18:50:06', '2020-01-08 18:50:06'),
(196, 'Electronics Mosquito Killer Lamp LED Electric Bug Zapper Lamp Anti Mosquito Repeller Electronic Mosquito Trap Killer', '', 'uploads/1578487806Electronics Mosquito Killer Lamp LED Electric Bug Zapper Lamp Anti Mosquito Repeller Electronic Mosquito Trap Killer 1073-1.jpg', '', 0, '2020-01-08 18:50:06', '2020-01-08 18:50:06'),
(197, 'Electronics Mosquito Killer Lamp LED Electric Bug Zapper Lamp Anti Mosquito Repeller Electronic Mosquito Trap Killer', '', 'uploads/1578487806Electronics Mosquito Killer Lamp LED Electric Bug Zapper Lamp Anti Mosquito Repeller Electronic Mosquito Trap Killer 1073-8.jpg', '', 0, '2020-01-08 18:50:06', '2020-01-08 18:50:06'),
(198, 'Cordless Motion Sensor Light Wireless Infrared Motion Activated Sensor Light 360 Degree Rotation Motion Wall Lamp Outdoor Lights', '', 'uploads/1578487940Cordless Motion Sensor Light Wireless Infrared Motion Activated Sensor Light 360 Degree Rotation Motion Wall Lamp Outdoor Lights 1074-2.jpg', '', 0, '2020-01-08 18:52:20', '2020-01-08 18:52:20'),
(199, 'Cordless Motion Sensor Light Wireless Infrared Motion Activated Sensor Light 360 Degree Rotation Motion Wall Lamp Outdoor Lights', '', 'uploads/1578487940Cordless Motion Sensor Light Wireless Infrared Motion Activated Sensor Light 360 Degree Rotation Motion Wall Lamp Outdoor Lights 1074-1.jpg', '', 0, '2020-01-08 18:52:20', '2020-01-08 18:52:20'),
(200, 'Cordless Motion Sensor Light Wireless Infrared Motion Activated Sensor Light 360 Degree Rotation Motion Wall Lamp Outdoor Lights', '', 'uploads/1578487940Cordless Motion Sensor Light Wireless Infrared Motion Activated Sensor Light 360 Degree Rotation Motion Wall Lamp Outdoor Lights 1074-5.jpg', '', 0, '2020-01-08 18:52:20', '2020-01-08 18:52:20'),
(201, 'Cordless Motion Sensor Light Wireless Infrared Motion Activated Sensor Light 360 Degree Rotation Motion Wall Lamp Outdoor Lights', '', 'uploads/1578487940Cordless Motion Sensor Light Wireless Infrared Motion Activated Sensor Light 360 Degree Rotation Motion Wall Lamp Outdoor Lights 1074-3.jpg', '', 0, '2020-01-08 18:52:20', '2020-01-08 18:52:20'),
(202, 'Nima Electric Spice Grinder', '', 'uploads/1578488024Nima Electric Spice Grinder 1075-2.jpg', '', 0, '2020-01-08 18:53:44', '2020-01-08 18:53:44'),
(203, 'Nima Electric Spice Grinder', '', 'uploads/1578488024Nima Electric Spice Grinder 1075-1.jpg', '', 0, '2020-01-08 18:53:44', '2020-01-08 18:53:44'),
(204, '24 LED IR Color CMOS Loop Recording CCTV Security Camera TV Out Remote Control', '', 'uploads/157848812024 LED IR Color CMOS Loop Recording CCTV Security Camera TV Out Remote Control 1076-4.jpg', '', 0, '2020-01-08 18:55:20', '2020-01-08 18:55:20'),
(205, '24 LED IR Color CMOS Loop Recording CCTV Security Camera TV Out Remote Control', '', 'uploads/157848812024 LED IR Color CMOS Loop Recording CCTV Security Camera TV Out Remote Control 1076-1.jpg', '', 0, '2020-01-08 18:55:20', '2020-01-08 18:55:20'),
(206, '24 LED IR Color CMOS Loop Recording CCTV Security Camera TV Out Remote Control', '', 'uploads/157848812024 LED IR Color CMOS Loop Recording CCTV Security Camera TV Out Remote Control 1076-3.jpg', '', 0, '2020-01-08 18:55:20', '2020-01-08 18:55:20'),
(207, 'Portable Mini Refillable Perfume Bottle With Spray Scent Pump / Empty Cosmetic Containers Spray Atomizer Bottle For Travel 5ml', '', 'uploads/1578488744Portable Mini Refillable Perfume Bottle With Spray Scent Pump  Empty Cosmetic Containers Spray Atomizer Bottle For Travel 5ml 1077-4.jpg', '', 0, '2020-01-08 19:05:44', '2020-01-08 19:05:44'),
(208, 'Portable Mini Refillable Perfume Bottle With Spray Scent Pump / Empty Cosmetic Containers Spray Atomizer Bottle For Travel 5ml', '', 'uploads/1578488744Portable Mini Refillable Perfume Bottle With Spray Scent Pump  Empty Cosmetic Containers Spray Atomizer Bottle For Travel 5ml 1077-2.jpg', '', 0, '2020-01-08 19:05:44', '2020-01-08 19:05:44'),
(209, 'Portable Mini Refillable Perfume Bottle With Spray Scent Pump / Empty Cosmetic Containers Spray Atomizer Bottle For Travel 5ml', '', 'uploads/1578488744Portable Mini Refillable Perfume Bottle With Spray Scent Pump  Empty Cosmetic Containers Spray Atomizer Bottle For Travel 5ml 1077-3.jpg', '', 0, '2020-01-08 19:05:44', '2020-01-08 19:05:44'),
(210, 'Credit card holder', '', 'uploads/1578488828Credit card holder 1078-2.jpg', '', 0, '2020-01-08 19:07:08', '2020-01-08 19:07:08'),
(211, 'Credit card holder', '', 'uploads/1578488828Credit card holder 1078-1.jpg', '', 0, '2020-01-08 19:07:08', '2020-01-08 19:07:08'),
(212, 'Credit card holder', '', 'uploads/1578488828Credit card holder 1078-3.jpg', '', 0, '2020-01-08 19:07:08', '2020-01-08 19:07:08'),
(213, 'Baby Bouncer - Newborn Baby Rocking Chair Multi-range Adjustment 0-2 yeaars Old', '', 'uploads/1578488947Baby Bouncer - Newborn Baby Rocking Chair Multi-range Adjustment 0-2 yeaars Old 1079-1.jpg', '', 0, '2020-01-08 19:09:07', '2020-01-08 19:09:07'),
(214, 'Baby Bouncer - Newborn Baby Rocking Chair Multi-range Adjustment 0-2 yeaars Old', '', 'uploads/1578488947Baby Bouncer - Newborn Baby Rocking Chair Multi-range Adjustment 0-2 yeaars Old 1079-2.jpg', '', 0, '2020-01-08 19:09:07', '2020-01-08 19:09:07'),
(215, 'Baby Bouncer - Newborn Baby Rocking Chair Multi-range Adjustment 0-2 yeaars Old', '', 'uploads/1578488947Baby Bouncer - Newborn Baby Rocking Chair Multi-range Adjustment 0-2 yeaars Old 1079-4.jpg', '', 0, '2020-01-08 19:09:07', '2020-01-08 19:09:07'),
(216, '3 IN 1 Round Mandoline Slicer Vegetable Cutter Cheese Grater Nut Chopper Grinder Salad Shooter Vegetable Slicer with a Stainless Steel peeler', '', 'uploads/15784890703 IN 1 Round Mandoline Slicer Vegetable Cutter Cheese Grater Nut Chopper Grinder Salad Shooter Vegetable Slicer with a Stainless Steel peeler 1080-1.jpg', '', 0, '2020-01-08 19:11:10', '2020-01-08 19:11:10'),
(217, '3 IN 1 Round Mandoline Slicer Vegetable Cutter Cheese Grater Nut Chopper Grinder Salad Shooter Vegetable Slicer with a Stainless Steel peeler', '', 'uploads/15784890703 IN 1 Round Mandoline Slicer Vegetable Cutter Cheese Grater Nut Chopper Grinder Salad Shooter Vegetable Slicer with a Stainless Steel peeler 1080-2.jpg', '', 0, '2020-01-08 19:11:10', '2020-01-08 19:11:10'),
(218, '3 IN 1 Round Mandoline Slicer Vegetable Cutter Cheese Grater Nut Chopper Grinder Salad Shooter Vegetable Slicer with a Stainless Steel peeler', '', 'uploads/15784890703 IN 1 Round Mandoline Slicer Vegetable Cutter Cheese Grater Nut Chopper Grinder Salad Shooter Vegetable Slicer with a Stainless Steel peeler 1080-3.jpg', '', 0, '2020-01-08 19:11:10', '2020-01-08 19:11:10'),
(219, 'Panasonic Boom Microphone Unidirectional Microphone EM-2800A Microphone for Youtubing', '', 'uploads/1578489393Panasonic Boom Microphone Unidirectional Microphone EM-2800A Microphone for Youtubing 1082-1.jpg', '', 0, '2020-01-08 19:16:33', '2020-01-08 19:16:33'),
(220, 'Panasonic Boom Microphone Unidirectional Microphone EM-2800A Microphone for Youtubing', '', 'uploads/1578489394Panasonic Boom Microphone Unidirectional Microphone EM-2800A Microphone for Youtubing 1082-2.jpg', '', 0, '2020-01-08 19:16:34', '2020-01-08 19:16:34'),
(221, 'Panasonic Boom Microphone Unidirectional Microphone EM-2800A Microphone for Youtubing', '', 'uploads/1578489394Panasonic Boom Microphone Unidirectional Microphone EM-2800A Microphone for Youtubing 1082-3.jpg', '', 0, '2020-01-08 19:16:34', '2020-01-08 19:16:34'),
(222, 'Clip Microphone BOYA BY-M1 Directional Lavalier Microphone for iPhone Android Mac Vlog Mic for DSLR Camera Camcorder Recorder Boya M1', '', 'uploads/1578489510Clip Microphone BOYA BY-M1 Directional Lavalier Microphone for iPhone Android Mac Vlog Mic for DSLR Camera Camcorder Recorder Boya M1 1083-1.jpg', '', 0, '2020-01-08 19:18:30', '2020-01-08 19:18:30'),
(223, 'Clip Microphone BOYA BY-M1 Directional Lavalier Microphone for iPhone Android Mac Vlog Mic for DSLR Camera Camcorder Recorder Boya M1', '', 'uploads/1578489510Clip Microphone BOYA BY-M1 Directional Lavalier Microphone for iPhone Android Mac Vlog Mic for DSLR Camera Camcorder Recorder Boya M1 1083-2.jpg', '', 0, '2020-01-08 19:18:30', '2020-01-08 19:18:30'),
(224, 'Clip Microphone BOYA BY-M1 Directional Lavalier Microphone for iPhone Android Mac Vlog Mic for DSLR Camera Camcorder Recorder Boya M1', '', 'uploads/1578489510Clip Microphone BOYA BY-M1 Directional Lavalier Microphone for iPhone Android Mac Vlog Mic for DSLR Camera Camcorder Recorder Boya M1 1083-3.jpg', '', 0, '2020-01-08 19:18:30', '2020-01-08 19:18:30'),
(225, 'Electric Knife Sharpener Swifty Sharp Motorized Knife Sharpener Rotating Sharpening Stone Sharpening Tool', '', 'uploads/1578489582Electric Knife Sharpener Swifty Sharp Motorized Knife Sharpener Rotating Sharpening Stone Sharpening Tool 1084-2.jpg', '', 0, '2020-01-08 19:19:42', '2020-01-08 19:19:42'),
(226, 'Electric Knife Sharpener Swifty Sharp Motorized Knife Sharpener Rotating Sharpening Stone Sharpening Tool', '', 'uploads/1578489582Electric Knife Sharpener Swifty Sharp Motorized Knife Sharpener Rotating Sharpening Stone Sharpening Tool 1084-1.jpg', '', 0, '2020-01-08 19:19:42', '2020-01-08 19:19:42'),
(227, 'Electric Knife Sharpener Swifty Sharp Motorized Knife Sharpener Rotating Sharpening Stone Sharpening Tool', '', 'uploads/1578489582Electric Knife Sharpener Swifty Sharp Motorized Knife Sharpener Rotating Sharpening Stone Sharpening Tool 1084-3.jpg', '', 0, '2020-01-08 19:19:42', '2020-01-08 19:19:42'),
(228, 'Mini Portable Car Fire Extinguisher with Hook Dry Chemical Fire Extinguisher Safety Flame Fighter for Home Office Car Fire Stop', '', 'uploads/1578489671Mini Portable Car Fire Extinguisher with Hook Dry Chemical Fire Extinguisher Safety Flame Fighter for Home Office Car Fire Stop 1088-2.jpg', '', 0, '2020-01-08 19:21:11', '2020-01-08 19:21:11'),
(229, 'Mini Portable Car Fire Extinguisher with Hook Dry Chemical Fire Extinguisher Safety Flame Fighter for Home Office Car Fire Stop', '', 'uploads/1578489671Mini Portable Car Fire Extinguisher with Hook Dry Chemical Fire Extinguisher Safety Flame Fighter for Home Office Car Fire Stop 1088-3.jpg', '', 0, '2020-01-08 19:21:11', '2020-01-08 19:21:11'),
(230, 'Mini Portable Car Fire Extinguisher with Hook Dry Chemical Fire Extinguisher Safety Flame Fighter for Home Office Car Fire Stop', '', 'uploads/1578489671Mini Portable Car Fire Extinguisher with Hook Dry Chemical Fire Extinguisher Safety Flame Fighter for Home Office Car Fire Stop 1088-4.jpg', '', 0, '2020-01-08 19:21:11', '2020-01-08 19:21:11'),
(231, 'Rechargeable Electric portable Juicer portable Smoothie Maker - Blender Machine', '', 'uploads/1578489791Rechargeable Electric portable Juicer portable Smoothie Maker - Blender Machine 1092-3.jpg', '', 0, '2020-01-08 19:23:11', '2020-01-08 19:23:11'),
(232, 'Rechargeable Electric portable Juicer portable Smoothie Maker - Blender Machine', '', 'uploads/1578489791Rechargeable Electric portable Juicer portable Smoothie Maker - Blender Machine 1092-.jpg', '', 0, '2020-01-08 19:23:11', '2020-01-08 19:23:11'),
(233, 'Rechargeable Electric portable Juicer portable Smoothie Maker - Blender Machine', '', 'uploads/1578489791Rechargeable Electric portable Juicer portable Smoothie Maker - Blender Machine 1092-2.jpg', '', 0, '2020-01-08 19:23:11', '2020-01-08 19:23:11'),
(234, 'Rechargeable Electric portable Juicer portable Smoothie Maker - Blender Machine', '', 'uploads/1578489791Rechargeable Electric portable Juicer portable Smoothie Maker - Blender Machine 1092-1.jpg', '', 0, '2020-01-08 19:23:11', '2020-01-08 19:23:11'),
(235, 'Rechareable Callous Remover / Electric Foot Care Tool Grinding Pedicure Kit', '', 'uploads/1578489908Rechareable Callous Remover  Electric Foot Care Tool Grinding Pedicure Kit 1093-1.jpg', '', 0, '2020-01-08 19:25:08', '2020-01-08 19:25:08'),
(236, 'Rechareable Callous Remover / Electric Foot Care Tool Grinding Pedicure Kit', '', 'uploads/1578489908Rechareable Callous Remover  Electric Foot Care Tool Grinding Pedicure Kit 1093-2.jpg', '', 0, '2020-01-08 19:25:08', '2020-01-08 19:25:08'),
(237, 'Rechareable Callous Remover / Electric Foot Care Tool Grinding Pedicure Kit', '', 'uploads/1578489908Rechareable Callous Remover  Electric Foot Care Tool Grinding Pedicure Kit 1093-3.jpg', '', 0, '2020-01-08 19:25:08', '2020-01-08 19:25:08'),
(238, 'Stainless Steel Easy to use Pineapple Corer Slicer Cutter Peeler Kitchen Tools', '', 'uploads/1578489991Stainless Steel Easy to use Pineapple Corer Slicer Cutter Peeler Kitchen Tools 1097-3.jpg', '', 0, '2020-01-08 19:26:31', '2020-01-08 19:26:31'),
(239, 'Stainless Steel Easy to use Pineapple Corer Slicer Cutter Peeler Kitchen Tools', '', 'uploads/1578489992Stainless Steel Easy to use Pineapple Corer Slicer Cutter Peeler Kitchen Tools 1097-2.jpg', '', 0, '2020-01-08 19:26:32', '2020-01-08 19:26:32'),
(240, 'Stainless Steel Easy to use Pineapple Corer Slicer Cutter Peeler Kitchen Tools', '', 'uploads/1578489992Stainless Steel Easy to use Pineapple Corer Slicer Cutter Peeler Kitchen Tools 1097-1.jpg', '', 0, '2020-01-08 19:26:32', '2020-01-08 19:26:32'),
(241, 'Havoc SILVER Deodorant Spray - For Men & Women  (200 ml)', '', 'uploads/1578490080Havoc SILVER Deodorant Spray - For Men & Women  (200 ml)  1098.jpg', '', 0, '2020-01-08 19:28:00', '2020-01-08 19:28:00'),
(242, 'Brut Original Deodorant Spray for Men - 200ml', '', 'uploads/1578490139Brut Original Deodorant Spray for Men - 200ml  1099.jpg', '', 0, '2020-01-08 19:28:59', '2020-01-08 19:28:59'),
(243, 'Brut Perfume Green Eau de Toilette - 100 ml  (For Men & Women)', '', 'uploads/1578490240Brut Perfume Green Eau de Toilette - 100 ml  (For Men & Women) 1100-2.jpg', '', 0, '2020-01-08 19:30:40', '2020-01-08 19:30:40'),
(244, 'Brut Perfume Green Eau de Toilette - 100 ml  (For Men & Women)', '', 'uploads/1578490240Brut Perfume Green Eau de Toilette - 100 ml  (For Men & Women) 1100-1.jpg', '', 0, '2020-01-08 19:30:40', '2020-01-08 19:30:40'),
(245, 'Wardrobe Cloth Storage Organizer, Portable Folding Fabric Wardrobe', '', 'uploads/15784903971109-2.jpg', '', 0, '2020-01-08 19:33:17', '2020-01-08 19:33:17'),
(246, 'Wardrobe Cloth Storage Organizer, Portable Folding Fabric Wardrobe', '', 'uploads/15784903971109-3.jpg', '', 0, '2020-01-08 19:33:17', '2020-01-08 19:33:17'),
(247, 'Wardrobe Cloth Storage Organizer, Portable Folding Fabric Wardrobe', '', 'uploads/15784903971109-1.jpg', '', 0, '2020-01-08 19:33:17', '2020-01-08 19:33:17'),
(248, 'High Quality Microwave Oven Storage Racks / Stainless Steel Adjustable Multi functional Microwave Oven Shelf Rack', '', 'uploads/1578490521High Quality Microwave Oven Storage Racks  Stainless Steel Adjustable Multifunctional Microwave Oven Shelf Rack 1110-1.jpg', '', 0, '2020-01-08 19:35:21', '2020-01-08 19:35:21'),
(249, 'High Quality Microwave Oven Storage Racks / Stainless Steel Adjustable Multi functional Microwave Oven Shelf Rack', '', 'uploads/1578490522High Quality Microwave Oven Storage Racks  Stainless Steel Adjustable Multifunctional Microwave Oven Shelf Rack 1110-2.jpg', '', 0, '2020-01-08 19:35:22', '2020-01-08 19:35:22'),
(250, 'High Quality Microwave Oven Storage Racks / Stainless Steel Adjustable Multi functional Microwave Oven Shelf Rack', '', 'uploads/1578490522High Quality Microwave Oven Storage Racks  Stainless Steel Adjustable Multifunctional Microwave Oven Shelf Rack 1110-4.jpg', '', 0, '2020-01-08 19:35:22', '2020-01-08 19:35:22'),
(251, 'Multi Functional Mobile Folding Racks Cloth Drying Rack', '', 'uploads/1578490616Multi Functional Mobile Folding Racks Cloth Drying Rack 1111-1.jpg', '', 0, '2020-01-08 19:36:56', '2020-01-08 19:36:56'),
(252, 'Multi Functional Mobile Folding Racks Cloth Drying Rack', '', 'uploads/1578490616Multi Functional Mobile Folding Racks Cloth Drying Rack 1111-3.jpg', '', 0, '2020-01-08 19:36:56', '2020-01-08 19:36:56'),
(253, 'Multi Functional Mobile Folding Racks Cloth Drying Rack', '', 'uploads/1578490616Multi Functional Mobile Folding Racks Cloth Drying Rack 1111-2.jpg', '', 0, '2020-01-08 19:36:56', '2020-01-08 19:36:56'),
(254, 'Egg Master Automatic Egg Roll Maker, New Electric Egg Boiler, Egg Omelette Master Sausage Machine Bottle-Shaped For Breakfast', '', 'uploads/1578490719Egg Master Automatic Egg Roll Maker, New Electric Egg Boiler, Egg Omelette Master Sausage Machine Bottle-Shaped For Breakfast 1112-2.jpg', '', 0, '2020-01-08 19:38:39', '2020-01-08 19:38:39'),
(255, 'Egg Master Automatic Egg Roll Maker, New Electric Egg Boiler, Egg Omelette Master Sausage Machine Bottle-Shaped For Breakfast', '', 'uploads/1578490719Egg Master Automatic Egg Roll Maker, New Electric Egg Boiler, Egg Omelette Master Sausage Machine Bottle-Shaped For Breakfast 1112-3.jpg', '', 0, '2020-01-08 19:38:39', '2020-01-08 19:38:39'),
(256, 'Egg Master Automatic Egg Roll Maker, New Electric Egg Boiler, Egg Omelette Master Sausage Machine Bottle-Shaped For Breakfast', '', 'uploads/1578490719Egg Master Automatic Egg Roll Maker, New Electric Egg Boiler, Egg Omelette Master Sausage Machine Bottle-Shaped For Breakfast 1112-1.jpg', '', 0, '2020-01-08 19:38:39', '2020-01-08 19:38:39'),
(257, 'Wardrobe Cloth Storage Organizer (Large Size) - Portable Folding Fabric Wardrobe', '', 'uploads/1578490814Wardrobe Cloth Storage Organizer (Large Size) - Portable Folding Fabric Wardrobe 1113-2.jpg', '', 0, '2020-01-08 19:40:14', '2020-01-08 19:40:14'),
(258, 'Wardrobe Cloth Storage Organizer (Large Size) - Portable Folding Fabric Wardrobe', '', 'uploads/1578490814Wardrobe Cloth Storage Organizer (Large Size) - Portable Folding Fabric Wardrobe 1113-3.jpg', '', 0, '2020-01-08 19:40:14', '2020-01-08 19:40:14'),
(259, 'Wardrobe Cloth Storage Organizer (Large Size) - Portable Folding Fabric Wardrobe', '', 'uploads/1578490814Wardrobe Cloth Storage Organizer (Large Size) - Portable Folding Fabric Wardrobe 1113-1.jpg', '', 0, '2020-01-08 19:40:14', '2020-01-08 19:40:14'),
(260, 'Air Dragon Portable Air Compressor Pumper', '', 'uploads/1578490873Air Dragon Portable Air Compressor Pumper 1114-3.jpg', '', 0, '2020-01-08 19:41:13', '2020-01-08 19:41:13'),
(261, 'Air Dragon Portable Air Compressor Pumper', '', 'uploads/1578490873Air Dragon Portable Air Compressor Pumper 1114-4.jpg', '', 0, '2020-01-08 19:41:13', '2020-01-08 19:41:13'),
(262, 'Mini Bluetooth Earphone Wireless Sports Headset Earpiece Headphone with Mic Handsfree For iPhone Samsung Xiaomi Huawei etc', '', 'uploads/1578490954Mini Bluetooth Earphone Wireless Sports Headset Earpiece Headphone with Mic Handsfree For iPhone Samsung Xiaomi Huawei etc 1115-2.jpg', '', 0, '2020-01-08 19:42:34', '2020-01-08 19:42:34'),
(263, 'Mini Bluetooth Earphone Wireless Sports Headset Earpiece Headphone with Mic Handsfree For iPhone Samsung Xiaomi Huawei etc', '', 'uploads/1578490954Mini Bluetooth Earphone Wireless Sports Headset Earpiece Headphone with Mic Handsfree For iPhone Samsung Xiaomi Huawei etc 1115-4.jpg', '', 0, '2020-01-08 19:42:34', '2020-01-08 19:42:34'),
(264, 'Mini Bluetooth Earphone Wireless Sports Headset Earpiece Headphone with Mic Handsfree For iPhone Samsung Xiaomi Huawei etc', '', 'uploads/1578490954Mini Bluetooth Earphone Wireless Sports Headset Earpiece Headphone with Mic Handsfree For iPhone Samsung Xiaomi Huawei etc 1115-1.jpg', '', 0, '2020-01-08 19:42:34', '2020-01-08 19:42:34'),
(265, 'Philips BT1210/15 Cordless Trimmer for Men, USB Charging Trimmer Rechargeable Beard Trimmer', '', 'uploads/1578493387Philips BT1210-15 Cordless Trimmer for Men, USB Charging Trimmer Rechargeable Beard Trimmer 1116-1.jpg', '', 0, '2020-01-08 20:23:07', '2020-01-08 20:23:07'),
(266, 'Philips BT1210/15 Cordless Trimmer for Men, USB Charging Trimmer Rechargeable Beard Trimmer', '', 'uploads/1578493387Philips BT1210-15 Cordless Trimmer for Men, USB Charging Trimmer Rechargeable Beard Trimmer 1116-2.jpg', '', 0, '2020-01-08 20:23:07', '2020-01-08 20:23:07'),
(267, 'Philips BT1210/15 Cordless Trimmer for Men, USB Charging Trimmer Rechargeable Beard Trimmer', '', 'uploads/1578493387Philips BT1210-15 Cordless Trimmer for Men, USB Charging Trimmer Rechargeable Beard Trimmer 1116-4.jpg', '', 0, '2020-01-08 20:23:07', '2020-01-08 20:23:07'),
(268, 'Original Magic Bullet - Hi-Speed Blender/Mixer System 21 Pcs Set', '', 'uploads/1578548779Original Magic Bullet - Hi-Speed BlenderMixer System 21 Pcs Set 1117-4.jpg', '', 0, '2020-01-09 11:46:19', '2020-01-09 11:46:19'),
(269, 'Original Magic Bullet - Hi-Speed Blender/Mixer System 21 Pcs Set', '', 'uploads/1578548779Original Magic Bullet - Hi-Speed BlenderMixer System 21 Pcs Set 1117-5.jpg', '', 0, '2020-01-09 11:46:19', '2020-01-09 11:46:19'),
(270, 'Original Magic Bullet - Hi-Speed Blender/Mixer System 21 Pcs Set', '', 'uploads/1578548779Original Magic Bullet - Hi-Speed BlenderMixer System 21 Pcs Set 1117-2.jpg', '', 0, '2020-01-09 11:46:19', '2020-01-09 11:46:19'),
(271, 'Android TV Box, X96 Mini Smart TV Box / 4K HD Smart Media Player', '', 'uploads/1578548864Android TV Box, X96 Mini Smart TV Box  4K HD Smart Media Player 1118-2.jpg', '', 0, '2020-01-09 11:47:44', '2020-01-09 11:47:44'),
(272, 'Android TV Box, X96 Mini Smart TV Box / 4K HD Smart Media Player', '', 'uploads/1578548864Android TV Box, X96 Mini Smart TV Box  4K HD Smart Media Player 1118-1.jpg', '', 0, '2020-01-09 11:47:44', '2020-01-09 11:47:44'),
(273, 'Android TV Box, X96 Mini Smart TV Box / 4K HD Smart Media Player', '', 'uploads/1578548864Android TV Box, X96 Mini Smart TV Box  4K HD Smart Media Player 1118-4.jpg', '', 0, '2020-01-09 11:47:44', '2020-01-09 11:47:44'),
(274, 'Hot Glue Gun, High Temperature Glue Gun for DIY Crafts, Projects, Fast Home Repairs & Creative Arts', '', 'uploads/1578549078Hot Glue Gun, High Temperature Glue Gun for DIY Crafts, Projects, Fast Home Repairs & Creative Arts 1119-6.jpg', '', 0, '2020-01-09 11:51:18', '2020-01-09 11:51:18'),
(275, 'Hot Glue Gun, High Temperature Glue Gun for DIY Crafts, Projects, Fast Home Repairs & Creative Arts', '', 'uploads/1578549078Hot Glue Gun, High Temperature Glue Gun for DIY Crafts, Projects, Fast Home Repairs & Creative Arts 1119-7.jpg', '', 0, '2020-01-09 11:51:18', '2020-01-09 11:51:18'),
(276, 'Hot Glue Gun, High Temperature Glue Gun for DIY Crafts, Projects, Fast Home Repairs & Creative Arts', '', 'uploads/1578549078Hot Glue Gun, High Temperature Glue Gun for DIY Crafts, Projects, Fast Home Repairs & Creative Arts 1119-5.jpg', '', 0, '2020-01-09 11:51:18', '2020-01-09 11:51:18'),
(277, '4 Grids Remote Control Holder Stand Organizer 4 grids Remote Control Storage Racks', '', 'uploads/15785491634 Grids Remote Control Holder Stand Organizer 4 grids Remote Control Storage Racks 1120-4.jpg', '', 0, '2020-01-09 11:52:43', '2020-01-09 11:52:43'),
(278, '4 Grids Remote Control Holder Stand Organizer 4 grids Remote Control Storage Racks', '', 'uploads/15785491634 Grids Remote Control Holder Stand Organizer 4 grids Remote Control Storage Racks 1120-3.jpg', '', 0, '2020-01-09 11:52:43', '2020-01-09 11:52:43'),
(279, '4 Grids Remote Control Holder Stand Organizer 4 grids Remote Control Storage Racks', '', 'uploads/15785491634 Grids Remote Control Holder Stand Organizer 4 grids Remote Control Storage Racks 1120-2.jpg', '', 0, '2020-01-09 11:52:43', '2020-01-09 11:52:43'),
(280, 'Rasasi Blue Lady Eau de Parfum - 40 ml (For Women)', '', 'uploads/1578549369Rasasi Blue Lady Eau de Parfum - 40 ml  (For Women) 1121-2.jpg', '', 0, '2020-01-09 11:56:09', '2020-01-09 11:56:09'),
(281, 'Rasasi Blue Lady Eau de Parfum - 40 ml (For Women)', '', 'uploads/1578549370Rasasi Blue Lady Eau de Parfum - 40 ml  (For Women) 1121-1.jpg', '', 0, '2020-01-09 11:56:10', '2020-01-09 11:56:10'),
(282, 'Rasasi Blue For Men EDP - Eau De Parfum 100ML ', '', 'uploads/1578549490Rasasi Blue For Men EDP - Eau De Parfum 100ML  1122-1.jpg', '', 0, '2020-01-09 11:58:10', '2020-01-09 11:58:10'),
(283, 'Rasasi Blue For Men EDP - Eau De Parfum 100ML ', '', 'uploads/1578549490Rasasi Blue For Men EDP - Eau De Parfum 100ML  1122-2.jpg', '', 0, '2020-01-09 11:58:10', '2020-01-09 11:58:10'),
(284, 'One Man Show Perfum For Men. Eau De Toilette Spray 100ml', '', 'uploads/1578549558One Man Show Perfum For Men. Eau De Toilette Spray 100ml 1123-2.jpg', '', 0, '2020-01-09 11:59:18', '2020-01-09 11:59:18'),
(285, 'One Man Show Perfum For Men. Eau De Toilette Spray 100ml', '', 'uploads/1578549558One Man Show Perfum For Men. Eau De Toilette Spray 100ml 1123-1.jpg', '', 0, '2020-01-09 11:59:18', '2020-01-09 11:59:18'),
(286, 'Carry Furnishings Easier  Furniture Carry Tools Useful Lifting Moving Strap Furniture Transport Belt In Shoulder Straps Team Straps Mover Conveying carry furnishing easier', '', 'uploads/1578549646Carry Furnishings Easier  Furniture Carry Tools Useful Lifting Moving Strap Furniture Transport Belt In Shoulder Straps Team Straps Mover Conveying carry furnishing easier 1124-3.jpg', '', 0, '2020-01-09 12:00:46', '2020-01-09 12:00:46'),
(287, 'Carry Furnishings Easier  Furniture Carry Tools Useful Lifting Moving Strap Furniture Transport Belt In Shoulder Straps Team Straps Mover Conveying carry furnishing easier', '', 'uploads/1578549647Carry Furnishings Easier  Furniture Carry Tools Useful Lifting Moving Strap Furniture Transport Belt In Shoulder Straps Team Straps Mover Conveying carry furnishing easier 1124-4.jpg', '', 0, '2020-01-09 12:00:47', '2020-01-09 12:00:47'),
(288, 'Carry Furnishings Easier  Furniture Carry Tools Useful Lifting Moving Strap Furniture Transport Belt In Shoulder Straps Team Straps Mover Conveying carry furnishing easier', '', 'uploads/1578549647Carry Furnishings Easier  Furniture Carry Tools Useful Lifting Moving Strap Furniture Transport Belt In Shoulder Straps Team Straps Mover Conveying carry furnishing easier 1124-2.jpg', '', 0, '2020-01-09 12:00:47', '2020-01-09 12:00:47'),
(289, 'Automatic Self Stirring Coffee Mug Stainless Steel 400ml coffee mug, Home Office Smart Mixer Cup', '', 'uploads/1578549731Automatic Self Stirring Coffee Mug Stainless Steel 400ml coffee mug, Home Office Smart Mixer Cup 1125-2.jpg', '', 0, '2020-01-09 12:02:11', '2020-01-09 12:02:11'),
(290, 'Automatic Self Stirring Coffee Mug Stainless Steel 400ml coffee mug, Home Office Smart Mixer Cup', '', 'uploads/1578549731Automatic Self Stirring Coffee Mug Stainless Steel 400ml coffee mug, Home Office Smart Mixer Cup 1125-3.jpg', '', 0, '2020-01-09 12:02:11', '2020-01-09 12:02:11'),
(291, 'Automatic Self Stirring Coffee Mug Stainless Steel 400ml coffee mug, Home Office Smart Mixer Cup', '', 'uploads/1578549731Automatic Self Stirring Coffee Mug Stainless Steel 400ml coffee mug, Home Office Smart Mixer Cup 1125-1.jpg', '', 0, '2020-01-09 12:02:11', '2020-01-09 12:02:11'),
(292, 'Portable Medicine Box 14/7 Grids 7 Days Medicine Storage Container Weekly Medicine Organizer', '', 'uploads/1578549824Portable Medicine Box 147 Grids 7 Days Medicine Storage Container Weekly Medicine Organizer 1126-1.jpg', '', 0, '2020-01-09 12:03:44', '2020-01-09 12:03:44'),
(293, 'Portable Medicine Box 14/7 Grids 7 Days Medicine Storage Container Weekly Medicine Organizer', '', 'uploads/1578549824Portable Medicine Box 147 Grids 7 Days Medicine Storage Container Weekly Medicine Organizer 1126-2.jpg', '', 0, '2020-01-09 12:03:44', '2020-01-09 12:03:44'),
(294, 'Backlit wireless Mini Keyboard Controller With Touchpad Mouse, Mini Keyboard for android TV Box', '', 'uploads/1578549927Backlit wireless Mini Keyboard Controller With Touchpad Mouse, Mini Keyboard for android TV Box 1127-5.jpg', '', 0, '2020-01-09 12:05:27', '2020-01-09 12:05:27'),
(295, 'Backlit wireless Mini Keyboard Controller With Touchpad Mouse, Mini Keyboard for android TV Box', '', 'uploads/1578549927Backlit wireless Mini Keyboard Controller With Touchpad Mouse, Mini Keyboard for android TV Box 1127-6.jpg', '', 0, '2020-01-09 12:05:27', '2020-01-09 12:05:27'),
(296, 'Backlit wireless Mini Keyboard Controller With Touchpad Mouse, Mini Keyboard for android TV Box', '', 'uploads/1578549927Backlit wireless Mini Keyboard Controller With Touchpad Mouse, Mini Keyboard for android TV Box 1127-2.jpg', '', 0, '2020-01-09 12:05:27', '2020-01-09 12:05:27'),
(297, 'Capsule Cutter with super fast motor ideal kitchen tool for slicing boneless meat, vegetable, fruit salads, onion and garlic, cutting various foods for baby, chopping herbs', '', 'uploads/1578550046Capsule Cutter with super fast motor idel kitchen tool for slicing boneless meat, vegetable, fruit salads, onion and garlic, cutting various foods for baby, chopping herbs 1129-4.jpg', '', 0, '2020-01-09 12:07:26', '2020-01-09 12:07:26'),
(298, 'Capsule Cutter with super fast motor ideal kitchen tool for slicing boneless meat, vegetable, fruit salads, onion and garlic, cutting various foods for baby, chopping herbs', '', 'uploads/1578550046Capsule Cutter with super fast motor idel kitchen tool for slicing boneless meat, vegetable, fruit salads, onion and garlic, cutting various foods for baby, chopping herbs 1129-1.jpg', '', 0, '2020-01-09 12:07:26', '2020-01-09 12:07:26'),
(299, 'Capsule Cutter with super fast motor ideal kitchen tool for slicing boneless meat, vegetable, fruit salads, onion and garlic, cutting various foods for baby, chopping herbs', '', 'uploads/1578550046Capsule Cutter with super fast motor idel kitchen tool for slicing boneless meat, vegetable, fruit salads, onion and garlic, cutting various foods for baby, chopping herbs 1129-3.jpg', '', 0, '2020-01-09 12:07:26', '2020-01-09 12:07:26'),
(300, 'Capsule Cutter with super fast motor ideal kitchen tool for slicing boneless meat, vegetable, fruit salads, onion and garlic, cutting various foods for baby, chopping herbs', '', 'uploads/1578550046Capsule Cutter with super fast motor idel kitchen tool for slicing boneless meat, vegetable, fruit salads, onion and garlic, cutting various foods for baby, chopping herbs 1129-2.jpg', '', 0, '2020-01-09 12:07:26', '2020-01-09 12:07:26'),
(301, 'Foldable Silicone electric water heater kettle for outdoor travel home Camping', '', 'uploads/1578550160Foldable Silicone electric water heater kettle for outdoor travel home Camping 1130-2.jpg', '', 0, '2020-01-09 12:09:20', '2020-01-09 12:09:20'),
(302, 'Foldable Silicone electric water heater kettle for outdoor travel home Camping', '', 'uploads/1578550160Foldable Silicone electric water heater kettle for outdoor travel home Camping 1130-3.jpg', '', 0, '2020-01-09 12:09:20', '2020-01-09 12:09:20'),
(303, 'Foldable Silicone electric water heater kettle for outdoor travel home Camping', '', 'uploads/1578550160Foldable Silicone electric water heater kettle for outdoor travel home Camping 1130-1.jpg', '', 0, '2020-01-09 12:09:20', '2020-01-09 12:09:20'),
(304, 'AnyCast M2 Plus Wireless WiFi Display Dongle Receiver 1080P HD Interface TV Stick, HDMI Dongle', '', 'uploads/1578550239AnyCast M2 Plus Wireless WiFi Display Dongle Receiver 1080P HD Interface TV Stick, HDMI Dongle 1131-2.jpg', '', 0, '2020-01-09 12:10:39', '2020-01-09 12:10:39'),
(305, 'AnyCast M2 Plus Wireless WiFi Display Dongle Receiver 1080P HD Interface TV Stick, HDMI Dongle', '', 'uploads/1578550239AnyCast M2 Plus Wireless WiFi Display Dongle Receiver 1080P HD Interface TV Stick, HDMI Dongle 1131-1.jpg', '', 0, '2020-01-09 12:10:39', '2020-01-09 12:10:39'),
(306, 'AnyCast M2 Plus Wireless WiFi Display Dongle Receiver 1080P HD Interface TV Stick, HDMI Dongle', '', 'uploads/1578550239AnyCast M2 Plus Wireless WiFi Display Dongle Receiver 1080P HD Interface TV Stick, HDMI Dongle 1131-3.jpg', '', 0, '2020-01-09 12:10:39', '2020-01-09 12:10:39'),
(307, '5pcs Professional Paint Roller Brush For Room Wall Painting Edge Painting Decorative Multifunctional Paint Roller Brush Set', '', 'uploads/15785503815pcs Professional Paint Roller Brush For Room Wall Painting Edge Painting Decorative Multifunctional Paint Roller Brush Set 1132-1.jpg', '', 0, '2020-01-09 12:13:01', '2020-01-09 12:13:01'),
(308, '5pcs Professional Paint Roller Brush For Room Wall Painting Edge Painting Decorative Multifunctional Paint Roller Brush Set', '', 'uploads/15785503815pcs Professional Paint Roller Brush For Room Wall Painting Edge Painting Decorative Multifunctional Paint Roller Brush Set 1132-3.jpg', '', 0, '2020-01-09 12:13:01', '2020-01-09 12:13:01'),
(309, '5pcs Professional Paint Roller Brush For Room Wall Painting Edge Painting Decorative Multifunctional Paint Roller Brush Set', '', 'uploads/15785503815pcs Professional Paint Roller Brush For Room Wall Painting Edge Painting Decorative Multifunctional Paint Roller Brush Set 1132-5.jpg', '', 0, '2020-01-09 12:13:01', '2020-01-09 12:13:01'),
(310, '5pcs Professional Paint Roller Brush For Room Wall Painting Edge Painting Decorative Multifunctional Paint Roller Brush Set', '', 'uploads/15785503815pcs Professional Paint Roller Brush For Room Wall Painting Edge Painting Decorative Multifunctional Paint Roller Brush Set 1132-2.jpg', '', 0, '2020-01-09 12:13:01', '2020-01-09 12:13:01'),
(311, '360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box (Black)', '', 'uploads/1578550578360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box 1133-3.jpg', '', 0, '2020-01-09 12:16:18', '2020-01-09 12:16:18'),
(312, '360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box (Black)', '', 'uploads/1578550578360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box 1133-1.jpg', '', 0, '2020-01-09 12:16:18', '2020-01-09 12:16:18'),
(313, '360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box (Black)', '', 'uploads/1578550578360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box 1133-4.jpg', '', 0, '2020-01-09 12:16:18', '2020-01-09 12:16:18'),
(314, '360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box (White)', '', 'uploads/1578550665360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box 1133-10.jpg', '', 0, '2020-01-09 12:17:45', '2020-01-09 12:17:45'),
(315, '360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box (White)', '', 'uploads/1578550665360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box 1133-11.jpg', '', 0, '2020-01-09 12:17:45', '2020-01-09 12:17:45'),
(316, '360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box (White)', '', 'uploads/1578550665360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box 1133-12.jpg', '', 0, '2020-01-09 12:17:45', '2020-01-09 12:17:45'),
(317, '360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box (Pink)', '', 'uploads/1578550749360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box 1133-5.jpg', '', 0, '2020-01-09 12:19:09', '2020-01-09 12:19:09'),
(318, '360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box (Pink)', '', 'uploads/1578550749360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box 1133-8.jpg', '', 0, '2020-01-09 12:19:09', '2020-01-09 12:19:09'),
(319, '360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box (Pink)', '', 'uploads/1578550749360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box 1133-7.jpg', '', 0, '2020-01-09 12:19:09', '2020-01-09 12:19:09'),
(320, '360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box (Pink)', '', 'uploads/1578550749360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box 1133-6.jpg', '', 0, '2020-01-09 12:19:09', '2020-01-09 12:19:09'),
(321, 'Portable Electric BBQ Stove - Smokeless Electric Pan Grill, Barbecue machine with 5 Temperature Mode for Home Camping', '', 'uploads/1578550863Portable Electric BBQ Stove - Smokeless Electric Pan Grill, Barbecue machine with 5 Temperature Mode for Home Camping 1134-1.jpg', '', 0, '2020-01-09 12:21:03', '2020-01-09 12:21:03'),
(322, 'Portable Electric BBQ Stove - Smokeless Electric Pan Grill, Barbecue machine with 5 Temperature Mode for Home Camping', '', 'uploads/1578550863Portable Electric BBQ Stove - Smokeless Electric Pan Grill, Barbecue machine with 5 Temperature Mode for Home Camping 1134-3.jpg', '', 0, '2020-01-09 12:21:03', '2020-01-09 12:21:03'),
(323, 'Portable Electric BBQ Stove - Smokeless Electric Pan Grill, Barbecue machine with 5 Temperature Mode for Home Camping', '', 'uploads/1578550863Portable Electric BBQ Stove - Smokeless Electric Pan Grill, Barbecue machine with 5 Temperature Mode for Home Camping 1134-2.jpg', '', 0, '2020-01-09 12:21:03', '2020-01-09 12:21:03'),
(324, 'Stainless Steel Adjustable Clothes Hanger Rack- Double Rail Clothes Rack Adjustable Height Rolling Garment Rack Stainless Steel 2 Shelf Pole Clothes Hanger Freestanding Organizer', '', 'uploads/1578551078Stainless Steel Adjustable Clothes Hanger Rack- Double Rail Clothes Rack Adjustable Height Rolling Garment Rack Stainless Steel 2 Shelf Pole Clothes Hanger Freestanding Organizer 1135-1.jpg', '', 0, '2020-01-09 12:24:38', '2020-01-09 12:24:38'),
(325, 'Stainless Steel Adjustable Clothes Hanger Rack- Double Rail Clothes Rack Adjustable Height Rolling Garment Rack Stainless Steel 2 Shelf Pole Clothes Hanger Freestanding Organizer', '', 'uploads/1578551078Stainless Steel Adjustable Clothes Hanger Rack- Double Rail Clothes Rack Adjustable Height Rolling Garment Rack Stainless Steel 2 Shelf Pole Clothes Hanger Freestanding Organizer 1135-2.jpg', '', 0, '2020-01-09 12:24:38', '2020-01-09 12:24:38'),
(326, 'Mini Sewing Machine, Portable Electric Double Speed Sewing Machine with Foot Pedal Power Supply for Household Travel and Beginner - Stitch Set 16', '', 'uploads/1578551343Mini Sewing Machine, Portable Electric Double Speed Sewing Machine with Foot Pedal Power Supply for Household Travel and Beginner - Stitch Set 16 1136-2.jpg', '', 0, '2020-01-09 12:29:03', '2020-01-09 12:29:03'),
(327, 'Mini Sewing Machine, Portable Electric Double Speed Sewing Machine with Foot Pedal Power Supply for Household Travel and Beginner - Stitch Set 16', '', 'uploads/1578551343Mini Sewing Machine, Portable Electric Double Speed Sewing Machine with Foot Pedal Power Supply for Household Travel and Beginner - Stitch Set 16 1136-3.jpg', '', 0, '2020-01-09 12:29:03', '2020-01-09 12:29:03'),
(328, 'Mini Sewing Machine, Portable Electric Double Speed Sewing Machine with Foot Pedal Power Supply for Household Travel and Beginner - Stitch Set 16', '', 'uploads/1578551343Mini Sewing Machine, Portable Electric Double Speed Sewing Machine with Foot Pedal Power Supply for Household Travel and Beginner - Stitch Set 16 1136-1.jpg', '', 0, '2020-01-09 12:29:03', '2020-01-09 12:29:03'),
(329, 'Electric Indoor Insect Mosquito Killer, UV LED Light Fly Zapper, Indoor Fly Catcher, Insect Trap Lamp, for Residential, Commercial and Industrial Use', '', 'uploads/1578551413Electric Indoor Insect Mosquito Killer, UV LED Light Fly Zapper, Indoor Fly Catcher, Insect Trap Lamp, for Residential, Commercial and Industrial Use 1137-2.jpg', '', 0, '2020-01-09 12:30:13', '2020-01-09 12:30:13'),
(330, 'Electric Indoor Insect Mosquito Killer, UV LED Light Fly Zapper, Indoor Fly Catcher, Insect Trap Lamp, for Residential, Commercial and Industrial Use', '', 'uploads/1578551413Electric Indoor Insect Mosquito Killer, UV LED Light Fly Zapper, Indoor Fly Catcher, Insect Trap Lamp, for Residential, Commercial and Industrial Use 1137-1.jpg', '', 0, '2020-01-09 12:30:13', '2020-01-09 12:30:13'),
(331, 'Electric Indoor Insect Mosquito Killer, UV LED Light Fly Zapper, Indoor Fly Catcher, Insect Trap Lamp, for Residential, Commercial and Industrial Use (Small)', '', 'uploads/1578551550Electric Indoor Insect Mosquito Killer, UV LED Light Fly Zapper, Indoor Fly Catcher, Insect Trap Lamp, for Residential, Commercial and Industrial Use 1137-2.jpg', '', 0, '2020-01-09 12:32:30', '2020-01-09 12:32:30'),
(332, 'Kitchen Stainless Steel Garlic Press Crusher Home Kitchen Mincer Tool', '', 'uploads/1578551680Kitchen Stainless Steel Garlic Press Crusher Home Kitchen Mincer Tool 1139-2.jpg', '', 0, '2020-01-09 12:34:40', '2020-01-09 12:34:40'),
(333, 'Kitchen Stainless Steel Garlic Press Crusher Home Kitchen Mincer Tool', '', 'uploads/1578551680Kitchen Stainless Steel Garlic Press Crusher Home Kitchen Mincer Tool 1139-3.jpg', '', 0, '2020-01-09 12:34:40', '2020-01-09 12:34:40'),
(334, 'Kitchen Stainless Steel Garlic Press Crusher Home Kitchen Mincer Tool', '', 'uploads/1578551680Kitchen Stainless Steel Garlic Press Crusher Home Kitchen Mincer Tool 1139-1.jpg', '', 0, '2020-01-09 12:34:40', '2020-01-09 12:34:40'),
(335, 'Pop up Spice Rack - Smartlife Kitchen Storage Racks Organizer Spice Tree Pots, 6 Cans Set', '', 'uploads/1578551772Pop up Spice Rack - Smartlife Kitchen Storage Racks Organizer Spice Tree Pots, 6 Cans Set 1140-3.jpg', '', 0, '2020-01-09 12:36:12', '2020-01-09 12:36:12'),
(336, 'Pop up Spice Rack - Smartlife Kitchen Storage Racks Organizer Spice Tree Pots, 6 Cans Set', '', 'uploads/1578551772Pop up Spice Rack - Smartlife Kitchen Storage Racks Organizer Spice Tree Pots, 6 Cans Set 1140-4.jpg', '', 0, '2020-01-09 12:36:12', '2020-01-09 12:36:12'),
(337, 'Pop up Spice Rack - Smartlife Kitchen Storage Racks Organizer Spice Tree Pots, 6 Cans Set', '', 'uploads/1578551772Pop up Spice Rack - Smartlife Kitchen Storage Racks Organizer Spice Tree Pots, 6 Cans Set 1140-2.jpg', '', 0, '2020-01-09 12:36:12', '2020-01-09 12:36:12'),
(338, 'Manual Stainless Steel Vegetable Chopper, Easy Salad Maker, Onion Chopper', '', 'uploads/1578551855Manual Stainless Steel Vegetable Chopper, Easy Salad Maker, Onion Chopper 1141-1.jpg', '', 0, '2020-01-09 12:37:35', '2020-01-09 12:37:35'),
(339, 'Manual Stainless Steel Vegetable Chopper, Easy Salad Maker, Onion Chopper', '', 'uploads/1578551855Manual Stainless Steel Vegetable Chopper, Easy Salad Maker, Onion Chopper 1141-3.jpg', '', 0, '2020-01-09 12:37:35', '2020-01-09 12:37:35'),
(340, 'Manual Stainless Steel Vegetable Chopper, Easy Salad Maker, Onion Chopper', '', 'uploads/1578551855Manual Stainless Steel Vegetable Chopper, Easy Salad Maker, Onion Chopper 1141-2.jpg', '', 0, '2020-01-09 12:37:35', '2020-01-09 12:37:35'),
(341, 'Manual Multifunctional Vegetable Chopper, Powerful Hand Held Vegetable Chopper / Kitchen Gadgets', '', 'uploads/1578551953Manual Multifunctional Vegetable Chopper, Powerful Hand Held Vegetable Chopper  Kitchen Gadgets 1142-1.jpg', '', 0, '2020-01-09 12:39:13', '2020-01-09 12:39:13');
INSERT INTO `media` (`media_id`, `media_title`, `product_code`, `media_path`, `media_type`, `product_id`, `created_time`, `modified_time`) VALUES
(342, 'Manual Multifunctional Vegetable Chopper, Powerful Hand Held Vegetable Chopper / Kitchen Gadgets', '', 'uploads/1578551953Manual Multifunctional Vegetable Chopper, Powerful Hand Held Vegetable Chopper  Kitchen Gadgets 1142-2.jpg', '', 0, '2020-01-09 12:39:13', '2020-01-09 12:39:13'),
(343, 'Manual Multifunctional Vegetable Chopper, Powerful Hand Held Vegetable Chopper / Kitchen Gadgets', '', 'uploads/1578551953Manual Multifunctional Vegetable Chopper, Powerful Hand Held Vegetable Chopper  Kitchen Gadgets 1142-3.jpg', '', 0, '2020-01-09 12:39:13', '2020-01-09 12:39:13'),
(344, 'Nicer Dicer Plus, Vegetable Cutter Chopper', '', 'uploads/1578552030Nicer Dicer Plus, Vegetable Cutter Chopper 1143-.jpg', '', 0, '2020-01-09 12:40:30', '2020-01-09 12:40:30'),
(345, 'Nicer Dicer Plus, Vegetable Cutter Chopper', '', 'uploads/1578552030Nicer Dicer Plus, Vegetable Cutter Chopper 1143-1.jpg', '', 0, '2020-01-09 12:40:30', '2020-01-09 12:40:30'),
(346, 'Nicer Dicer Plus, Vegetable Cutter Chopper', '', 'uploads/1578552030Nicer Dicer Plus, Vegetable Cutter Chopper 1143-2.jpg', '', 0, '2020-01-09 12:40:30', '2020-01-09 12:40:30'),
(347, 'Infrared Motion Sensor Holder for Light, Human Body Sensor Lamp Holder', '', 'uploads/1578552119Infrared Motion Sensor Holder for Light, Human Body Sensor Lamp Holder 1144-1.jpg', '', 0, '2020-01-09 12:41:59', '2020-01-09 12:41:59'),
(348, 'Infrared Motion Sensor Holder for Light, Human Body Sensor Lamp Holder', '', 'uploads/1578552119Infrared Motion Sensor Holder for Light, Human Body Sensor Lamp Holder 1144-2.jpg', '', 0, '2020-01-09 12:41:59', '2020-01-09 12:41:59'),
(349, 'Portable Medium Size First Aid Kit Box, Household Multi Layer Medicine Drawer Health Box', '', 'uploads/1578552277Portable Medium Size First Aid Kit Box, Household Multi Layer Medicine Drawer Health Box 1145-1.jpg', '', 0, '2020-01-09 12:44:37', '2020-01-09 12:44:37'),
(350, 'Portable Medium Size First Aid Kit Box, Household Multi Layer Medicine Drawer Health Box', '', 'uploads/1578552277Portable Medium Size First Aid Kit Box, Household Multi Layer Medicine Drawer Health Box 1145-3.jpg', '', 0, '2020-01-09 12:44:37', '2020-01-09 12:44:37'),
(351, 'Portable Medium Size First Aid Kit Box, Household Multi Layer Medicine Drawer Health Box', '', 'uploads/1578552277Portable Medium Size First Aid Kit Box, Household Multi Layer Medicine Drawer Health Box 1145-2.jpg', '', 0, '2020-01-09 12:44:37', '2020-01-09 12:44:37'),
(352, 'Suction Mug - Creative Insulated Plastic Bottle Magic \"not Fall Down\" Travel Coffee Cup Travel Mug Balance Cups', '', 'uploads/1578552651Suction Mug - Creative Insulated Plastic Bottle Magic not Fall Down Travel Coffee Cup Travel Mug Balance Cups 1146-3.jpg', '', 0, '2020-01-09 12:50:51', '2020-01-09 12:50:51'),
(353, 'Suction Mug - Creative Insulated Plastic Bottle Magic \"not Fall Down\" Travel Coffee Cup Travel Mug Balance Cups', '', 'uploads/1578552651Suction Mug - Creative Insulated Plastic Bottle Magic not Fall Down Travel Coffee Cup Travel Mug Balance Cups 1146-4.jpg', '', 0, '2020-01-09 12:50:51', '2020-01-09 12:50:51'),
(354, 'Multi Functional Electric Egg Boiler & Fryer, Non-Stick Frying Pan, Mini Egg Pan Steam Boiler Fried Steak Sandwich', '', 'uploads/1578575970Multi Functional Electric Egg Boiler & Fryer, Non-Stick Frying Pan, Mini Egg Pan Steam Boiler Fried Steak Sandwich 1147-2.jpg', '', 0, '2020-01-09 19:19:30', '2020-01-09 19:19:30'),
(355, 'Multi Functional Electric Egg Boiler & Fryer, Non-Stick Frying Pan, Mini Egg Pan Steam Boiler Fried Steak Sandwich', '', 'uploads/1578575970Multi Functional Electric Egg Boiler & Fryer, Non-Stick Frying Pan, Mini Egg Pan Steam Boiler Fried Steak Sandwich 1147-1.jpg', '', 0, '2020-01-09 19:19:30', '2020-01-09 19:19:30'),
(356, 'Multi Functional Electric Egg Boiler & Fryer, Non-Stick Frying Pan, Mini Egg Pan Steam Boiler Fried Steak Sandwich', '', 'uploads/1578575970Multi Functional Electric Egg Boiler & Fryer, Non-Stick Frying Pan, Mini Egg Pan Steam Boiler Fried Steak Sandwich 1147-3.jpg', '', 0, '2020-01-09 19:19:30', '2020-01-09 19:19:30'),
(357, 'Iron Metal Multi Remote Control Stand,4 Remote Stand Holder, Remote Holder for Home,tv Remote Holder Stand', '', 'uploads/1578576383Iron Metal Multi Remote Control Stand,4 Remote Stand Holder, Remote Holder for Home,tv Remote Holder Stand 1148-1.jpg', '', 0, '2020-01-09 19:26:23', '2020-01-09 19:26:23'),
(358, 'Iron Metal Multi Remote Control Stand,4 Remote Stand Holder, Remote Holder for Home,tv Remote Holder Stand', '', 'uploads/1578576383Iron Metal Multi Remote Control Stand,4 Remote Stand Holder, Remote Holder for Home,tv Remote Holder Stand 1148-2.jpg', '', 0, '2020-01-09 19:26:23', '2020-01-09 19:26:23'),
(359, 'Iron Metal Multi Remote Control Stand,4 Remote Stand Holder, Remote Holder for Home,tv Remote Holder Stand', '', 'uploads/1578576383Iron Metal Multi Remote Control Stand,4 Remote Stand Holder, Remote Holder for Home,tv Remote Holder Stand 1148-3.jpg', '', 0, '2020-01-09 19:26:23', '2020-01-09 19:26:23'),
(360, 'LED Colorful music flowerpot Bluetooth Speaker, Colorful LED Night Light Touch Plant Piano Music Playing, Creative Birthday Gifts Gifts or home office', '', 'uploads/1578576656LED Colorful music flowerpot Bluetooth Speaker, Colorful LED Night Light Touch Plant Piano Music Playing, Creative Birthday Gifts Gifts or home office 1149-2.jpg', '', 0, '2020-01-09 19:30:56', '2020-01-09 19:30:56'),
(361, 'LED Colorful music flowerpot Bluetooth Speaker, Colorful LED Night Light Touch Plant Piano Music Playing, Creative Birthday Gifts Gifts or home office', '', 'uploads/1578576656LED Colorful music flowerpot Bluetooth Speaker, Colorful LED Night Light Touch Plant Piano Music Playing, Creative Birthday Gifts Gifts or home office 1149-5.jpg', '', 0, '2020-01-09 19:30:56', '2020-01-09 19:30:56'),
(362, 'LED Colorful music flowerpot Bluetooth Speaker, Colorful LED Night Light Touch Plant Piano Music Playing, Creative Birthday Gifts Gifts or home office', '', 'uploads/1578576656LED Colorful music flowerpot Bluetooth Speaker, Colorful LED Night Light Touch Plant Piano Music Playing, Creative Birthday Gifts Gifts or home office 1149-3.jpg', '', 0, '2020-01-09 19:30:56', '2020-01-09 19:30:56'),
(363, 'Casio Scientific Calculator FX-991ES Plus LED Display, Battery and Solar Dual Power Supply, 417 Functions Calculator for students', '', 'uploads/1578576861Casio Scientific Calculator FX-991ES Plus LED Display, Battery and Solar Dual Power Supply, 417 Functions Calculator for students 1150-3.jpg', '', 0, '2020-01-09 19:34:21', '2020-01-09 19:34:21'),
(364, 'Casio Scientific Calculator FX-991ES Plus LED Display, Battery and Solar Dual Power Supply, 417 Functions Calculator for students', '', 'uploads/1578576861Casio Scientific Calculator FX-991ES Plus LED Display, Battery and Solar Dual Power Supply, 417 Functions Calculator for students 1150-1.jpg', '', 0, '2020-01-09 19:34:21', '2020-01-09 19:34:21'),
(365, 'Casio Scientific Calculator FX-991ES Plus LED Display, Battery and Solar Dual Power Supply, 417 Functions Calculator for students', '', 'uploads/1578576861Casio Scientific Calculator FX-991ES Plus LED Display, Battery and Solar Dual Power Supply, 417 Functions Calculator for students 1150-4.jpg', '', 0, '2020-01-09 19:34:21', '2020-01-09 19:34:21'),
(366, 'Adjustable Handheld Micro Boom Pole Microphone Mic Holder (Boom Stick) 3 Section Boompole 67.5inch Extension', '', 'uploads/1578577091Adjustable Handheld Micro Boom Pole Microphone Mic Holder (Boom Stick) 3 Section Boompole 67.5inch Extension 1151-2.jpg', '', 0, '2020-01-09 19:38:11', '2020-01-09 19:38:11'),
(367, 'Adjustable Handheld Micro Boom Pole Microphone Mic Holder (Boom Stick) 3 Section Boompole 67.5inch Extension', '', 'uploads/1578577092Adjustable Handheld Micro Boom Pole Microphone Mic Holder (Boom Stick) 3 Section Boompole 67.5inch Extension 1151-1.jpg', '', 0, '2020-01-09 19:38:12', '2020-01-09 19:38:12'),
(368, 'Adjustable Handheld Micro Boom Pole Microphone Mic Holder (Boom Stick) 3 Section Boompole 67.5inch Extension', '', 'uploads/1578577092Adjustable Handheld Micro Boom Pole Microphone Mic Holder (Boom Stick) 3 Section Boompole 67.5inch Extension 1151-3.jpg', '', 0, '2020-01-09 19:38:12', '2020-01-09 19:38:12'),
(369, 'Adjustable Handheld Micro Boom Pole Microphone Mic Holder (Boom Stick) 3 Section Boompole 67.5inch Extension', '', 'uploads/1578577092Adjustable Handheld Micro Boom Pole Microphone Mic Holder (Boom Stick) 3 Section Boompole 67.5inch Extension 1151-4.jpg', '', 0, '2020-01-09 19:38:12', '2020-01-09 19:38:12'),
(370, 'Stainless Steel Manual Pasta Maker, Noodles Maker - Silver', '', 'uploads/1578577211Stainless Steel Manual Pasta Maker, Noodles Maker - Silver 1152-1.jpg', '', 0, '2020-01-09 19:40:11', '2020-01-09 19:40:11'),
(371, 'Stainless Steel Manual Pasta Maker, Noodles Maker - Silver', '', 'uploads/1578577211Stainless Steel Manual Pasta Maker, Noodles Maker - Silver 1152-3.jpg', '', 0, '2020-01-09 19:40:11', '2020-01-09 19:40:11'),
(372, 'Stainless Steel Manual Pasta Maker, Noodles Maker - Silver', '', 'uploads/1578577211Stainless Steel Manual Pasta Maker, Noodles Maker - Silver 1152-2.jpg', '', 0, '2020-01-09 19:40:11', '2020-01-09 19:40:11'),
(373, 'Best Quality non-stick Electric Roti Maker / chapati maker (Black)', '', 'uploads/1578577691Best Quality non-stick Electric Roti Maker  chapati maker 1154-7.jpg', '', 0, '2020-01-09 19:48:11', '2020-01-09 19:48:11'),
(374, 'Best Quality non-stick Electric Roti Maker / chapati maker (Black)', '', 'uploads/1578577692Best Quality non-stick Electric Roti Maker  chapati maker 1154-6.jpg', '', 0, '2020-01-09 19:48:12', '2020-01-09 19:48:12'),
(375, 'Best Quality non-stick Electric Roti Maker / chapati maker (SS)', '', 'uploads/1578577807Best Quality non-stick Electric Roti Maker  chapati maker 1154-3.jpg', '', 0, '2020-01-09 19:50:07', '2020-01-09 19:50:07'),
(376, 'Best Quality non-stick Electric Roti Maker / chapati maker (SS)', '', 'uploads/1578577807Best Quality non-stick Electric Roti Maker  chapati maker 1154-2.jpg', '', 0, '2020-01-09 19:50:07', '2020-01-09 19:50:07'),
(377, 'Best Quality non-stick Electric Roti Maker / chapati maker (SS)', '', 'uploads/1578577807Best Quality non-stick Electric Roti Maker  chapati maker 1154-1.jpg', '', 0, '2020-01-09 19:50:07', '2020-01-09 19:50:07'),
(378, 'Electric Muffin Maker Electric Cupcake Maker Automatic Temperature Control Mini Cake Machine', '', 'uploads/1578577911Electric Muffin Maker Electric Cupcake Maker Automatic Temperature Control Mini Cake Machine 1155-2.jpg', '', 0, '2020-01-09 19:51:51', '2020-01-09 19:51:51'),
(379, 'Electric Muffin Maker Electric Cupcake Maker Automatic Temperature Control Mini Cake Machine', '', 'uploads/1578577911Electric Muffin Maker Electric Cupcake Maker Automatic Temperature Control Mini Cake Machine 1155-1.jpg', '', 0, '2020-01-09 19:51:51', '2020-01-09 19:51:51'),
(380, 'Portable Electric Lunch Box Food Container / Food Warmer Heater Rice Container', '', 'uploads/1578578034Portable Electric Lunch Box Food Container  Food Warmer Heater Rice Container 1156-2.jpg', '', 0, '2020-01-09 19:53:54', '2020-01-09 19:53:54'),
(381, 'Portable Electric Lunch Box Food Container / Food Warmer Heater Rice Container', '', 'uploads/1578578035Portable Electric Lunch Box Food Container  Food Warmer Heater Rice Container 1156-3.jpg', '', 0, '2020-01-09 19:53:55', '2020-01-09 19:53:55'),
(382, 'Portable Electric Lunch Box Food Container / Food Warmer Heater Rice Container', '', 'uploads/1578578035Portable Electric Lunch Box Food Container  Food Warmer Heater Rice Container 1156-1.jpg', '', 0, '2020-01-09 19:53:55', '2020-01-09 19:53:55'),
(383, 'Revoflex Xtreme Multi-function Full Body Workout Exercise Equipment', '', 'uploads/1578578406Revoflex Xtreme Multi-function Full Body Workout Exercise Equipment 1157-2.jpg', '', 0, '2020-01-09 20:00:06', '2020-01-09 20:00:06'),
(384, 'Revoflex Xtreme Multi-function Full Body Workout Exercise Equipment', '', 'uploads/1578578406Revoflex Xtreme Multi-function Full Body Workout Exercise Equipment 1157-4 (2).jpg', '', 0, '2020-01-09 20:00:06', '2020-01-09 20:00:06'),
(385, 'Revoflex Xtreme Multi-function Full Body Workout Exercise Equipment', '', 'uploads/1578578406Revoflex Xtreme Multi-function Full Body Workout Exercise Equipment 1157-5.jpg', '', 0, '2020-01-09 20:00:06', '2020-01-09 20:00:06'),
(386, 'Revoflex Xtreme Multi-function Full Body Workout Exercise Equipment', '', 'uploads/1578578406Revoflex Xtreme Multi-function Full Body Workout Exercise Equipment 1157-1.jpg', '', 0, '2020-01-09 20:00:06', '2020-01-09 20:00:06'),
(387, 'Veet Sensitive Touch Electric Trimmer for Women', '', 'uploads/1578578812Veet Sensitive Touch Electric Trimmer for Women 1158-1.jpg', '', 0, '2020-01-09 20:06:52', '2020-01-09 20:06:52'),
(388, 'Veet Sensitive Touch Electric Trimmer for Women', '', 'uploads/1578578812Veet Sensitive Touch Electric Trimmer for Women 1158-2.jpg', '', 0, '2020-01-09 20:06:52', '2020-01-09 20:06:52'),
(389, 'Portable Folding Pocket Prayer Mat with Compass /Islamic Janamaz / Easy Carry Prayer Mat', '', 'uploads/1578579413Portable Folding Pocket Prayer Mat with Compass Islamic Janamaz  Easy Carry Prayer Mat 1161-3.jpg', '', 0, '2020-01-09 20:16:53', '2020-01-09 20:16:53'),
(390, 'Portable Folding Pocket Prayer Mat with Compass /Islamic Janamaz / Easy Carry Prayer Mat', '', 'uploads/1578579413Portable Folding Pocket Prayer Mat with Compass Islamic Janamaz  Easy Carry Prayer Mat 1161-2.jpg', '', 0, '2020-01-09 20:16:53', '2020-01-09 20:16:53'),
(391, 'Portable Digital Infrared Ear Thermometer with LCD Display, Digital LCD Thermometer, Pocket Thermometer', '', 'uploads/1578579888Portable Digital Infrared Ear Thermometer with LCD Display, Digital LCD Thermometer, Pocket Thermometer 1162-3.jpg', '', 0, '2020-01-09 20:24:48', '2020-01-09 20:24:48'),
(392, 'Portable Digital Infrared Ear Thermometer with LCD Display, Digital LCD Thermometer, Pocket Thermometer', '', 'uploads/1578579888Portable Digital Infrared Ear Thermometer with LCD Display, Digital LCD Thermometer, Pocket Thermometer 1162-1.jpg', '', 0, '2020-01-09 20:24:48', '2020-01-09 20:24:48'),
(393, 'Portable Digital Infrared Ear Thermometer with LCD Display, Digital LCD Thermometer, Pocket Thermometer', '', 'uploads/1578579888Portable Digital Infrared Ear Thermometer with LCD Display, Digital LCD Thermometer, Pocket Thermometer 1162-2.jpg', '', 0, '2020-01-09 20:24:48', '2020-01-09 20:24:48'),
(394, '3 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup', '', 'uploads/15785803383 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup 1163-1.jpg', '', 0, '2020-01-09 20:32:18', '2020-01-09 20:32:18'),
(395, '3 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup', '', 'uploads/15785803383 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup 1163-2.jpg', '', 0, '2020-01-09 20:32:18', '2020-01-09 20:32:18'),
(396, '4 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup', '', 'uploads/15785812674 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup 1164-1.jpg', '', 0, '2020-01-09 20:47:47', '2020-01-09 20:47:47'),
(397, '4 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup', '', 'uploads/15785812674 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup 1164-2.jpg', '', 0, '2020-01-09 20:47:47', '2020-01-09 20:47:47'),
(398, '5 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup', '', 'uploads/15785814095 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup 1165-1.jpg', '', 0, '2020-01-09 20:50:09', '2020-01-09 20:50:09'),
(399, '6 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup', '', 'uploads/15785814906 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup 1166-2.jpg', '', 0, '2020-01-09 20:51:30', '2020-01-09 20:51:30'),
(400, '6 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup', '', 'uploads/15785814906 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup 1166-1.jpg', '', 0, '2020-01-09 20:51:30', '2020-01-09 20:51:30'),
(401, 'Professional Adjustable LED Lighted Vanity Makeup Mirror, Touch Screen Mirrors For Beauty Makeup Eyelash Brush', '', 'uploads/1578581783Professional Adjustable LED Lighted Vanity Makeup Mirror, Touch Screen Mirrors For Beauty Makeup Eyelash Brush 1169-1.jpg', '', 0, '2020-01-09 20:56:23', '2020-01-09 20:56:23'),
(402, 'Professional Adjustable LED Lighted Vanity Makeup Mirror, Touch Screen Mirrors For Beauty Makeup Eyelash Brush', '', 'uploads/1578581783Professional Adjustable LED Lighted Vanity Makeup Mirror, Touch Screen Mirrors For Beauty Makeup Eyelash Brush 1169-2.jpg', '', 0, '2020-01-09 20:56:23', '2020-01-09 20:56:23'),
(403, 'Acrylic Makeup Organizer 16 Slot with Removable Mirror Cosmetic Organizers', '', 'uploads/1578582011Acrylic Makeup Organizer 16 Slot with Removable Mirror Cosmetic Organizers 1170-2.jpg', '', 0, '2020-01-09 21:00:11', '2020-01-09 21:00:11'),
(404, 'Acrylic Makeup Organizer 16 Slot with Removable Mirror Cosmetic Organizers', '', 'uploads/1578582011Acrylic Makeup Organizer 16 Slot with Removable Mirror Cosmetic Organizers 1170-1.jpg', '', 0, '2020-01-09 21:00:11', '2020-01-09 21:00:11'),
(405, 'Original 10000mAh Xiaomi MI Power Bank (Dual Output)', '', 'uploads/1578582095Original 10000mAh Xiaomi MI Power Bank (Dual Output) 1171-2.jpg', '', 0, '2020-01-09 21:01:35', '2020-01-09 21:01:35'),
(406, 'Original 10000mAh Xiaomi MI Power Bank (Dual Output)', '', 'uploads/1578582095Original 10000mAh Xiaomi MI Power Bank (Dual Output) 1171-1.jpg', '', 0, '2020-01-09 21:01:35', '2020-01-09 21:01:35'),
(407, 'Automatic Toothpaste Dispenser, 5 Toothbrush Holder Stand Set Wall Mount', '', 'uploads/1578582205Automatic Toothpaste Dispenser, 5 Toothbrush Holder Stand Set Wall Mount 1174-1.jpg', '', 0, '2020-01-09 21:03:25', '2020-01-09 21:03:25'),
(408, 'Automatic Toothpaste Dispenser, 5 Toothbrush Holder Stand Set Wall Mount', '', 'uploads/1578582205Automatic Toothpaste Dispenser, 5 Toothbrush Holder Stand Set Wall Mount 1174-2.jpg', '', 0, '2020-01-09 21:03:25', '2020-01-09 21:03:25'),
(409, 'Exclusive lage cosmetic organizer box mirror (beautiful two-sided round mirror) - Transparent Acrylic cosmetic storage box- 3 Drawers', '', 'uploads/1578582322Exclusive lage cosmetic organizer box mirror (beautiful two-sided round mirror) - Transparent Acrylic cosmetic storage box- 3 Drawers 1175-1.jpg', '', 0, '2020-01-09 21:05:22', '2020-01-09 21:05:22'),
(410, 'Exclusive lage cosmetic organizer box mirror (beautiful two-sided round mirror) - Transparent Acrylic cosmetic storage box- 3 Drawers', '', 'uploads/1578582322Exclusive lage cosmetic organizer box mirror (beautiful two-sided round mirror) - Transparent Acrylic cosmetic storage box- 3 Drawers 1175-2.jpg', '', 0, '2020-01-09 21:05:22', '2020-01-09 21:05:22'),
(411, '360 Rotating Design Acrylic Clear Makeup Rack 3D Cosmetic Organizer', '', 'uploads/1578582801360 Rotating Design Acrylic Clear Makeup Rack 3D Cosmetic Organizer 1177-2.jpg', '', 0, '2020-01-09 21:13:21', '2020-01-09 21:13:21'),
(412, '360 Rotating Design Acrylic Clear Makeup Rack 3D Cosmetic Organizer', '', 'uploads/1578582801360 Rotating Design Acrylic Clear Makeup Rack 3D Cosmetic Organizer 1177-1.jpg', '', 0, '2020-01-09 21:13:21', '2020-01-09 21:13:21'),
(413, 'Digital Body Weight Scale, Glass Top, Large LCD Display, Precision Measurements (Round)', '', 'uploads/1578583088Digital Body Weight Scale, Glass Top, Large LCD Display, Precision Measurements (Round) 1178-3.jpg', '', 0, '2020-01-09 21:18:08', '2020-01-09 21:18:08'),
(414, 'Digital Body Weight Scale, Glass Top, Large LCD Display, Precision Measurements (Round)', '', 'uploads/1578583088Digital Body Weight Scale, Glass Top, Large LCD Display, Precision Measurements (Round) 1178-2.jpg', '', 0, '2020-01-09 21:18:08', '2020-01-09 21:18:08'),
(415, 'Digital Body Weight Scale, Glass Top, Large LCD Display, Precision Measurements (Round)', '', 'uploads/1578583088Digital Body Weight Scale, Glass Top, Large LCD Display, Precision Measurements (Round) 1178-1.jpg', '', 0, '2020-01-09 21:18:08', '2020-01-09 21:18:08'),
(416, 'Easy Dough Maker / Atta Maker', '', 'uploads/1578583339Easy Dough Maker  Atta Maker 1180-1.jpg', '', 0, '2020-01-09 21:22:19', '2020-01-09 21:22:19'),
(417, 'Easy Dough Maker / Atta Maker', '', 'uploads/1578583340Easy Dough Maker  Atta Maker 1180-2.jpg', '', 0, '2020-01-09 21:22:20', '2020-01-09 21:22:20'),
(418, 'Easy Dough Maker / Atta Maker', '', 'uploads/1578583340Easy Dough Maker  Atta Maker 1180-3.jpg', '', 0, '2020-01-09 21:22:20', '2020-01-09 21:22:20'),
(419, 'Nima 2 in 1 Electric Spice Grinder & Juicer  Mini Juicer Mini Blender', '', 'uploads/1578584609Nima 2 in 1 Electric Spice Grinder & Juicer  Mini Juicer Mini Blender 1181-3.jpg', '', 0, '2020-01-09 21:43:29', '2020-01-09 21:43:29'),
(420, 'Nima 2 in 1 Electric Spice Grinder & Juicer  Mini Juicer Mini Blender', '', 'uploads/1578584609Nima 2 in 1 Electric Spice Grinder & Juicer  Mini Juicer Mini Blender 1181-1.jpg', '', 0, '2020-01-09 21:43:29', '2020-01-09 21:43:29'),
(421, 'Nima 2 in 1 Electric Spice Grinder & Juicer  Mini Juicer Mini Blender', '', 'uploads/1578584609Nima 2 in 1 Electric Spice Grinder & Juicer  Mini Juicer Mini Blender 1181-2.jpg', '', 0, '2020-01-09 21:43:29', '2020-01-09 21:43:29'),
(422, 'M3 Smart Fitness Wristband Bracelet / Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones', '', 'uploads/1578584724M3 Smart Fitness Wristband Bracelet  Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones 1182-4.jpg', '', 0, '2020-01-09 21:45:24', '2020-01-09 21:45:24'),
(423, 'M3 Smart Fitness Wristband Bracelet / Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones', '', 'uploads/1578584724M3 Smart Fitness Wristband Bracelet  Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones 1182-3.jpg', '', 0, '2020-01-09 21:45:24', '2020-01-09 21:45:24'),
(424, 'M3 Smart Fitness Wristband Bracelet / Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones', '', 'uploads/1578584724M3 Smart Fitness Wristband Bracelet  Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones 1182-1.jpg', '', 0, '2020-01-09 21:45:24', '2020-01-09 21:45:24'),
(425, 'Xiaomi Mi Band 3 OLED Smart Fitness Wristband Bracelet / Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones', '', 'uploads/1578584856Xiaomi Mi Band 3 OLED Smart Fitness Wristband Bracelet  Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones 1183-3.jpg', '', 0, '2020-01-09 21:47:36', '2020-01-09 21:47:36'),
(426, 'Xiaomi Mi Band 3 OLED Smart Fitness Wristband Bracelet / Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones', '', 'uploads/1578584856Xiaomi Mi Band 3 OLED Smart Fitness Wristband Bracelet  Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones 1183-1.jpg', '', 0, '2020-01-09 21:47:36', '2020-01-09 21:47:36'),
(427, 'Xiaomi Mi Band 3 OLED Smart Fitness Wristband Bracelet / Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones', '', 'uploads/1578584856Xiaomi Mi Band 3 OLED Smart Fitness Wristband Bracelet  Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones 1183-2.jpg', '', 0, '2020-01-09 21:47:36', '2020-01-09 21:47:36'),
(428, 'Xiaomi Mi Band 3 OLED Smart Fitness Wristband Bracelet / Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones', '', 'uploads/1578584856Xiaomi Mi Band 3 OLED Smart Fitness Wristband Bracelet  Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones 1183-4.jpg', '', 0, '2020-01-09 21:47:36', '2020-01-09 21:47:36'),
(429, 'TWS I11 Wireless Bluetooth Headset with Charging Box Sports Running Ear Plugs Hanging Ears Wearing Earphones', '', 'uploads/1578585604TWS I11 Wireless Bluetooth Headset with Charging Box Sports Running Ear Plugs Hanging Ears Wearing Earphones 1184-3.jpg', '', 0, '2020-01-09 22:00:04', '2020-01-09 22:00:04'),
(430, 'TWS I11 Wireless Bluetooth Headset with Charging Box Sports Running Ear Plugs Hanging Ears Wearing Earphones', '', 'uploads/1578585604TWS I11 Wireless Bluetooth Headset with Charging Box Sports Running Ear Plugs Hanging Ears Wearing Earphones 1184-5.jpg', '', 0, '2020-01-09 22:00:04', '2020-01-09 22:00:04'),
(431, 'TWS I11 Wireless Bluetooth Headset with Charging Box Sports Running Ear Plugs Hanging Ears Wearing Earphones', '', 'uploads/1578585604TWS I11 Wireless Bluetooth Headset with Charging Box Sports Running Ear Plugs Hanging Ears Wearing Earphones 1184-2.jpg', '', 0, '2020-01-09 22:00:04', '2020-01-09 22:00:04'),
(432, 'Remax RB-S8 Sports Bluetooth Headset wireless earbuds Sport Stereo Earphone Magnetic Charge with hd Mic Hands-free Call ', '', 'uploads/1578585701Remax RB-S8 Sports Bluetooth Headset wireless earbuds Sport Stereo Earphone Magnetic Charge with hd Mic Hands-free Call  1185-1.jpg', '', 0, '2020-01-09 22:01:41', '2020-01-09 22:01:41'),
(433, 'Remax RB-S8 Sports Bluetooth Headset wireless earbuds Sport Stereo Earphone Magnetic Charge with hd Mic Hands-free Call ', '', 'uploads/1578585701Remax RB-S8 Sports Bluetooth Headset wireless earbuds Sport Stereo Earphone Magnetic Charge with hd Mic Hands-free Call  1185-4.jpg', '', 0, '2020-01-09 22:01:41', '2020-01-09 22:01:41'),
(434, 'Remax RB-S8 Sports Bluetooth Headset wireless earbuds Sport Stereo Earphone Magnetic Charge with hd Mic Hands-free Call ', '', 'uploads/1578585701Remax RB-S8 Sports Bluetooth Headset wireless earbuds Sport Stereo Earphone Magnetic Charge with hd Mic Hands-free Call  1185-2.jpg', '', 0, '2020-01-09 22:01:41', '2020-01-09 22:01:41'),
(435, 'Remax RB-S8 HIFI wireless Bluetooth Headphones earbuds Hands-free Wireless Neckband Noise Cancelling Earphone Magnetic Earbuds Sweatproof Earphones 7-9 Hrs Playtime for Running Gym Workout w/Mic', '', 'uploads/1578585778Remax RB-S8 HIFI wireless Bluetooth Headphones earbuds Hands-free Wireless Neckband Noise Cancelling Earphone Magnetic Earbuds Sweatproof Earphones 7-9 Hrs Playtime for Running Gym Workout wMic 1186-3.jpg', '', 0, '2020-01-09 22:02:58', '2020-01-09 22:02:58'),
(436, 'Remax RB-S8 HIFI wireless Bluetooth Headphones earbuds Hands-free Wireless Neckband Noise Cancelling Earphone Magnetic Earbuds Sweatproof Earphones 7-9 Hrs Playtime for Running Gym Workout w/Mic', '', 'uploads/1578585779Remax RB-S8 HIFI wireless Bluetooth Headphones earbuds Hands-free Wireless Neckband Noise Cancelling Earphone Magnetic Earbuds Sweatproof Earphones 7-9 Hrs Playtime for Running Gym Workout wMic 1186-2.jpg', '', 0, '2020-01-09 22:02:59', '2020-01-09 22:02:59'),
(437, 'Remax RB-S8 HIFI wireless Bluetooth Headphones earbuds Hands-free Wireless Neckband Noise Cancelling Earphone Magnetic Earbuds Sweatproof Earphones 7-9 Hrs Playtime for Running Gym Workout w/Mic', '', 'uploads/1578585779Remax RB-S8 HIFI wireless Bluetooth Headphones earbuds Hands-free Wireless Neckband Noise Cancelling Earphone Magnetic Earbuds Sweatproof Earphones 7-9 Hrs Playtime for Running Gym Workout wMic 1186-1.jpg', '', 0, '2020-01-09 22:02:59', '2020-01-09 22:02:59'),
(438, 'BOYA BY-M1DM Dual Clip Microphone for Interview 2 Person Recording Live Videos Camera smartphone iPhone Canon DSLR PK Rode', '', 'uploads/1578585928BOYA BY-M1DM Dual Clip Microphone for Interview 2 Person Recording Live Videos Camera smartphone iPhone Canon DSLR PK Rode 1187-4.jpg', '', 0, '2020-01-09 22:05:28', '2020-01-09 22:05:28'),
(439, 'BOYA BY-M1DM Dual Clip Microphone for Interview 2 Person Recording Live Videos Camera smartphone iPhone Canon DSLR PK Rode', '', 'uploads/1578585928BOYA BY-M1DM Dual Clip Microphone for Interview 2 Person Recording Live Videos Camera smartphone iPhone Canon DSLR PK Rode 1187-5.jpg', '', 0, '2020-01-09 22:05:28', '2020-01-09 22:05:28'),
(440, 'Sardine F1 TWS Aluminium Wireless Bluetooth Speaker with Charging Dock 3D Stereo Subwoofer Bass Speaker for smartphone hands-free Mic Portable Loudspeaker', '', 'uploads/1578586110Sardine F1 TWS Aluminium Wireless Bluetooth Speaker with Charging Dock 3D Stereo Subwoofer Bass Speaker for smartphone hands-free Mic Portable Loudspeaker 1188-5.jpg', '', 0, '2020-01-09 22:08:30', '2020-01-09 22:08:30'),
(441, 'Sardine F1 TWS Aluminium Wireless Bluetooth Speaker with Charging Dock 3D Stereo Subwoofer Bass Speaker for smartphone hands-free Mic Portable Loudspeaker', '', 'uploads/1578586110Sardine F1 TWS Aluminium Wireless Bluetooth Speaker with Charging Dock 3D Stereo Subwoofer Bass Speaker for smartphone hands-free Mic Portable Loudspeaker 1188-3.jpg', '', 0, '2020-01-09 22:08:30', '2020-01-09 22:08:30'),
(442, 'Sardine F1 TWS Aluminium Wireless Bluetooth Speaker with Charging Dock 3D Stereo Subwoofer Bass Speaker for smartphone hands-free Mic Portable Loudspeaker', '', 'uploads/1578586110Sardine F1 TWS Aluminium Wireless Bluetooth Speaker with Charging Dock 3D Stereo Subwoofer Bass Speaker for smartphone hands-free Mic Portable Loudspeaker 1188-1.jpg', '', 0, '2020-01-09 22:08:30', '2020-01-09 22:08:30'),
(443, 'Sardine F1 TWS Aluminium Wireless Bluetooth Speaker with Charging Dock 3D Stereo Subwoofer Bass Speaker for smartphone hands-free Mic Portable Loudspeaker', '', 'uploads/1578586110Sardine F1 TWS Aluminium Wireless Bluetooth Speaker with Charging Dock 3D Stereo Subwoofer Bass Speaker for smartphone hands-free Mic Portable Loudspeaker 1188-2.jpg', '', 0, '2020-01-09 22:08:30', '2020-01-09 22:08:30'),
(444, 'T6 Portable Adjustable Laptop Table/stand for Notebook MacBook Ergonomic TV Bed Lap Stand Up Sitting with Pad Side Mount', '', 'uploads/1578586426T6 Portable Adjustable Laptop Tablestand for Notebook MacBook Ergonomic TV Bed Lap Stand Up Sitting with Pad Side Mount 1189-4.jpg', '', 0, '2020-01-09 22:13:46', '2020-01-09 22:13:46'),
(445, 'T6 Portable Adjustable Laptop Table/stand for Notebook MacBook Ergonomic TV Bed Lap Stand Up Sitting with Pad Side Mount', '', 'uploads/1578586426T6 Portable Adjustable Laptop Tablestand for Notebook MacBook Ergonomic TV Bed Lap Stand Up Sitting with Pad Side Mount 1189-2.jpg', '', 0, '2020-01-09 22:13:46', '2020-01-09 22:13:46'),
(446, 'T6 Portable Adjustable Laptop Table/stand for Notebook MacBook Ergonomic TV Bed Lap Stand Up Sitting with Pad Side Mount', '', 'uploads/1578586426T6 Portable Adjustable Laptop Tablestand for Notebook MacBook Ergonomic TV Bed Lap Stand Up Sitting with Pad Side Mount 1189-1.jpg', '', 0, '2020-01-09 22:13:46', '2020-01-09 22:13:46'),
(447, 'T6 Portable Adjustable Laptop Table/stand for Notebook MacBook Ergonomic TV Bed Lap Stand Up Sitting with Pad Side Mount', '', 'uploads/1578586426T6 Portable Adjustable Laptop Tablestand for Notebook MacBook Ergonomic TV Bed Lap Stand Up Sitting with Pad Side Mount 1189-3.jpg', '', 0, '2020-01-09 22:13:46', '2020-01-09 22:13:46'),
(448, 'Silicone Gloves Magic Silicone Dish Washing Glove Household Scrubber Rubber Kitchen Cleaning Tool Kitchen Gloves ', '', 'uploads/1578586554Silicone Gloves Magic Silicone Dish Washing Glove Household Scrubber Rubber Kitchen Cleaning Tool Kitchen Gloves  1191-3.jpg', '', 0, '2020-01-09 22:15:54', '2020-01-09 22:15:54'),
(449, 'Silicone Gloves Magic Silicone Dish Washing Glove Household Scrubber Rubber Kitchen Cleaning Tool Kitchen Gloves ', '', 'uploads/1578586554Silicone Gloves Magic Silicone Dish Washing Glove Household Scrubber Rubber Kitchen Cleaning Tool Kitchen Gloves  1191-7.jpg', '', 0, '2020-01-09 22:15:54', '2020-01-09 22:15:54'),
(450, 'Silicone Gloves Magic Silicone Dish Washing Glove Household Scrubber Rubber Kitchen Cleaning Tool Kitchen Gloves ', '', 'uploads/1578586554Silicone Gloves Magic Silicone Dish Washing Glove Household Scrubber Rubber Kitchen Cleaning Tool Kitchen Gloves  1191-1.jpg', '', 0, '2020-01-09 22:15:54', '2020-01-09 22:15:54'),
(451, 'Silicone Gloves Magic Silicone Dish Washing Glove Household Scrubber Rubber Kitchen Cleaning Tool Kitchen Gloves ', '', 'uploads/1578586554Silicone Gloves Magic Silicone Dish Washing Glove Household Scrubber Rubber Kitchen Cleaning Tool Kitchen Gloves  1191-5.jpg', '', 0, '2020-01-09 22:15:54', '2020-01-09 22:15:54'),
(452, 'Xiaomi MI WiFi Repeater Universal Router 300Mbps - WIFI Range Extender', '', 'uploads/1578587523Xiaomi MI WiFi Repeater Universal Router 300Mbps - WIFI Range Extender 1193-2.jpg', '', 0, '2020-01-09 22:32:03', '2020-01-09 22:32:03'),
(453, 'Xiaomi MI WiFi Repeater Universal Router 300Mbps - WIFI Range Extender', '', 'uploads/1578587523Xiaomi MI WiFi Repeater Universal Router 300Mbps - WIFI Range Extender 1193-3.jpg', '', 0, '2020-01-09 22:32:03', '2020-01-09 22:32:03'),
(454, 'Xiaomi MI WiFi Repeater Universal Router 300Mbps - WIFI Range Extender', '', 'uploads/1578587523Xiaomi MI WiFi Repeater Universal Router 300Mbps - WIFI Range Extender 1193-1.jpg', '', 0, '2020-01-09 22:32:03', '2020-01-09 22:32:03'),
(455, 'Broadcasting Studio Microphone Mic Stand Adjustable Boom Studio Scissor Arm Mount Shock for Mounting On table (for Blue Yeti Snowball Microphone and Blue Yeti Nano)', '', 'uploads/1578816040Broadcasting Studio Microphone Mic Stand Adjustable Boom Studio Scissor Arm Mount Shock for Mounting On table (for Blue Yeti Snowball Microphone and Blue Yeti Nano) 1194-1.jpg', '', 0, '2020-01-12 14:00:40', '2020-01-12 14:00:40'),
(456, 'Broadcasting Studio Microphone Mic Stand Adjustable Boom Studio Scissor Arm Mount Shock for Mounting On table (for Blue Yeti Snowball Microphone and Blue Yeti Nano)', '', 'uploads/1578816040Broadcasting Studio Microphone Mic Stand Adjustable Boom Studio Scissor Arm Mount Shock for Mounting On table (for Blue Yeti Snowball Microphone and Blue Yeti Nano) 1194-2.jpg', '', 0, '2020-01-12 14:00:40', '2020-01-12 14:00:40'),
(457, 'Broadcasting Studio Microphone Mic Stand Adjustable Boom Studio Scissor Arm Mount Shock for Mounting On table (for Blue Yeti Snowball Microphone and Blue Yeti Nano)', '', 'uploads/1578816040Broadcasting Studio Microphone Mic Stand Adjustable Boom Studio Scissor Arm Mount Shock for Mounting On table (for Blue Yeti Snowball Microphone and Blue Yeti Nano) 1194-4.jpg', '', 0, '2020-01-12 14:00:40', '2020-01-12 14:00:40'),
(458, 'Professional Pop Filter For Microphone With Adjustable Arm, Double Mesh Screen Windscreen Studio', '', 'uploads/1578816412Professional Pop Filter For Microphone With Adjustable Arm, Double Mesh Screen Windscreen Studio 1195-1.jpg', '', 0, '2020-01-12 14:06:52', '2020-01-12 14:06:52'),
(459, 'Professional Pop Filter For Microphone With Adjustable Arm, Double Mesh Screen Windscreen Studio', '', 'uploads/1578816412Professional Pop Filter For Microphone With Adjustable Arm, Double Mesh Screen Windscreen Studio 1195-2.jpg', '', 0, '2020-01-12 14:06:52', '2020-01-12 14:06:52'),
(460, 'BM100 High Performance Condenser Microphone For YouTube Studio Radio Broadcasting Singing Recording With Shock Mount Kit', '', 'uploads/1578823009BM100 High Performance Condenser Microphone For YouTube Studio Radio Braodcasting Singing Recording With Shock Mount Kit 1196-2.jpg', '', 0, '2020-01-12 15:56:49', '2020-01-12 15:56:49'),
(461, 'BM100 High Performance Condenser Microphone For YouTube Studio Radio Broadcasting Singing Recording With Shock Mount Kit', '', 'uploads/1578823009BM100 High Performance Condenser Microphone For YouTube Studio Radio Braodcasting Singing Recording With Shock Mount Kit 1196-9.jpg', '', 0, '2020-01-12 15:56:49', '2020-01-12 15:56:49'),
(462, 'BM100 High Performance Condenser Microphone For YouTube Studio Radio Broadcasting Singing Recording With Shock Mount Kit', '', 'uploads/1578823009BM100 High Performance Condenser Microphone For YouTube Studio Radio Braodcasting Singing Recording With Shock Mount Kit 1196-3.jpg', '', 0, '2020-01-12 15:56:49', '2020-01-12 15:56:49'),
(463, 'BM100 High Performance Condenser Microphone For YouTube Studio Radio Broadcasting Singing Recording With Shock Mount Kit', '', 'uploads/1578823009BM100 High Performance Condenser Microphone For YouTube Studio Radio Braodcasting Singing Recording With Shock Mount Kit 1196-1.jpg', '', 0, '2020-01-12 15:56:49', '2020-01-12 15:56:49'),
(464, 'New Vacuum Cleaner Blowing and Sucking Dual Purpose (Jk-8) 8 Multi-functional Portable Vacuum Cleaner', '', 'uploads/1578823467New Vacuum Cleaner Blowing and Sucking Dual Purpose (Jk-8) 8 Multi-functional Portable Vacuum Cleaner 1197-4.jpg', '', 0, '2020-01-12 16:04:27', '2020-01-12 16:04:27'),
(465, 'New Vacuum Cleaner Blowing and Sucking Dual Purpose (Jk-8) 8 Multi-functional Portable Vacuum Cleaner', '', 'uploads/1578823467New Vacuum Cleaner Blowing and Sucking Dual Purpose (Jk-8) 8 Multi-functional Portable Vacuum Cleaner 1197-2.jpg', '', 0, '2020-01-12 16:04:27', '2020-01-12 16:04:27'),
(466, 'New Vacuum Cleaner Blowing and Sucking Dual Purpose (Jk-8) 8 Multi-functional Portable Vacuum Cleaner', '', 'uploads/1578823467New Vacuum Cleaner Blowing and Sucking Dual Purpose (Jk-8) 8 Multi-functional Portable Vacuum Cleaner 1197-1.jpg', '', 0, '2020-01-12 16:04:27', '2020-01-12 16:04:27'),
(467, '3MP Panoramic WiFi Camera HD VR CAM 360 Degrees - Infrared Night Vision Camera', '', 'uploads/15788237293MP Panoramic WiFi Camera HD VR CAM 360 Degrees - Infrared Night Vision Camera 1200-1.jpg', '', 0, '2020-01-12 16:08:49', '2020-01-12 16:08:49'),
(468, '3MP Panoramic WiFi Camera HD VR CAM 360 Degrees - Infrared Night Vision Camera', '', 'uploads/15788237293MP Panoramic WiFi Camera HD VR CAM 360 Degrees - Infrared Night Vision Camera 1200-2.jpg', '', 0, '2020-01-12 16:08:49', '2020-01-12 16:08:49'),
(469, '3MP Panoramic WiFi Camera HD VR CAM 360 Degrees - Infrared Night Vision Camera', '', 'uploads/15788237293MP Panoramic WiFi Camera HD VR CAM 360 Degrees - Infrared Night Vision Camera 1200-3.jpg', '', 0, '2020-01-12 16:08:49', '2020-01-12 16:08:49'),
(470, '3MP Panoramic WiFi Camera HD VR CAM 360 Degrees - Infrared Night Vision Camera', '', 'uploads/15788237293MP Panoramic WiFi Camera HD VR CAM 360 Degrees - Infrared Night Vision Camera 1200-4.jpg', '', 0, '2020-01-12 16:08:49', '2020-01-12 16:08:49'),
(471, 'Hi quality Rechargeable LED Headlight dual light zoom headlamp for cycling bike riding', '', 'uploads/1578823839Hi quality Rechargable LED Headlight dual light zoom headlamp for cycling bike riding 1201-1.jpg', '', 0, '2020-01-12 16:10:39', '2020-01-12 16:10:39'),
(472, 'Hi quality Rechargeable LED Headlight dual light zoom headlamp for cycling bike riding', '', 'uploads/1578823839Hi quality Rechargable LED Headlight dual light zoom headlamp for cycling bike riding 1201-2.jpg', '', 0, '2020-01-12 16:10:39', '2020-01-12 16:10:39'),
(473, 'Hi quality Rechargeable LED Headlight dual light zoom headlamp for cycling bike riding', '', 'uploads/1578823839Hi quality Rechargable LED Headlight dual light zoom headlamp for cycling bike riding 1201-3.jpg', '', 0, '2020-01-12 16:10:39', '2020-01-12 16:10:39'),
(474, 'Shure SM-959 Professional wired Dynamic Microphone, best for youtube video', '', 'uploads/1578824033Shure SM-959 Professional wired Dynamic Microphone, best for youtube video 1203-2.jpg', '', 0, '2020-01-12 16:13:53', '2020-01-12 16:13:53'),
(475, 'Shure SM-959 Professional wired Dynamic Microphone, best for youtube video', '', 'uploads/1578824033Shure SM-959 Professional wired Dynamic Microphone, best for youtube video 1203-1.jpg', '', 0, '2020-01-12 16:13:53', '2020-01-12 16:13:53'),
(476, 'Shure SM-959 Professional wired Dynamic Microphone, best for youtube video', '', 'uploads/1578824033Shure SM-959 Professional wired Dynamic Microphone, best for youtube video 1203-4.jpg', '', 0, '2020-01-12 16:13:53', '2020-01-12 16:13:53'),
(477, 'Google Chromecast Full HD Smart TV Device, Wireless WiFi Display Dongle, Android System Supports Google Chrome, HDMI 1080P Digital TV Receiver Adapter', '', 'uploads/1578824162Google Chromecast Full HD Smart TV Device, Wireless WiFi Display Dongle, Android System Supports Google Chrome, HDMI 1080P Digital TV Receiver Adapter 1204-1.jpg', '', 0, '2020-01-12 16:16:02', '2020-01-12 16:16:02'),
(478, 'Uniross Multi USB Chargeing Station 6.8A built in IC for auto detection to recognize most smartphones, built in voltage stabilizer ', '', 'uploads/1578824212Uniross Multi USB Chargeing Station 6.8A built in IC for auto detection to recognize most smartphones, built in votage stabilizer  1205-1.jpg', '', 0, '2020-01-12 16:16:52', '2020-01-12 16:16:52'),
(479, 'ZOOM H1n Crystal Clear Digital Audio voice Recorder, Stereo Microphone for Recording Interview', '', 'uploads/1578824515ZOOM H1N Crystal Clear Digital Audio voice Recorder, Stereo Microphone for Recording Interview 1206-6.jpg', '', 0, '2020-01-12 16:21:55', '2020-01-12 16:21:55'),
(480, 'ZOOM H1n Crystal Clear Digital Audio voice Recorder, Stereo Microphone for Recording Interview', '', 'uploads/1578824515ZOOM H1N Crystal Clear Digital Audio voice Recorder, Stereo Microphone for Recording Interview 1206-4.jpg', '', 0, '2020-01-12 16:21:55', '2020-01-12 16:21:55'),
(481, 'ZOOM H1n Crystal Clear Digital Audio voice Recorder, Stereo Microphone for Recording Interview', '', 'uploads/1578824515ZOOM H1N Crystal Clear Digital Audio voice Recorder, Stereo Microphone for Recording Interview 1206-1.jpg', '', 0, '2020-01-12 16:21:55', '2020-01-12 16:21:55'),
(482, 'ZOOM H1n Crystal Clear Digital Audio voice Recorder, Stereo Microphone for Recording Interview', '', 'uploads/1578824515ZOOM H1N Crystal Clear Digital Audio voice Recorder, Stereo Microphone for Recording Interview 1206-3.jpg', '', 0, '2020-01-12 16:21:55', '2020-01-12 16:21:55'),
(483, 'Zoom H6 portable professional handheld digital recorder 6-Track audio recorder for interview', '', 'uploads/1578824838Zoom H6 portable professional handheld digital recorder 6-Track audio recorder for interview 1207-1.jpg', '', 0, '2020-01-12 16:27:18', '2020-01-12 16:27:18'),
(484, 'Zoom H6 portable professional handheld digital recorder 6-Track audio recorder for interview', '', 'uploads/1578824838Zoom H6 portable professional handheld digital recorder 6-Track audio recorder for interview 1207-4.jpg', '', 0, '2020-01-12 16:27:18', '2020-01-12 16:27:18'),
(485, 'Zoom H6 portable professional handheld digital recorder 6-Track audio recorder for interview', '', 'uploads/1578824838Zoom H6 portable professional handheld digital recorder 6-Track audio recorder for interview 1207-6.jpg', '', 0, '2020-01-12 16:27:18', '2020-01-12 16:27:18'),
(486, 'Zoom H6 portable professional handheld digital recorder 6-Track audio recorder for interview', '', 'uploads/1578824838Zoom H6 portable professional handheld digital recorder 6-Track audio recorder for interview 1207-5.jpg', '', 0, '2020-01-12 16:27:18', '2020-01-12 16:27:18'),
(487, 'Zoom H6 portable professional handheld digital recorder 6-Track audio recorder for interview', '', 'uploads/1578824838Zoom H6 portable professional handheld digital recorder 6-Track audio recorder for interview 1207-3.jpg', '', 0, '2020-01-12 16:27:18', '2020-01-12 16:27:18'),
(488, 'Zoom H2n Handy Portable Digital Audio Recorder / Stereo microphone for Interview', '', 'uploads/1578825071Zoom H2n Handy Portable Digital Audio Recorder  Stereo microphone for Interview 1208-3.jpg', '', 0, '2020-01-12 16:31:11', '2020-01-12 16:31:11'),
(489, 'Zoom H2n Handy Portable Digital Audio Recorder / Stereo microphone for Interview', '', 'uploads/1578825071Zoom H2n Handy Portable Digital Audio Recorder  Stereo microphone for Interview 1208-5.jpg', '', 0, '2020-01-12 16:31:11', '2020-01-12 16:31:11'),
(490, 'Zoom H2n Handy Portable Digital Audio Recorder / Stereo microphone for Interview', '', 'uploads/1578825071Zoom H2n Handy Portable Digital Audio Recorder  Stereo microphone for Interview 1208-4.jpg', '', 0, '2020-01-12 16:31:11', '2020-01-12 16:31:11'),
(491, 'Zoom H2n Handy Portable Digital Audio Recorder / Stereo microphone for Interview', '', 'uploads/1578825071Zoom H2n Handy Portable Digital Audio Recorder  Stereo microphone for Interview 1208-2.jpg', '', 0, '2020-01-12 16:31:11', '2020-01-12 16:31:11'),
(492, 'DJI Osmo Pocket 3-axis stabilized handheld camera 4K 60fps Video', '', 'uploads/1578825412DJI Osmo Pocket 3-axis stabilized handheld camera 4K 60fps Video 1209-1.jpg', '', 0, '2020-01-12 16:36:52', '2020-01-12 16:36:52'),
(493, 'DJI Osmo Pocket 3-axis stabilized handheld camera 4K 60fps Video', '', 'uploads/1578825412DJI Osmo Pocket 3-axis stabilized handheld camera 4K 60fps Video 1209-2.jpg', '', 0, '2020-01-12 16:36:52', '2020-01-12 16:36:52'),
(494, 'Rode VideoMic Camera Mount Shotgun Microphone with Rycote Lyre Shock Mount', '', 'uploads/1578826011Rode VideoMic Camera Mount Shotgun Microphone with Rycote Lyre Shock Mount 1210-3.jpg', '', 0, '2020-01-12 16:46:51', '2020-01-12 16:46:51'),
(495, 'Rode VideoMic Camera Mount Shotgun Microphone with Rycote Lyre Shock Mount', '', 'uploads/1578826011Rode VideoMic Camera Mount Shotgun Microphone with Rycote Lyre Shock Mount 1210-1.jpg', '', 0, '2020-01-12 16:46:51', '2020-01-12 16:46:51'),
(496, 'Rode VideoMic Camera Mount Shotgun Microphone with Rycote Lyre Shock Mount', '', 'uploads/1578826011Rode VideoMic Camera Mount Shotgun Microphone with Rycote Lyre Shock Mount 1210-4.jpg', '', 0, '2020-01-12 16:46:51', '2020-01-12 16:46:51'),
(497, 'Rode VideoMic Camera Mount Shotgun Microphone with Rycote Lyre Shock Mount', '', 'uploads/1578826011Rode VideoMic Camera Mount Shotgun Microphone with Rycote Lyre Shock Mount 1210-2.jpg', '', 0, '2020-01-12 16:46:51', '2020-01-12 16:46:51'),
(498, 'Rode VideoMic Pro+ plus Shot gun On-Camera Shotgun Condenser Microphone with Shockmount', '', 'uploads/1578826242Rode VideoMic Pro+ plus Shot gun On-Camera Shotgun Condenser Microphone with Shockmount 1211-4.jpg', '', 0, '2020-01-12 16:50:42', '2020-01-12 16:50:42'),
(499, 'Rode VideoMic Pro+ plus Shot gun On-Camera Shotgun Condenser Microphone with Shockmount', '', 'uploads/1578826242Rode VideoMic Pro+ plus Shot gun On-Camera Shotgun Condenser Microphone with Shockmount 1211-3.jpg', '', 0, '2020-01-12 16:50:42', '2020-01-12 16:50:42'),
(500, 'Rode VideoMic Pro+ plus Shot gun On-Camera Shotgun Condenser Microphone with Shockmount', '', 'uploads/1578826242Rode VideoMic Pro+ plus Shot gun On-Camera Shotgun Condenser Microphone with Shockmount 1211-2.jpg', '', 0, '2020-01-12 16:50:42', '2020-01-12 16:50:42'),
(501, 'Rode VideoMic Pro+ plus Shot gun On-Camera Shotgun Condenser Microphone with Shockmount', '', 'uploads/1578826242Rode VideoMic Pro+ plus Shot gun On-Camera Shotgun Condenser Microphone with Shockmount 1211-1.jpg', '', 0, '2020-01-12 16:50:42', '2020-01-12 16:50:42'),
(502, 'Rode NTG2 Multi-Powered Short Shotgun Condenser Microphone (Battery or Phantom Powered)', '', 'uploads/1578826490Rode NTG2 Multi-Powered Short Shotgun Condenser Microphone (Battery or Phantom Powered) 1212-1.jpg', '', 0, '2020-01-12 16:54:50', '2020-01-12 16:54:50'),
(503, 'Rode NTG2 Multi-Powered Short Shotgun Condenser Microphone (Battery or Phantom Powered)', '', 'uploads/1578826490Rode NTG2 Multi-Powered Short Shotgun Condenser Microphone (Battery or Phantom Powered)1212-2.jpg', '', 0, '2020-01-12 16:54:50', '2020-01-12 16:54:50'),
(504, 'Rode NTG2 Multi-Powered Short Shotgun Condenser Microphone (Battery or Phantom Powered)', '', 'uploads/1578826490Rode NTG2 Multi-Powered Short Shotgun Condenser Microphone (Battery or Phantom Powered) 1212-3.jpg', '', 0, '2020-01-12 16:54:50', '2020-01-12 16:54:50'),
(505, 'Rode NTG4+ Supercardioid Condenser Shotgun Microphone with Digital Switches', '', 'uploads/1578826654Rode NTG4 Supercardioid Condenser Shotgun Microphone with Digital Switches 1213-3.jpg', '', 0, '2020-01-12 16:57:34', '2020-01-12 16:57:34'),
(506, 'Rode NTG4+ Supercardioid Condenser Shotgun Microphone with Digital Switches', '', 'uploads/1578826654Rode NTG4 Supercardioid Condenser Shotgun Microphone with Digital Switches 1213-1.jpg', '', 0, '2020-01-12 16:57:34', '2020-01-12 16:57:34'),
(507, 'Rode NTG4+ Supercardioid Condenser Shotgun Microphone with Digital Switches', '', 'uploads/1578826654Rode NTG4 Supercardioid Condenser Shotgun Microphone with Digital Switches 1213-2.jpg', '', 0, '2020-01-12 16:57:34', '2020-01-12 16:57:34'),
(508, 'Boom Microphone- BOYA BY-HM100 Handheld Dynamic Microphone Xlr Long Handle Aluminum Body mic For Interviews News Gathering Presentation Speech', '', 'uploads/1578826836Boom Microphone- BOYA BY-HM100 Handheld Dynamic Microphone Xlr Long Handle Aluminum Body mic For Interviews News Gathering Presentation Speech 1214-3.jpg', '', 0, '2020-01-12 17:00:36', '2020-01-12 17:00:36'),
(509, 'Boom Microphone- BOYA BY-HM100 Handheld Dynamic Microphone Xlr Long Handle Aluminum Body mic For Interviews News Gathering Presentation Speech', '', 'uploads/1578826836Boom Microphone- BOYA BY-HM100 Handheld Dynamic Microphone Xlr Long Handle Aluminum Body mic For Interviews News Gathering Presentation Speech 1214-1.jpg', '', 0, '2020-01-12 17:00:36', '2020-01-12 17:00:36');
INSERT INTO `media` (`media_id`, `media_title`, `product_code`, `media_path`, `media_type`, `product_id`, `created_time`, `modified_time`) VALUES
(510, 'Boom Microphone- BOYA BY-HM100 Handheld Dynamic Microphone Xlr Long Handle Aluminum Body mic For Interviews News Gathering Presentation Speech', '', 'uploads/1578826836Boom Microphone- BOYA BY-HM100 Handheld Dynamic Microphone Xlr Long Handle Aluminum Body mic For Interviews News Gathering Presentation Speech 1214-4.jpg', '', 0, '2020-01-12 17:00:36', '2020-01-12 17:00:36'),
(511, 'BOYA BY-MM1 Microphone For YouTube Vlogging Facebook Livestream Video Recording Mini Mic for DJI Osmo Action/Osmo Pocket/iPhone Huawei Smartphone and DSLR Cameras', '', 'uploads/1578827074BOYA by-MM1 Microphone For YouTube Vlogging Facebook Livestream Video Recording Mini Mic for DJI Osmo ActionOsmo PocketiPhone Huawei Smartphone and DSLR Cameras 1215-3.jpg', '', 0, '2020-01-12 17:04:34', '2020-01-12 17:04:34'),
(512, 'BOYA BY-MM1 Microphone For YouTube Vlogging Facebook Livestream Video Recording Mini Mic for DJI Osmo Action/Osmo Pocket/iPhone Huawei Smartphone and DSLR Cameras', '', 'uploads/1578827074BOYA by-MM1 Microphone For YouTube Vlogging Facebook Livestream Video Recording Mini Mic for DJI Osmo ActionOsmo PocketiPhone Huawei Smartphone and DSLR Cameras 1215-2.jpg', '', 0, '2020-01-12 17:04:34', '2020-01-12 17:04:34'),
(513, 'BOYA BY-MM1 Microphone For YouTube Vlogging Facebook Livestream Video Recording Mini Mic for DJI Osmo Action/Osmo Pocket/iPhone Huawei Smartphone and DSLR Cameras', '', 'uploads/1578827074BOYA by-MM1 Microphone For YouTube Vlogging Facebook Livestream Video Recording Mini Mic for DJI Osmo ActionOsmo PocketiPhone Huawei Smartphone and DSLR Cameras 1215-1.jpg', '', 0, '2020-01-12 17:04:34', '2020-01-12 17:04:34'),
(514, 'BOYA BY-WFM12 VHF Wireless Lavalier Microphone System 12 Channel Super-Cardioid for DSLR Camcorder Audio Recorder Tablet PC Smartphone Presentation Interview Filmmaking Real Time Monitor', '', 'uploads/1578827383BOYA BY-WFM12 VHF Wireless Lavalier Microphone System 12 Channel Super-Cardioid for DSLR Camcorder Audio Recorder Tablet PC Smartphone Presentation Interview Filmmaking Real Time Monitor 1216-3.jpg', '', 0, '2020-01-12 17:09:43', '2020-01-12 17:09:43'),
(515, 'BOYA BY-WFM12 VHF Wireless Lavalier Microphone System 12 Channel Super-Cardioid for DSLR Camcorder Audio Recorder Tablet PC Smartphone Presentation Interview Filmmaking Real Time Monitor', '', 'uploads/1578827383BOYA BY-WFM12 VHF Wireless Lavalier Microphone System 12 Channel Super-Cardioid for DSLR Camcorder Audio Recorder Tablet PC Smartphone Presentation Interview Filmmaking Real Time Monitor 1216-5.jpg', '', 0, '2020-01-12 17:09:43', '2020-01-12 17:09:43'),
(516, 'BOYA BY-WFM12 VHF Wireless Lavalier Microphone System 12 Channel Super-Cardioid for DSLR Camcorder Audio Recorder Tablet PC Smartphone Presentation Interview Filmmaking Real Time Monitor', '', 'uploads/1578827383BOYA BY-WFM12 VHF Wireless Lavalier Microphone System 12 Channel Super-Cardioid for DSLR Camcorder Audio Recorder Tablet PC Smartphone Presentation Interview Filmmaking Real Time Monitor 1216-2.jpg', '', 0, '2020-01-12 17:09:43', '2020-01-12 17:09:43'),
(517, 'BOYA BY-BM2021 Cardioid On Camera Shotgun Microphone with 3.5mm TRS TRRS Cable Connector / Microphone for Camcorder Smartphone DSLR ', '', 'uploads/1578827588BOYA BY-BM2021 Cardioid On Camera Shotgun Microphone with 3.5mm TRS TRRS Cable Connector  Microphone for Camcorder Smartphone DSLR  1217-2.jpg', '', 0, '2020-01-12 17:13:08', '2020-01-12 17:13:08'),
(518, 'BOYA BY-BM2021 Cardioid On Camera Shotgun Microphone with 3.5mm TRS TRRS Cable Connector / Microphone for Camcorder Smartphone DSLR ', '', 'uploads/1578827588BOYA BY-BM2021 Cardioid On Camera Shotgun Microphone with 3.5mm TRS TRRS Cable Connector  Microphone for Camcorder Smartphone DSLR  1217-3.jpg', '', 0, '2020-01-12 17:13:08', '2020-01-12 17:13:08'),
(519, 'BOYA BY-BM2021 Cardioid On Camera Shotgun Microphone with 3.5mm TRS TRRS Cable Connector / Microphone for Camcorder Smartphone DSLR ', '', 'uploads/1578827588BOYA BY-BM2021 Cardioid On Camera Shotgun Microphone with 3.5mm TRS TRRS Cable Connector  Microphone for Camcorder Smartphone DSLR  1217-4.jpg', '', 0, '2020-01-12 17:13:08', '2020-01-12 17:13:08'),
(520, 'BOYA BY-BM2021 Cardioid On Camera Shotgun Microphone with 3.5mm TRS TRRS Cable Connector / Microphone for Camcorder Smartphone DSLR ', '', 'uploads/1578827588BOYA BY-BM2021 Cardioid On Camera Shotgun Microphone with 3.5mm TRS TRRS Cable Connector  Microphone for Camcorder Smartphone DSLR  1217-5.jpg', '', 0, '2020-01-12 17:13:08', '2020-01-12 17:13:08'),
(521, 'BM100FX High Performance Condenser Microphone For YouTube Studio, Radio Braodcasting, Singing Recording With Mini Tripod, Pop filter & Studio Microphone Stand', '', 'uploads/1578828835BM100FX High Performance Condenser Microphone For YouTube Studio, Radio Braodcasting, Singing Recording With Mini Tripod, Pop filter & Studio Microphone Stand 1218-2.jpg', '', 0, '2020-01-12 17:33:55', '2020-01-12 17:33:55'),
(522, 'BM100FX High Performance Condenser Microphone For YouTube Studio, Radio Braodcasting, Singing Recording With Mini Tripod, Pop filter & Studio Microphone Stand', '', 'uploads/1578828835BM100FX High Performance Condenser Microphone For YouTube Studio, Radio Braodcasting, Singing Recording With Mini Tripod, Pop filter & Studio Microphone Stand 1218-4.jpg', '', 0, '2020-01-12 17:33:55', '2020-01-12 17:33:55'),
(523, 'BM100FX High Performance Condenser Microphone For YouTube Studio, Radio Braodcasting, Singing Recording With Mini Tripod, Pop filter & Studio Microphone Stand', '', 'uploads/1578828835BM100FX High Performance Condenser Microphone For YouTube Studio, Radio Braodcasting, Singing Recording With Mini Tripod, Pop filter & Studio Microphone Stand 1218-5.jpg', '', 0, '2020-01-12 17:33:55', '2020-01-12 17:33:55'),
(524, 'Boya Lavalier Wireless Microphone BY-WM5 Portable Transmitter Set Microphones For DSLR Camera Camcorder Audio Recorder Mic', '', 'uploads/1578830611Boya Lavalier Wireless Microphone BY-WM5 Portable Transmitter Set Microphones For DSLR Camera Camcorder Audio Recorder Mic 1221-2.jpg', '', 0, '2020-01-12 18:03:31', '2020-01-12 18:03:31'),
(525, 'Boya Lavalier Wireless Microphone BY-WM5 Portable Transmitter Set Microphones For DSLR Camera Camcorder Audio Recorder Mic', '', 'uploads/1578830611Boya Lavalier Wireless Microphone BY-WM5 Portable Transmitter Set Microphones For DSLR Camera Camcorder Audio Recorder Mic 1221-1.jpg', '', 0, '2020-01-12 18:03:31', '2020-01-12 18:03:31'),
(526, 'Boya Lavalier Wireless Microphone BY-WM5 Portable Transmitter Set Microphones For DSLR Camera Camcorder Audio Recorder Mic', '', 'uploads/1578830611Boya Lavalier Wireless Microphone BY-WM5 Portable Transmitter Set Microphones For DSLR Camera Camcorder Audio Recorder Mic 1221-3.jpg', '', 0, '2020-01-12 18:03:31', '2020-01-12 18:03:31'),
(527, 'Boya Lavalier Wireless Microphone BY-WM5 Portable Transmitter Set Microphones For DSLR Camera Camcorder Audio Recorder Mic', '', 'uploads/1578830611Boya Lavalier Wireless Microphone BY-WM5 Portable Transmitter Set Microphones For DSLR Camera Camcorder Audio Recorder Mic 1221-4.jpg', '', 0, '2020-01-12 18:03:31', '2020-01-12 18:03:31'),
(528, 'Havit M60 Mini Microphone - Black', '', 'uploads/1578831333Havit M60 Mini Microphone - Black 1222-1.jpg', '', 0, '2020-01-12 18:15:33', '2020-01-12 18:15:33'),
(529, 'Havit M60 Mini Microphone - Black', '', 'uploads/1578831333Havit M60 Mini Microphone - Black 1222-4.jpg', '', 0, '2020-01-12 18:15:33', '2020-01-12 18:15:33'),
(530, 'Havit M60 Mini Microphone - Black', '', 'uploads/1578831333Havit M60 Mini Microphone - Black 1222-3.jpg', '', 0, '2020-01-12 18:15:33', '2020-01-12 18:15:33'),
(531, 'HAVIT HV-M80 Budget Friendly Desk Microphone for PC', '', 'uploads/1578831427HAVIT HV-M80 Budget Friendly Desk Microphone for PC 1223-1.jpg', '', 0, '2020-01-12 18:17:07', '2020-01-12 18:17:07'),
(532, 'HAVIT HV-M80 Budget Friendly Desk Microphone for PC', '', 'uploads/1578831427HAVIT HV-M80 Budget Friendly Desk Microphone for PC 1223-3.jpg', '', 0, '2020-01-12 18:17:07', '2020-01-12 18:17:07'),
(533, 'HAVIT HV-M80 Budget Friendly Desk Microphone for PC', '', 'uploads/1578831427HAVIT HV-M80 Budget Friendly Desk Microphone for PC 1223-4.jpg', '', 0, '2020-01-12 18:17:07', '2020-01-12 18:17:07'),
(534, 'Ahuja UTP-30 Lavaliers clip Microphone with long cable (6m) / clip microphone for Interviews and Recordings', '', 'uploads/1578831625Ahuja UTP-30 Lavaliers clip Microphone with long cable (6m)  clip microphone for Interviews and Recordings 1226-2.jpg', '', 0, '2020-01-12 18:20:25', '2020-01-12 18:20:25'),
(535, 'Ahuja UTP-30 Lavaliers clip Microphone with long cable (6m) / clip microphone for Interviews and Recordings', '', 'uploads/1578831625Ahuja UTP-30 Lavaliers clip Microphone with long cable (6m)  clip microphone for Interviews and Recordings 1226-1.jpg', '', 0, '2020-01-12 18:20:25', '2020-01-12 18:20:25'),
(536, 'BM800 Microphone- High Performance Condenser Microphone For YouTube Studio, Radio Braodcasting, Singing Recording With Shock Mount Kit', '', 'uploads/1578832826BM800 Microphone- High Performance Condenser Microphone For YouTube Studio, Radio Braodcasting, Singing Recording With Shock Mount Kit 1227-3.jpg', '', 0, '2020-01-12 18:40:26', '2020-01-12 18:40:26'),
(537, 'BM800 Microphone- High Performance Condenser Microphone For YouTube Studio, Radio Braodcasting, Singing Recording With Shock Mount Kit', '', 'uploads/1578832826BM800 Microphone- High Performance Condenser Microphone For YouTube Studio, Radio Braodcasting, Singing Recording With Shock Mount Kit 1227-1.jpg', '', 0, '2020-01-12 18:40:26', '2020-01-12 18:40:26'),
(538, 'BM800 Microphone- High Performance Condenser Microphone For YouTube Studio, Radio Braodcasting, Singing Recording With Shock Mount Kit', '', 'uploads/1578832826BM800 Microphone- High Performance Condenser Microphone For YouTube Studio, Radio Braodcasting, Singing Recording With Shock Mount Kit 1227-2.jpg', '', 0, '2020-01-12 18:40:26', '2020-01-12 18:40:26'),
(539, '1 Channel 48V Phantom Power Supply For Condenser Microphone / Low-noise For Audio Condenser Microphone Recording Equipment / 5 feet USB Cable XLR 3Pin Microphone Cable for Any Condenser Microphone', '', 'uploads/15788330191 Channel 48V Phantom Power Supply For Condenser Microphone  Low-noise For Audio Condenser Microphone Recording Equipment  5 feet USB Cable XLR 3Pin Microphone Cable for Any Condenser Microphone 1228-2.jpg', '', 0, '2020-01-12 18:43:39', '2020-01-12 18:43:39'),
(540, '1 Channel 48V Phantom Power Supply For Condenser Microphone / Low-noise For Audio Condenser Microphone Recording Equipment / 5 feet USB Cable XLR 3Pin Microphone Cable for Any Condenser Microphone', '', 'uploads/15788330201 Channel 48V Phantom Power Supply For Condenser Microphone  Low-noise For Audio Condenser Microphone Recording Equipment  5 feet USB Cable XLR 3Pin Microphone Cable for Any Condenser Microphone 1228-5.jpg', '', 0, '2020-01-12 18:43:40', '2020-01-12 18:43:40'),
(541, '1 Channel 48V Phantom Power Supply For Condenser Microphone / Low-noise For Audio Condenser Microphone Recording Equipment / 5 feet USB Cable XLR 3Pin Microphone Cable for Any Condenser Microphone', '', 'uploads/15788330201 Channel 48V Phantom Power Supply For Condenser Microphone  Low-noise For Audio Condenser Microphone Recording Equipment  5 feet USB Cable XLR 3Pin Microphone Cable for Any Condenser Microphone 1228-3.jpg', '', 0, '2020-01-12 18:43:40', '2020-01-12 18:43:40'),
(542, '1 Channel 48V Phantom Power Supply For Condenser Microphone / Low-noise For Audio Condenser Microphone Recording Equipment / 5 feet USB Cable XLR 3Pin Microphone Cable for Any Condenser Microphone', '', 'uploads/15788330201 Channel 48V Phantom Power Supply For Condenser Microphone  Low-noise For Audio Condenser Microphone Recording Equipment  5 feet USB Cable XLR 3Pin Microphone Cable for Any Condenser Microphone 1228-4.jpg', '', 0, '2020-01-12 18:43:40', '2020-01-12 18:43:40'),
(543, 'BOYA BY-VM600 Cardioid Directional Condenser Microphone Mic For DSLR Camera Video camera', '', 'uploads/1578833682BOYA BY-VM600 Cardioid Directional Condenser Microphone Mic For DSLR Camera Video camera 1229-5.jpg', '', 0, '2020-01-12 18:54:42', '2020-01-12 18:54:42'),
(544, 'BOYA BY-VM600 Cardioid Directional Condenser Microphone Mic For DSLR Camera Video camera', '', 'uploads/1578833682BOYA BY-VM600 Cardioid Directional Condenser Microphone Mic For DSLR Camera Video camera 1229-2.jpg', '', 0, '2020-01-12 18:54:42', '2020-01-12 18:54:42'),
(545, 'BOYA BY-VM600 Cardioid Directional Condenser Microphone Mic For DSLR Camera Video camera', '', 'uploads/1578833682BOYA BY-VM600 Cardioid Directional Condenser Microphone Mic For DSLR Camera Video camera 1229-3.jpg', '', 0, '2020-01-12 18:54:42', '2020-01-12 18:54:42'),
(546, 'BOYA BY-DM1 Professional Lightning Lavalier clip Microphone for iPhone iPad Mini iPad Pro iPad Air 2 iPod', '', 'uploads/1578833912BOYA BY-DM1 Professional Lightning Lavalier clip Microphone for iPhone iPad Mini iPad Pro iPad Air 2 iPod 1230-3.jpg', '', 0, '2020-01-12 18:58:32', '2020-01-12 18:58:32'),
(547, 'BOYA BY-DM1 Professional Lightning Lavalier clip Microphone for iPhone iPad Mini iPad Pro iPad Air 2 iPod', '', 'uploads/1578833912BOYA BY-DM1 Professional Lightning Lavalier clip Microphone for iPhone iPad Mini iPad Pro iPad Air 2 iPod 1230-2.jpg', '', 0, '2020-01-12 18:58:32', '2020-01-12 18:58:32'),
(548, 'BOYA BY-DM1 Professional Lightning Lavalier clip Microphone for iPhone iPad Mini iPad Pro iPad Air 2 iPod', '', 'uploads/1578833912BOYA BY-DM1 Professional Lightning Lavalier clip Microphone for iPhone iPad Mini iPad Pro iPad Air 2 iPod 1230-1.jpg', '', 0, '2020-01-12 18:58:32', '2020-01-12 18:58:32'),
(549, 'ZOMEI 18 inch Premium Quality LED Ring Light Full Set With Stand And Carry Bag / 50W 5500K Lighting Kit with Color Filter, Hot Shoe Adapter for Lighting for Makeup Camera Smartphone YouTube Video Shooting', '', 'uploads/1578835010zomei-18-inch-premium-quality-led-ring-light-full-set-with-stand-and-carry-bag--50w-5500k-lighting-kit-with-color-filter-hot-shoe-adapter-for-lighting-for-makeup-camera-smartphone-youtube 1231-1.jpg', '', 0, '2020-01-12 19:16:50', '2020-01-12 19:16:50'),
(550, 'ZOMEI 18 inch Premium Quality LED Ring Light Full Set With Stand And Carry Bag / 50W 5500K Lighting Kit with Color Filter, Hot Shoe Adapter for Lighting for Makeup Camera Smartphone YouTube Video Shooting', '', 'uploads/1578835010zomei-18-inch-premium-quality-led-ring-light-full-set-with-stand-and-carry-bag--50w-5500k-lighting-kit-with-color-filter-hot-shoe-adapter-for-lighting-for-makeup-camera-smartphone-youtube 1231-2.jpg', '', 0, '2020-01-12 19:16:50', '2020-01-12 19:16:50'),
(551, 'ZOMEI 18 inch Premium Quality LED Ring Light Full Set With Stand And Carry Bag / 50W 5500K Lighting Kit with Color Filter, Hot Shoe Adapter for Lighting for Makeup Camera Smartphone YouTube Video Shooting', '', 'uploads/1578835010zomei-18-inch-premium-quality-led-ring-light-full-set-with-stand-and-carry-bag--50w-5500k-lighting-kit-with-color-filter-hot-shoe-adapter-for-lighting-for-makeup-camera-smartphone-youtube 1231-3.jpg', '', 0, '2020-01-12 19:16:50', '2020-01-12 19:16:50'),
(552, 'ZOMEI 18 inch Premium Quality LED Ring Light Full Set With Stand And Carry Bag / 50W 5500K Lighting Kit with Color Filter, Hot Shoe Adapter for Lighting for Makeup Camera Smartphone YouTube Video Shooting', '', 'uploads/1578835010zomei-18-inch-premium-quality-led-ring-light-full-set-with-stand-and-carry-bag--50w-5500k-lighting-kit-with-color-filter-hot-shoe-adapter-for-lighting-for-makeup-camera-smartphone-youtube 1231-4.jpg', '', 0, '2020-01-12 19:16:50', '2020-01-12 19:16:50'),
(553, 'Global Version Original Xiaomi Mi TV Box S / 4K HDR Android TV Box With Google Assistant Voice Remote', '', 'uploads/1578835165Original Xiaomi Mi TV Box S  4K HDR Android TV Box With Google Assistant Voice Remote 1232-1.jpg', '', 0, '2020-01-12 19:19:25', '2020-01-12 19:19:25'),
(554, 'Global Version Original Xiaomi Mi TV Box S / 4K HDR Android TV Box With Google Assistant Voice Remote', '', 'uploads/1578835165Original Xiaomi Mi TV Box S  4K HDR Android TV Box With Google Assistant Voice Remote 1232-2.jpg', '', 0, '2020-01-12 19:19:25', '2020-01-12 19:19:25'),
(555, 'Global Version Original Xiaomi Mi TV Box S / 4K HDR Android TV Box With Google Assistant Voice Remote', '', 'uploads/1578835165Original Xiaomi Mi TV Box S  4K HDR Android TV Box With Google Assistant Voice Remote 1232-4.jpg', '', 0, '2020-01-12 19:19:25', '2020-01-12 19:19:25'),
(556, 'hot product romjan', 'dddd', 'G:\\XAMPP\\htdocs\\first_laravel_ecomerce\\public/uploads/187/187.01.png', '', 187, '2020-05-20 12:32:46', '2020-05-20 12:32:46'),
(557, 'new', '555', 'G:\\XAMPP\\htdocs\\first_laravel_ecomerce\\public/uploads/188/188.03-44-02-07-10-2019-14910507_1085776081536990_58939388760083820_n.jpg', '', 188, '2020-05-20 12:36:24', '2020-05-20 12:36:24'),
(558, 'sujon product price', '555', 'G:\\XAMPP\\htdocs\\first_laravel_ecomerce\\public/uploads/189/189.1573378123gf-min-min.png', '', 189, '2020-05-20 18:42:27', '2020-05-20 18:42:27'),
(559, 'ddd', '55', 'uploads/190/190.1573378123gf-min-min.png', '', 190, '2020-05-20 18:47:32', '2020-05-20 18:47:32'),
(560, 'tumi ki', '5', 'uploads/191/191.01.png', '', 191, '2020-05-20 18:59:41', '2020-05-20 18:59:41'),
(561, '27 romjan product', '555', 'uploads/192/192.1.png', '', 192, '2020-05-20 19:16:00', '2020-05-20 19:16:00'),
(562, '27 romjan product', '555', 'uploads/192/54.1.jpg', '', 192, '2020-05-20 19:16:01', '2020-05-20 19:16:01'),
(563, '27 romjan product', '555', 'uploads/192/78.1.jpeg', '', 192, '2020-05-20 19:16:01', '2020-05-20 19:16:01'),
(564, '27 romjan product', '555', 'uploads/192/29.2.jpeg', '', 192, '2020-05-20 19:16:01', '2020-05-20 19:16:01'),
(565, '27 romjan product', '555', 'uploads/192/61.2.png', '', 192, '2020-05-20 19:16:01', '2020-05-20 19:16:01'),
(566, '27 romjan product', '555', 'uploads/192/11.2.jpg', '', 192, '2020-05-20 19:16:01', '2020-05-20 19:16:01'),
(567, '27 romjan product', '555', 'uploads/192/99.5-.jpg', '', 192, '2020-05-20 19:16:02', '2020-05-20 19:16:02'),
(568, 'f', '22', 'uploads/193/193.1-273x273.jpg', '', 193, '2020-05-20 19:29:27', '2020-05-20 19:29:27'),
(569, 'gggg', '2222', 'uploads/194/194.2-1_b77ada4c_thumb_thumb.jpg', '', 194, '2020-05-20 19:33:36', '2020-05-20 19:33:36'),
(570, 'gggg', '2222', 'uploads/194/53.2-1_b77ada4c-273x273.jpg', '', 194, '2020-05-20 19:33:36', '2020-05-20 19:33:36'),
(571, 'new product of sujon', '25', 'uploads/191/195.25.5.3.jpg', '', 195, '2020-05-21 06:31:03', '2020-05-21 06:31:03'),
(572, 'ecomerce first product of sujon', '1', 'uploads/196/196.537.jpg', '', 196, '2020-05-21 06:35:32', '2020-05-21 06:35:32'),
(573, 'ecomerce first product of sujon', '1', 'uploads/196/40.180.jpg', '', 196, '2020-05-21 06:35:32', '2020-05-21 06:35:32'),
(574, 'product image 2', '55', 'uploads/197/197.2-1_b77ada4c.jpg', 'featured_image', 197, '2020-05-21 07:19:47', '2020-05-21 07:19:47'),
(575, 'product image 2', '55', 'uploads/197/62.2-1_b77ada4c-208x185.jpg', 'galary_image1', 197, '2020-05-21 07:06:40', '2020-05-21 07:06:40'),
(576, 'new price product', '1254', 'uploads/198/198.1-273x273.jpg', 'featured_image', 198, '2020-05-21 08:27:43', '2020-05-21 08:27:43'),
(577, 'Hot product of banglades', '123', 'uploads/199/199.1205.2.jpg', 'featured_image', 199, '2020-05-22 08:52:18', '2020-05-22 08:52:18'),
(578, 'Hot product of banglades', '123', 'uploads/199/68.322.jpg', 'galary_image1', 199, '2020-05-22 08:52:19', '2020-05-22 08:52:19'),
(579, 'Hot product of banglades', '123', 'uploads/199/10.4-273x273.jpg', 'galary_image2', 199, '2020-05-22 08:52:19', '2020-05-22 08:52:19'),
(580, 'Hot product of banglades', '123', 'uploads/199/33.104.jpg', 'galary_image3', 199, '2020-05-22 08:52:19', '2020-05-22 08:52:19'),
(581, 'Hot product of banglades', '123', 'uploads/199/76.7-273x273.jpg', 'galary_image4', 199, '2020-05-22 08:52:19', '2020-05-22 08:52:19'),
(582, 'Hot product of banglades', '123', 'uploads/199/57.4-tap-3509.jpg', 'galary_image5', 199, '2020-05-22 08:52:19', '2020-05-22 08:52:19'),
(583, 'Hot product of banglades', '123', 'uploads/199/58.104 copy.jpg', 'galary_image6', 199, '2020-05-22 08:52:19', '2020-05-22 08:52:19'),
(584, 'ehhf product preice', '521', 'uploads/238/239.Chrysanthemum.jpg', 'featured_image', 239, '2020-06-08 04:29:17', '2020-06-08 04:29:17'),
(585, 'sumon product', '3333', 'uploads/240/240.1578586554Silicone Gloves Magic Silicone Dish Washing Glove Household Scrubber Rubber Kitchen Cleaning Tool Kitchen Gloves 1191-3.jpg', 'featured_image', 240, '2020-06-24 03:58:56', '2020-06-24 03:58:56'),
(586, 'webp imageproduct', '44', 'uploads/241/241.bengal-meat-beef-keema-net-weight-50-gm-1-kg.webp', 'featured_image', 241, '2020-06-24 13:45:51', '2020-06-24 13:45:51'),
(587, 'web p 2', '333', 'uploads/242/242.Hydrangeas.webp', 'featured_image', 242, '2020-06-24 14:00:45', '2020-06-24 14:00:45'),
(588, 'best watch collection', '353', 'uploads/243/252.PicsArt_07-28-10.52.37.jpg', 'featured_image', 252, '2020-06-28 17:52:35', '2020-06-28 17:52:35'),
(589, 'best watch collection', '353', 'uploads/243/70.Chrysanthemum.jpg', 'galary_image1', 252, '2020-06-28 17:52:36', '2020-06-28 17:52:36'),
(590, 'best watch collection', '353', 'uploads/243/15.Hydrangeas.jpg', 'galary_image2', 252, '2020-06-28 17:52:36', '2020-06-28 17:52:36'),
(591, 'best watch collection', '353', 'uploads/243/40.Jellyfish.jpg', 'galary_image3', 252, '2020-06-28 17:52:36', '2020-06-28 17:52:36'),
(592, 'hot product of sujon ali', '333', 'uploads/253/253.Hydrangeas.jpg', 'featured_image', 253, '2020-06-28 17:56:51', '2020-06-28 17:56:51'),
(593, 'hot product of sujon ali', '333', 'uploads/253/23.Tulips.jpg', 'galary_image1', 253, '2020-06-28 17:56:51', '2020-06-28 17:56:51'),
(594, 'hot product of sujon ali', '333', 'uploads/253/27.Chrysanthemum.jpg', 'galary_image2', 253, '2020-06-28 17:56:51', '2020-06-28 17:56:51'),
(595, 'sujon product', '4', 'uploads/254/254.1.jpg', 'featured_image', 254, '2020-06-28 18:13:14', '2020-06-28 18:13:14'),
(596, 'sujon product', '4', 'uploads/254/10.Penguins.jpg', 'galary_image1', 254, '2020-06-28 18:06:22', '2020-06-28 18:06:22'),
(597, 'sujon product', '4', 'uploads/254/88.Jellyfish.jpg', 'galary_image2', 254, '2020-06-28 18:06:23', '2020-06-28 18:06:23'),
(598, 'sujon product', '4', 'uploads/254/70.Koala.jpg', 'galary_image3', 254, '2020-06-28 18:06:23', '2020-06-28 18:06:23'),
(599, 'sujon product', '4', 'uploads/254/48.Hydrangeas.jpg', 'galary_image4', 254, '2020-06-28 18:06:24', '2020-06-28 18:06:24'),
(600, 'sujon product', '4', 'uploads/254/86.Tulips.jpg', 'galary_image5', 254, '2020-06-28 18:06:24', '2020-06-28 18:06:24'),
(601, 'sujon product', '4', 'uploads/254/78.Penguins.jpg', 'galary_image6', 254, '2020-06-28 18:06:25', '2020-06-28 18:06:25');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE `newsletter` (
  `newsletter_id` int(11) NOT NULL,
  `newsletter_email` varchar(155) NOT NULL,
  `created_time` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`newsletter_id`, `newsletter_email`, `created_time`, `status`) VALUES
(9, 'ss@hhhh.jjj', '2019-12-12 09:10:39', 0),
(10, 'ssf@ggg.jjj', '2019-12-17 03:22:42', 0),
(11, 'ssf@ggg.jjj', '2019-12-17 03:22:45', 0),
(12, 'ff@ffffgg.jjjj', '2020-01-04 05:12:22', 0);

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `option_id` int(11) NOT NULL,
  `option_name` varchar(255) DEFAULT NULL,
  `option_value` mediumtext CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`option_id`, `option_name`, `option_value`) VALUES
(59, 'home_page_category_id', '58,65'),
(60, 'logo', 'g'),
(61, 'icon', 'http://localhost/first_laravel_ecomerce/adnib'),
(62, 'site_title', 'Tanzirbd Online Ecommerce Shop'),
(63, 'order_image', NULL),
(64, 'phone', '017383059555'),
(65, 'phone_order', '<i class=\"fa fa-phone-square\" style=\"padding-left:20px;color: green;\">   </i> 01760 442 442 <br>\r\n <i class=\"fa fa-phone-square\" style=\"padding-left:20px;color: green;\"> </i> 01841 305 335 <br>'),
(66, 'address', NULL),
(67, 'admin_email', 'ssss'),
(68, 'shipping_charge_in_dhaka', '60'),
(69, 'shipping_charge_out_of_dhaka', '120'),
(70, 'footer', NULL),
(71, 'google_map', NULL),
(72, 'copyright', NULL),
(73, 'default_product_terms', '44444444444444'),
(74, 'home_cat_section', '58,65'),
(75, 'home_seo_title', NULL),
(76, 'home_seo_content', NULL),
(77, 'home_seo_keywords', NULL),
(78, 'home_about_title', NULL),
(79, 'home_about_content', NULL),
(80, 'bkash', '076544444');

-- --------------------------------------------------------

--
-- Table structure for table `order_data`
--

CREATE TABLE `order_data` (
  `order_id` bigint(200) NOT NULL,
  `created_by` varchar(55) CHARACTER SET utf8 DEFAULT 'customer',
  `staff_id` int(11) DEFAULT NULL,
  `order_total` varchar(155) NOT NULL,
  `shipping_charge` int(11) DEFAULT NULL,
  `order_status` varchar(55) CHARACTER SET utf8 NOT NULL DEFAULT 'new',
  `payment_type` varchar(55) CHARACTER SET utf8 DEFAULT NULL,
  `products` text CHARACTER SET utf8 NOT NULL,
  `courier_service` varchar(155) CHARACTER SET utf8 DEFAULT NULL,
  `shipment_time` datetime DEFAULT NULL,
  `created_time` datetime NOT NULL,
  `order_date` date NOT NULL,
  `modified_time` datetime DEFAULT NULL,
  `customer_name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `customer_phone` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `customer_email` varchar(250) DEFAULT NULL,
  `customer_address` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `delevery_address` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `order_area` varchar(255) DEFAULT NULL,
  `order_note` text,
  `discount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_data`
--

INSERT INTO `order_data` (`order_id`, `created_by`, `staff_id`, `order_total`, `shipping_charge`, `order_status`, `payment_type`, `products`, `courier_service`, `shipment_time`, `created_time`, `order_date`, `modified_time`, `customer_name`, `customer_phone`, `customer_email`, `customer_address`, `delevery_address`, `order_area`, `order_note`, `discount`) VALUES
(268, 'customer', NULL, '6490', 0, 'new', NULL, 'a:1:{s:5:\"items\";a:2:{i:238;a:7:{s:14:\"featured_image\";s:136:\"http://localhost/sopnershop/uploads/1571830915wifi-ip-security-camera-wireless-cctv-camera-for-home-and-office-security 1001-7_thumb.jpg\";s:3:\"qty\";s:1:\"1\";s:5:\"price\";s:8:\"1,990.00\";s:8:\"subtotal\";s:8:\"1,990.00\";s:4:\"size\";s:0:\"\";s:5:\"color\";s:0:\"\";s:4:\"name\";s:73:\"WiFi IP Security Camera wireless CCTV Camera for home and office security\";}i:237;a:7:{s:14:\"featured_image\";s:70:\"http://localhost/sopnershop/uploads/29-50-06-17-10-2019-head_thumb.jpg\";s:3:\"qty\";s:1:\"2\";s:5:\"price\";s:8:\"2,250.00\";s:8:\"subtotal\";s:8:\"4,500.00\";s:4:\"size\";s:0:\"\";s:5:\"color\";s:0:\"\";s:4:\"name\";s:18:\"KONIYCOI KT-2100MV\";}}}', NULL, '2019-11-25 04:57:55', '2019-11-25 04:57:55', '0000-00-00', '2019-11-25 00:00:00', 'Shahinul islam', '01738305670', 'suzonice15@gmail.com', 'gg', '', 'outside', '', 0),
(269, 'customer', NULL, '5830', 0, 'try', NULL, '', NULL, '2019-11-25 17:54:06', '2019-11-25 17:54:06', '0000-00-00', '2019-11-25 00:00:00', 'Shahinul islam', '01738305670', '', '', '', '', '', 0),
(270, 'customer', NULL, '10140', 0, 'new', '', 'a:1:{s:5:\"items\";a:4:{i:145;a:7:{s:4:\"Size\";s:2:\"39\";s:5:\"Color\";s:5:\"Black\";s:3:\"qty\";s:1:\"2\";s:14:\"featured_image\";s:90:\"http://localhost/sopnershop/uploads/46-03-04-06-09-2019-usb-mosquito-killer-lamp_thumb.jpg\";s:5:\"price\";s:6:\"100.00\";s:4:\"name\";s:85:\"USB লাইটিং মস্কুইটো কিলার ল্যাম্প\";s:8:\"subtotal\";s:6:\"200.00\";}i:199;a:7:{s:4:\"Size\";s:0:\"\";s:5:\"Color\";s:0:\"\";s:3:\"qty\";s:1:\"3\";s:14:\"featured_image\";s:81:\"http://localhost/sopnershop/uploads/12-56-05-17-10-2019-Liqua-Gold-Leaf_thumb.jpg\";s:5:\"price\";s:6:\"400.00\";s:4:\"name\";s:16:\"Liqua Gold Leaf \";s:8:\"subtotal\";s:7:\"1200.00\";}i:237;a:7:{s:4:\"Size\";s:0:\"\";s:5:\"Color\";s:0:\"\";s:3:\"qty\";s:1:\"3\";s:14:\"featured_image\";s:70:\"http://localhost/sopnershop/uploads/29-50-06-17-10-2019-head_thumb.jpg\";s:5:\"price\";s:7:\"2250.00\";s:4:\"name\";s:18:\"KONIYCOI KT-2100MV\";s:8:\"subtotal\";s:7:\"6750.00\";}i:238;a:7:{s:4:\"Size\";s:0:\"\";s:5:\"Color\";s:5:\"White\";s:3:\"qty\";s:1:\"1\";s:14:\"featured_image\";s:136:\"http://localhost/sopnershop/uploads/1571830915wifi-ip-security-camera-wireless-cctv-camera-for-home-and-office-security 1001-7_thumb.jpg\";s:5:\"price\";s:7:\"1990.00\";s:4:\"name\";s:73:\"WiFi IP Security Camera wireless CCTV Camera for home and office security\";s:8:\"subtotal\";s:7:\"1990.00\";}}}', NULL, '2019-11-25 12:00:00', '2019-11-25 05:54:12', '0000-00-00', '2019-11-25 00:00:00', 'Shahinul islam', '01738305670', 'suzonice15@gmail.com', 'ddd				', '', 'outside', '', 0),
(273, 'customer', NULL, '190.00', 0, 'try', NULL, '', NULL, '2019-12-02 12:04:24', '2019-12-02 12:04:24', '0000-00-00', '2019-12-02 00:00:00', 'Shahinul islam', '01738305670', '', '', '', '', '', 0),
(275, 'customer', NULL, '77', 0, 'new', NULL, 'a:1:{s:5:\"items\";a:2:{i:241;a:5:{s:3:\"qty\";s:1:\"1\";s:14:\"featured_image\";s:118:\"http://localhost/first_laravel_ecomerce/public/uploads/241/small/241.bengal-meat-beef-keema-net-weight-50-gm-1-kg.webp\";s:5:\"price\";s:2:\"44\";s:4:\"name\";s:17:\"webp imageproduct\";s:8:\"subtotal\";s:2:\"44\";}i:252;a:5:{s:3:\"qty\";s:1:\"1\";s:14:\"featured_image\";s:95:\"http://localhost/first_laravel_ecomerce/public/uploads/243/small/252.PicsArt_07-28-10.52.37.jpg\";s:5:\"price\";s:2:\"33\";s:4:\"name\";s:21:\"best watch collection\";s:8:\"subtotal\";s:2:\"33\";}}}', NULL, '2019-12-02 00:00:00', '2019-12-02 12:05:44', '0000-00-00', '2020-06-28 22:19:16', 'Shahinul islam', '01738305670', NULL, NULL, '', '', NULL, 0),
(279, 'customer', NULL, '890', 0, 'new', NULL, 'a:1:{s:5:\"items\";a:1:{i:224;a:7:{s:4:\"Size\";s:5:\"12222\";s:5:\"Color\";s:3:\"abc\";s:3:\"qty\";s:1:\"1\";s:14:\"featured_image\";s:74:\"http://localhost/sopnershop/uploads/54-35-06-17-10-2019-assembly_thumb.jpg\";s:5:\"price\";s:6:\"790.00\";s:4:\"name\";s:88:\"জাতীয় সংসদ ভবন রেপ্লিকা ভাস্কর্য\";s:8:\"subtotal\";s:6:\"790.00\";}}}', NULL, '2019-12-04 12:11:10', '2019-12-04 12:11:10', '0000-00-00', '2019-12-23 00:00:00', 'Shahinul islam', '01738305670', 'suzonice15@gmail', 'ff		', '', 'outside', '', 0),
(282, 'customer', NULL, '2,500.00', 0, 'try', NULL, '', NULL, '2019-12-05 14:54:15', '2019-12-05 14:54:15', '0000-00-00', '2019-12-05 00:00:00', '', '01738305670', '', '', '', '', '', 0),
(289, 'customer', NULL, '3240', 100, 'new', NULL, 'a:1:{s:5:\"items\";a:1:{i:289;a:1:{s:3:\"qty\";s:1:\"1\";}}}', NULL, '2021-01-08 00:00:00', '2019-12-23 10:16:22', '0000-00-00', '2020-05-28 00:00:00', 'Shahinul islam', '01738300000', NULL, 'Dhaka 1215, mirpu Section 2, 10/12.', '', 'outside', NULL, 0),
(290, 'customer', NULL, '3200', 100, 'new', NULL, 'a:1:{s:5:\"items\";a:2:{i:223;a:7:{s:14:\"featured_image\";s:78:\"http://localhost/sopnershop/uploads/52-34-06-17-10-2019-sound-active_thumb.jpg\";s:3:\"qty\";s:1:\"1\";s:5:\"price\";s:6:\"100.00\";s:8:\"subtotal\";s:6:\"100.00\";s:4:\"size\";s:0:\"\";s:5:\"color\";s:0:\"\";s:4:\"name\";s:44:\"সাউন্ড Activated বার্ড\";}i:220;a:7:{s:14:\"featured_image\";s:73:\"http://localhost/sopnershop/uploads/07-27-06-17-10-2019-sixpack_thumb.jpg\";s:3:\"qty\";s:1:\"1\";s:5:\"price\";s:8:\"3,000.00\";s:8:\"subtotal\";s:8:\"3,000.00\";s:4:\"size\";s:0:\"\";s:5:\"color\";s:0:\"\";s:4:\"name\";s:47:\"সিক্স প্যাক কেয়ার\";}}}', NULL, '2020-01-08 10:33:59', '2020-01-08 10:33:59', '0000-00-00', '2020-01-08 00:00:00', 'Shahinul islam', '01738300000', '', 'Dhaka 1215, mirpu Section 2, 10/12.', '', 'outside', '', 0),
(291, 'customer', NULL, '160', 60, 'new', NULL, 'a:1:{s:5:\"items\";a:1:{i:38;a:7:{s:4:\"Size\";s:5:\"12222\";s:5:\"Color\";s:3:\"abc\";s:3:\"qty\";s:1:\"1\";s:14:\"featured_image\";s:91:\"http://localhost/final_sujon_shop/uploads/41-53-04-05-09-2019-scitech-smart-watch_thumb.jpg\";s:5:\"price\";s:6:\"100.00\";s:4:\"name\";s:19:\"Scitech Smart Watch\";s:8:\"subtotal\";s:6:\"100.00\";}}}', NULL, '2020-12-01 00:00:00', '2020-01-12 10:52:15', '0000-00-00', '2020-01-12 00:00:00', 'sd', '01738305670', '', 'ddd		', '', 'inside', '', 0),
(292, 'customer', NULL, '160', 60, 'new', NULL, 'a:1:{s:5:\"items\";a:1:{i:38;a:7:{s:4:\"Size\";s:0:\"\";s:5:\"Color\";s:0:\"\";s:3:\"qty\";s:1:\"1\";s:14:\"featured_image\";s:91:\"http://localhost/final_sujon_shop/uploads/41-53-04-05-09-2019-scitech-smart-watch_thumb.jpg\";s:5:\"price\";s:6:\"100.00\";s:4:\"name\";s:19:\"Scitech Smart Watch\";s:8:\"subtotal\";s:6:\"100.00\";}}}', NULL, '2020-12-01 00:00:00', '2020-01-12 10:53:59', '0000-00-00', '2020-01-12 00:00:00', 'sd', '01738305670', '', 'ddd		', '', 'inside', '', 0),
(293, 'Shahinul islam sujon', 2, '700', 100, 'new', NULL, 'a:1:{s:5:\"items\";a:3:{i:293;a:1:{s:3:\"qty\";s:1:\"1\";}i:126;a:4:{s:14:\"featured_image\";s:91:\"http://localhost/final_sujon_shop/uploads/20-12-03-06-09-2019-magic-capsul-cutter_thumb.jpg\";s:5:\"price\";s:6:\"100.00\";s:4:\"name\";s:19:\"Magic Capsul Cutter\";s:8:\"subtotal\";s:6:\"100.00\";}i:194;a:4:{s:14:\"featured_image\";s:82:\"http://localhost/final_sujon_shop/uploads/46-47-05-17-10-2019-table-lamp_thumb.jpg\";s:5:\"price\";s:6:\"500.00\";s:4:\"name\";s:10:\"Table Lamp\";s:8:\"subtotal\";s:6:\"500.00\";}}}', NULL, '2020-12-01 00:00:00', '2020-01-12 10:59:18', '0000-00-00', '2020-05-28 00:00:00', 'sddd', '01738305670', 'suzonice@gmail.com', 's', '', '', NULL, 0),
(294, 'Staff', 5, '2250', 50, 'delivered', NULL, 'a:1:{s:5:\"items\";a:1:{i:220;a:5:{s:3:\"qty\";s:1:\"1\";s:14:\"featured_image\";N;s:5:\"price\";s:4:\"2200\";s:4:\"name\";s:158:\"BM100FX High Performance Condenser Microphone For YouTube Studio, Radio Braodcasting, Singing Recording With Mini Tripod, Pop filter & Studio Microphone Stand\";s:8:\"subtotal\";s:4:\"2200\";}}}', NULL, '2020-05-12 00:00:00', '2020-05-29 01:00:10', '2020-05-29', '2020-05-29 00:00:00', 'sujon ali', '01738305670', 'sujon@gmail.com', 'dhaka', NULL, NULL, 'ddd', NULL),
(295, 'Staff', 5, '2710', 100, 'new', NULL, 'a:1:{s:5:\"items\";a:3:{i:295;a:1:{s:3:\"qty\";s:1:\"1\";}i:197;a:4:{s:14:\"featured_image\";s:85:\"http://localhost/first_laravel_ecomerce/public/uploads/197/small/197.2-1_b77ada4c.jpg\";s:5:\"price\";s:3:\"555\";s:4:\"name\";s:15:\"product image 2\";s:8:\"subtotal\";s:4:\"1110\";}i:237;a:4:{s:14:\"featured_image\";s:75:\"http://localhost/first_laravel_ecomerce/public/uploads/187/small/187.01.png\";s:5:\"price\";s:4:\"1500\";s:4:\"name\";s:18:\"hot product romjan\";s:8:\"subtotal\";s:4:\"1500\";}}}', NULL, '2020-05-13 00:00:00', '2020-05-29 01:05:17', '2020-05-29', '2020-06-06 00:00:00', 'abdullla', '01738305670', 'abdullah@com', 'dhaka 1216', NULL, NULL, 'nai', NULL),
(296, 'Staff', 5, '13451', 100, 'new', NULL, 'a:1:{s:5:\"items\";a:6:{i:296;a:1:{s:3:\"qty\";s:1:\"2\";}i:197;a:4:{s:14:\"featured_image\";s:85:\"http://localhost/first_laravel_ecomerce/public/uploads/197/small/197.2-1_b77ada4c.jpg\";s:5:\"price\";s:3:\"555\";s:4:\"name\";s:15:\"product image 2\";s:8:\"subtotal\";s:4:\"1110\";}i:198;a:4:{s:14:\"featured_image\";s:82:\"http://localhost/first_laravel_ecomerce/public/uploads/198/small/198.1-273x273.jpg\";s:5:\"price\";s:3:\"541\";s:4:\"name\";s:17:\"new price product\";s:8:\"subtotal\";s:3:\"541\";}i:199;a:4:{s:14:\"featured_image\";s:79:\"http://localhost/first_laravel_ecomerce/public/uploads/199/small/199.1205.2.jpg\";s:5:\"price\";s:3:\"800\";s:4:\"name\";s:24:\"Hot product of banglades\";s:8:\"subtotal\";s:4:\"1600\";}i:223;a:4:{s:14:\"featured_image\";s:63:\"http://localhost/first_laravel_ecomerce/public/uploads/0/small/\";s:5:\"price\";s:4:\"3550\";s:4:\"name\";s:131:\"BOYA BY-BM2021 Cardioid On Camera Shotgun Microphone with 3.5mm TRS TRRS Cable Connector / Microphone for Camcorder Smartphone DSLR\";s:8:\"subtotal\";s:4:\"7100\";}i:237;a:4:{s:14:\"featured_image\";s:75:\"http://localhost/first_laravel_ecomerce/public/uploads/187/small/187.01.png\";s:5:\"price\";s:4:\"1500\";s:4:\"name\";s:18:\"hot product romjan\";s:8:\"subtotal\";s:4:\"3000\";}}}', NULL, '2020-05-13 00:00:00', '2020-05-29 01:06:39', '2020-05-29', '2020-05-29 00:00:00', 'abdullla', '01738305670', 'abdullah@com', 'dhaka 1216', NULL, NULL, 'nai', NULL),
(297, 'Staff', 5, '2710', 100, 'new', NULL, 'a:1:{s:5:\"items\";a:3:{i:297;a:1:{s:3:\"qty\";s:1:\"1\";}i:197;a:4:{s:14:\"featured_image\";s:85:\"http://localhost/first_laravel_ecomerce/public/uploads/197/small/197.2-1_b77ada4c.jpg\";s:5:\"price\";s:3:\"555\";s:4:\"name\";s:15:\"product image 2\";s:8:\"subtotal\";s:4:\"1110\";}i:237;a:4:{s:14:\"featured_image\";s:75:\"http://localhost/first_laravel_ecomerce/public/uploads/187/small/187.01.png\";s:5:\"price\";s:4:\"1500\";s:4:\"name\";s:18:\"hot product romjan\";s:8:\"subtotal\";s:4:\"1500\";}}}', NULL, '2020-05-13 00:00:00', '2020-05-29 01:07:20', '2020-05-29', '2020-05-29 00:00:00', 'abdullla', '01738305670', 'abdullah@com', 'dhaka 1216', NULL, NULL, 'nai', NULL),
(298, 'Staff', 5, '2955', 100, 'new', NULL, 'a:1:{s:5:\"items\";a:4:{i:298;a:1:{s:3:\"qty\";s:1:\"1\";}i:197;a:4:{s:14:\"featured_image\";s:85:\"http://localhost/first_laravel_ecomerce/public/uploads/197/small/197.2-1_b77ada4c.jpg\";s:5:\"price\";s:3:\"555\";s:4:\"name\";s:15:\"product image 2\";s:8:\"subtotal\";s:3:\"555\";}i:199;a:4:{s:14:\"featured_image\";s:79:\"http://localhost/first_laravel_ecomerce/public/uploads/199/small/199.1205.2.jpg\";s:5:\"price\";s:3:\"800\";s:4:\"name\";s:24:\"Hot product of banglades\";s:8:\"subtotal\";s:3:\"800\";}i:237;a:4:{s:14:\"featured_image\";s:75:\"http://localhost/first_laravel_ecomerce/public/uploads/187/small/187.01.png\";s:5:\"price\";s:4:\"1500\";s:4:\"name\";s:18:\"hot product romjan\";s:8:\"subtotal\";s:4:\"1500\";}}}', NULL, '2020-05-13 00:00:00', '2020-05-29 01:08:08', '2020-05-29', '2020-05-29 00:00:00', 'abdullla', '01738305670', 'abdullah@com', 'dhaka 1216', NULL, NULL, 'nai', NULL),
(299, 'Customer', 0, '2620', 60, 'new', NULL, 'a:1:{s:5:\"items\";a:4:{i:239;a:5:{s:14:\"featured_image\";s:86:\"http://localhost/first_laravel_ecomerce/public/uploads/238/thumb/239.Chrysanthemum.jpg\";s:3:\"qty\";s:1:\"1\";s:5:\"price\";s:3:\"600\";s:8:\"subtotal\";s:3:\"600\";s:4:\"name\";s:19:\"ehhf product preice\";}i:199;a:5:{s:14:\"featured_image\";s:79:\"http://localhost/first_laravel_ecomerce/public/uploads/199/thumb/199.1205.2.jpg\";s:3:\"qty\";s:1:\"1\";s:5:\"price\";s:3:\"800\";s:8:\"subtotal\";s:3:\"800\";s:4:\"name\";s:24:\"Hot product of banglades\";}i:197;a:5:{s:14:\"featured_image\";s:85:\"http://localhost/first_laravel_ecomerce/public/uploads/197/thumb/197.2-1_b77ada4c.jpg\";s:3:\"qty\";s:1:\"2\";s:5:\"price\";s:3:\"555\";s:8:\"subtotal\";s:4:\"1110\";s:4:\"name\";s:15:\"product image 2\";}i:195;a:5:{s:14:\"featured_image\";s:79:\"http://localhost/first_laravel_ecomerce/public/uploads/191/thumb/195.25.5.3.jpg\";s:3:\"qty\";s:1:\"2\";s:5:\"price\";s:2:\"25\";s:8:\"subtotal\";s:2:\"50\";s:4:\"name\";s:20:\"new product of sujon\";}}}', NULL, NULL, '2020-06-12 05:58:08', '2020-06-12', NULL, 'mitul', '01755555114', NULL, 'ddd', NULL, NULL, NULL, NULL),
(300, 'Customer', 0, '2620', 60, 'new', NULL, 'a:1:{s:5:\"items\";a:5:{i:300;a:1:{s:3:\"qty\";s:1:\"2\";}i:239;a:4:{s:14:\"featured_image\";s:86:\"http://localhost/first_laravel_ecomerce/public/uploads/238/thumb/239.Chrysanthemum.jpg\";s:5:\"price\";s:3:\"600\";s:4:\"name\";s:19:\"ehhf product preice\";s:8:\"subtotal\";s:3:\"600\";}i:199;a:4:{s:14:\"featured_image\";s:79:\"http://localhost/first_laravel_ecomerce/public/uploads/199/thumb/199.1205.2.jpg\";s:5:\"price\";s:3:\"800\";s:4:\"name\";s:24:\"Hot product of banglades\";s:8:\"subtotal\";s:3:\"800\";}i:197;a:4:{s:14:\"featured_image\";s:85:\"http://localhost/first_laravel_ecomerce/public/uploads/197/thumb/197.2-1_b77ada4c.jpg\";s:5:\"price\";s:3:\"555\";s:4:\"name\";s:15:\"product image 2\";s:8:\"subtotal\";s:4:\"1110\";}i:195;a:4:{s:14:\"featured_image\";s:79:\"http://localhost/first_laravel_ecomerce/public/uploads/191/thumb/195.25.5.3.jpg\";s:5:\"price\";s:2:\"25\";s:4:\"name\";s:20:\"new product of sujon\";s:8:\"subtotal\";s:2:\"50\";}}}', NULL, '1970-01-01 00:00:00', '2020-06-12 05:59:19', '2020-06-12', '2020-06-29 21:19:06', 'mitul', '01755555114', NULL, 'ddd', NULL, NULL, NULL, NULL),
(301, 'Customer', 0, '2620', 60, 'new', NULL, 'a:1:{s:5:\"items\";a:4:{i:239;a:5:{s:14:\"featured_image\";s:86:\"http://localhost/first_laravel_ecomerce/public/uploads/238/thumb/239.Chrysanthemum.jpg\";s:3:\"qty\";s:1:\"1\";s:5:\"price\";s:3:\"600\";s:8:\"subtotal\";s:3:\"600\";s:4:\"name\";s:19:\"ehhf product preice\";}i:199;a:5:{s:14:\"featured_image\";s:79:\"http://localhost/first_laravel_ecomerce/public/uploads/199/thumb/199.1205.2.jpg\";s:3:\"qty\";s:1:\"1\";s:5:\"price\";s:3:\"800\";s:8:\"subtotal\";s:3:\"800\";s:4:\"name\";s:24:\"Hot product of banglades\";}i:197;a:5:{s:14:\"featured_image\";s:85:\"http://localhost/first_laravel_ecomerce/public/uploads/197/thumb/197.2-1_b77ada4c.jpg\";s:3:\"qty\";s:1:\"2\";s:5:\"price\";s:3:\"555\";s:8:\"subtotal\";s:4:\"1110\";s:4:\"name\";s:15:\"product image 2\";}i:195;a:5:{s:14:\"featured_image\";s:79:\"http://localhost/first_laravel_ecomerce/public/uploads/191/thumb/195.25.5.3.jpg\";s:3:\"qty\";s:1:\"2\";s:5:\"price\";s:2:\"25\";s:8:\"subtotal\";s:2:\"50\";s:4:\"name\";s:20:\"new product of sujon\";}}}', NULL, NULL, '2020-06-12 06:00:02', '2020-06-12', NULL, 'mitul', '01755555114', NULL, 'ddd', NULL, NULL, NULL, NULL),
(302, 'Customer', 0, '18056', 60, 'new', NULL, 'a:1:{s:5:\"items\";a:5:{i:198;a:5:{s:14:\"featured_image\";s:82:\"http://localhost/first_laravel_ecomerce/public/uploads/198/thumb/198.1-273x273.jpg\";s:3:\"qty\";s:1:\"1\";s:5:\"price\";s:3:\"541\";s:8:\"subtotal\";s:3:\"541\";s:4:\"name\";s:17:\"new price product\";}i:239;a:5:{s:14:\"featured_image\";s:86:\"http://localhost/first_laravel_ecomerce/public/uploads/238/thumb/239.Chrysanthemum.jpg\";s:3:\"qty\";s:2:\"10\";s:5:\"price\";s:3:\"600\";s:8:\"subtotal\";s:4:\"6000\";s:4:\"name\";s:19:\"ehhf product preice\";}i:199;a:5:{s:14:\"featured_image\";s:79:\"http://localhost/first_laravel_ecomerce/public/uploads/199/thumb/199.1205.2.jpg\";s:3:\"qty\";s:2:\"10\";s:5:\"price\";s:3:\"800\";s:8:\"subtotal\";s:4:\"8000\";s:4:\"name\";s:24:\"Hot product of banglades\";}i:197;a:5:{s:14:\"featured_image\";s:85:\"http://localhost/first_laravel_ecomerce/public/uploads/197/thumb/197.2-1_b77ada4c.jpg\";s:3:\"qty\";s:1:\"6\";s:5:\"price\";s:3:\"555\";s:8:\"subtotal\";s:4:\"3330\";s:4:\"name\";s:15:\"product image 2\";}i:195;a:5:{s:14:\"featured_image\";s:79:\"http://localhost/first_laravel_ecomerce/public/uploads/191/thumb/195.25.5.3.jpg\";s:3:\"qty\";s:1:\"5\";s:5:\"price\";s:2:\"25\";s:8:\"subtotal\";s:3:\"125\";s:4:\"name\";s:20:\"new product of sujon\";}}}', NULL, NULL, '2020-06-12 11:46:44', '2020-06-12', NULL, 'milon ali', '01735555', NULL, 'dddd', NULL, NULL, NULL, NULL),
(303, 'Customer', 0, '10933', 60, 'new', NULL, 'a:1:{s:5:\"items\";a:6:{i:303;a:1:{s:3:\"qty\";s:1:\"4\";}i:195;a:4:{s:14:\"featured_image\";s:79:\"http://localhost/first_laravel_ecomerce/public/uploads/191/small/195.25.5.3.jpg\";s:5:\"price\";s:2:\"25\";s:4:\"name\";s:20:\"new product of sujon\";s:8:\"subtotal\";s:2:\"75\";}i:197;a:4:{s:14:\"featured_image\";s:85:\"http://localhost/first_laravel_ecomerce/public/uploads/197/small/197.2-1_b77ada4c.jpg\";s:5:\"price\";s:3:\"555\";s:4:\"name\";s:15:\"product image 2\";s:8:\"subtotal\";s:4:\"2775\";}i:198;a:4:{s:14:\"featured_image\";s:82:\"http://localhost/first_laravel_ecomerce/public/uploads/198/small/198.1-273x273.jpg\";s:5:\"price\";s:3:\"541\";s:4:\"name\";s:17:\"new price product\";s:8:\"subtotal\";s:4:\"1623\";}i:199;a:4:{s:14:\"featured_image\";s:79:\"http://localhost/first_laravel_ecomerce/public/uploads/199/small/199.1205.2.jpg\";s:5:\"price\";s:3:\"800\";s:4:\"name\";s:24:\"Hot product of banglades\";s:8:\"subtotal\";s:4:\"4000\";}i:239;a:4:{s:14:\"featured_image\";s:86:\"http://localhost/first_laravel_ecomerce/public/uploads/238/small/239.Chrysanthemum.jpg\";s:5:\"price\";s:3:\"600\";s:4:\"name\";s:19:\"ehhf product preice\";s:8:\"subtotal\";s:4:\"2400\";}}}', NULL, '1970-01-01 00:00:00', '2020-06-12 15:47:30', '2020-06-12', '2020-06-12 18:22:47', 'milon', '0176542144', NULL, 'natore', NULL, NULL, NULL, NULL),
(304, 'Customer', 0, '213', 60, 'new', NULL, 'a:1:{s:5:\"items\";a:4:{i:253;a:4:{s:14:\"featured_image\";s:83:\"http://localhost/first_laravel_ecomerce/public/uploads/253/small/253.Hydrangeas.jpg\";s:5:\"price\";s:1:\"3\";s:4:\"name\";s:24:\"hot product of sujon ali\";s:8:\"subtotal\";s:2:\"15\";}i:254;a:4:{s:14:\"featured_image\";s:74:\"http://localhost/first_laravel_ecomerce/public/uploads/254/thumb/254.1.jpg\";s:5:\"price\";s:2:\"44\";s:4:\"name\";s:158:\"sujon product sujon productsujon productsujon productsujon productsujon productsujon productsujon productsujon produc tsujon productsujon productsujon product\";s:8:\"subtotal\";s:2:\"88\";}i:195;a:4:{s:14:\"featured_image\";s:79:\"http://localhost/first_laravel_ecomerce/public/uploads/191/small/195.25.5.3.jpg\";s:5:\"price\";s:2:\"25\";s:4:\"name\";s:104:\"new product of sujon new product of sujon new product of sujon new product of sujon new product of sujon\";s:8:\"subtotal\";s:2:\"50\";}i:304;a:1:{s:3:\"qty\";s:1:\"2\";}}}', NULL, '1970-01-01 00:00:00', '2020-06-29 16:04:18', '2020-06-29', '2020-06-29 21:26:13', 'sumo ali', '01738305640', NULL, '444', NULL, NULL, NULL, NULL),
(305, 'Customer', 0, '4243', 0, 'new', 'cash_on_delivery', 'a:1:{s:5:\"items\";a:5:{i:239;a:4:{s:14:\"featured_image\";s:86:\"http://localhost/first_laravel_ecomerce/public/uploads/238/small/239.Chrysanthemum.jpg\";s:5:\"price\";s:3:\"600\";s:4:\"name\";s:19:\"ehhf product preice\";s:8:\"subtotal\";s:4:\"3600\";}i:197;a:4:{s:14:\"featured_image\";s:85:\"http://localhost/first_laravel_ecomerce/public/uploads/197/small/197.2-1_b77ada4c.jpg\";s:5:\"price\";s:3:\"555\";s:4:\"name\";s:15:\"product image 2\";s:8:\"subtotal\";s:3:\"555\";}i:254;a:4:{s:14:\"featured_image\";s:74:\"http://localhost/first_laravel_ecomerce/public/uploads/254/small/254.1.jpg\";s:5:\"price\";s:2:\"44\";s:4:\"name\";s:158:\"sujon product sujon productsujon productsujon productsujon productsujon productsujon productsujon productsujon produc tsujon productsujon productsujon product\";s:8:\"subtotal\";s:2:\"44\";}i:240;a:4:{s:14:\"featured_image\";s:202:\"http://localhost/first_laravel_ecomerce/public/uploads/240/small/240.1578586554Silicone Gloves Magic Silicone Dish Washing Glove Household Scrubber Rubber Kitchen Cleaning Tool Kitchen Gloves 1191-3.jpg\";s:5:\"price\";s:2:\"44\";s:4:\"name\";s:13:\"sumon product\";s:8:\"subtotal\";s:2:\"44\";}i:305;a:1:{s:3:\"qty\";s:1:\"1\";}}}', NULL, '1970-01-01 00:00:00', '2020-06-29 19:23:22', '2020-06-29', '2020-06-29 21:30:00', 'sujol ali', '01738305643', NULL, 'ggg', NULL, NULL, NULL, NULL),
(306, 'Customer', 0, '964', 120, 'new', 'cash_on_delivery', 'a:1:{s:5:\"items\";a:2:{i:254;a:5:{s:14:\"featured_image\";s:74:\"http://localhost/first_laravel_ecomerce/public/uploads/254/small/254.1.jpg\";s:3:\"qty\";s:1:\"1\";s:5:\"price\";s:2:\"44\";s:8:\"subtotal\";s:2:\"44\";s:4:\"name\";s:158:\"sujon product sujon productsujon productsujon productsujon productsujon productsujon productsujon productsujon produc tsujon productsujon productsujon product\";}i:199;a:5:{s:14:\"featured_image\";s:79:\"http://localhost/first_laravel_ecomerce/public/uploads/199/small/199.1205.2.jpg\";s:3:\"qty\";s:1:\"1\";s:5:\"price\";s:3:\"800\";s:8:\"subtotal\";s:3:\"800\";s:4:\"name\";s:24:\"Hot product of banglades\";}}}', NULL, NULL, '2020-06-29 20:07:26', '2020-06-29', '2020-06-29 20:07:26', 'suruj ahmed', '01738305640', 's@gghgg.hhh', 'ddd', NULL, NULL, NULL, NULL),
(307, 'Customer', 0, '720', 120, 'new', 'cash_on_delivery', 'a:1:{s:5:\"items\";a:1:{i:239;a:5:{s:14:\"featured_image\";s:86:\"http://localhost/first_laravel_ecomerce/public/uploads/238/small/239.Chrysanthemum.jpg\";s:3:\"qty\";s:1:\"1\";s:5:\"price\";s:3:\"600\";s:8:\"subtotal\";s:3:\"600\";s:4:\"name\";s:19:\"ehhf product preice\";}}}', NULL, NULL, '2020-06-29 08:08:49', '2020-06-29', '2020-06-29 08:08:49', 'sumo ali', '01738305640', 's@gghgg.hhh', 'ffffffff', NULL, NULL, NULL, NULL),
(308, 'Customer', 0, '1170', 60, 'new', 'cash_on_delivery', 'a:1:{s:5:\"items\";a:2:{i:308;a:1:{s:3:\"qty\";s:1:\"2\";}i:197;a:4:{s:14:\"featured_image\";s:85:\"http://localhost/first_laravel_ecomerce/public/uploads/197/small/197.2-1_b77ada4c.jpg\";s:5:\"price\";s:3:\"555\";s:4:\"name\";s:15:\"product image 2\";s:8:\"subtotal\";s:4:\"1110\";}}}', NULL, '1970-01-01 00:00:00', '2020-06-29 08:12:19', '2020-06-29', '2020-06-29 20:13:03', 'sujol ali', '01738305643', NULL, 'dddd', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `page`
--

CREATE TABLE `page` (
  `page_id` int(11) NOT NULL,
  `page_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `page_link` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `page_template` varchar(50) CHARACTER SET utf8 NOT NULL,
  `page_content` text CHARACTER SET utf8 NOT NULL,
  `created_time` datetime NOT NULL,
  `page_order` int(11) NOT NULL,
  `page_position` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `page`
--

INSERT INTO `page` (`page_id`, `page_name`, `page_link`, `page_template`, `page_content`, `created_time`, `page_order`, `page_position`) VALUES
(3, 'Replacement Policy', 'replacement', 'default', '<p>রিপ্লেসমেন্ট পলিসিঃ যে সকল প্রোডাক্টটের মূল্য ২০০০ টাকার বেশি শুধুমাত্র সেগুলোর ক্ষেত্রে কাস্টমার নিম্নের শর্ত সাপেক্ষে প্রোডাক্টটির রিপ্লেসমেন্ট সুবিধা পাবে।<br />\r\n১) প্রোডাক্টের সমস্যার (যেমন : প্রোডাক্ট ভাঙ্গা, ছেঁড়া, ভুল সাইজ, প্রোডাক্ট কাজ না করা, ছবির সাথে প্রোডাক্টের মিল না থাকা ইত্যাদি) ক্ষেত্রে আপনি রিপ্লেসমেন্ট পেতে পারেন।<br />\r\n২) প্রোডাক্টটির বাক্স সহ সম্পূর্ণ অক্ষত অবস্থায় থাকতে হবে।<br />\r\n৩) ডেলিভারি গ্রহনের পর সর্বোচ্চ ৪৮ ঘন্টার মধ্যে আপনাকে info@ekushyshop.com এ মেইল করতে হবে অথবা 01796-000007 নাম্বারে কমপ্লেইন রেজিস্টার করতে হবে।<br />\r\n৪) আপনাকে উক্ত প্রোডাক্টটি কালেরহাট-এর অফিসে অবশ্যই সর্বোচ্চ ৭ কার্যদিবসের মধ্যে নিজ দায়িত্বে ফেরত পাঠাতে হবে। বিঃ দ্রঃ পণ্য ও সার্ভিস সম্পর্কিত কোনো অভিযোগের জন্য আমাদের কমপ্লেইন্ট টীম আপনাকে ফোন করবেন। এ জন্য আপনার অভিযোগটি সমাধান না হওয়া পর্যন্ত আপনাকে আমরা ফোনে সক্রিয় পেতে চাই। আপনার যোগাযোগে দেওয়া নম্বরটি সক্রিয় না থাকলে বিকল্প কোনো নম্বর সক্রিয় থাকতে হবে। রিফান্ডের জন্য আপনাকে টাকাটি ফেরতের মাধ্যম আমাদের জানাতে হবে। আমরা আপনার কোনো প্রকার সহযোগিতা ১৫ কার্যদিবসের মধ্যে ফোনে অথবা ইমেইলে না পেলে আপনার অভিযোগটি নিস্পত্তি বলে মনে করবো।</p>\r\n', '2019-10-07 10:18:01', 0, ''),
(4, 'About Us ', 'about', 'default', '<h1><strong>About Ekusheyshop</strong></h1>\r\n\r\n<hr />\r\n<p>ekusheyshop.com is the ultimate online shopping destination in Bangladesh, offering completely hassle-free shopping experience through secure and trusted payment gateways and quickest delivery service. We are offering you trendy and reliable shopping with all your favorite brands and more. Now shopping is much more easier, faster and joyous. We are here to help you make the right choice. Ekusheyshop.com is a concern of Ekushey Technology.</p>\r\n\r\n<p>Ekusheyshop showcases only Original products from all categories such as clothing, footwear, jewellery, accessories, electronics, home appliance, gadgets, health &amp; beauty and still counting!&nbsp; Our products are exclusively selected for you. Ekusheyshop have all the stuffs that you need under one umbrella at incredible prices.</p>\r\n\r\n<p>In tune with the vision <strong>&ldquo;Digital Bangladesh&rdquo;</strong>, ekusheyshop.com opens the doorway for everybody to shop over the Internet sitting at home. We are constantly updating our product lines, services and special offers that fits with your requirement. We provide on-time delivery across the nation and quick resolution of any concerns. Customer support and satisfaction is our main strength. We are working hard every moment to make your online shopping secure &amp; enjoyable.&nbsp;</p>\r\n', '2019-11-13 11:56:27', 0, 'home'),
(5, 'TERMS & CONDITIONS', 'terms', 'default', '<p>কীভাবে মূল্য ফেরত নেবেন অনলাইন পেমেণ্ট এর ক্ষেত্রে অতিরিক্ত মূল্য পরিশোধিত হলে ২৪ ঘণ্টার মধ্যে জানাতে হবে । এক্ষেত্রে info@okshop এ মেইল করে জানানোর জন্য অনুরোধ করা হচ্ছে । ১. নষ্ট বা ক্ষতিগ্রস্ত পণ্যের ক্ষেত্রে পণ্য গ্রহন না করে পন্যবাহকের কাছে পণ্য ফেরত দেবার জন্য বলা হচ্ছে এবং আমাদেরকে টেলিফোন/ ইমেইল করে অবহিত করার জন্য অনুরোধ করা হচ্ছে। ২. নষ্ট পণ্য সাথে সাথে বাহকের কাছে ফেরত দিতে সমর্থ না হলে পরবর্তীতে ফেরত দেবার ক্ষেত্রে যাবতীয় পরিবহন খরচ ক্রেতাকে বহন করতে হবে। ৩. ব্যবহার করা পণ্যের ক্ষেত্রে কোনভাবেই মূল্য ফেরত দেওয়া হবে না। ৪. ট্রাভেল ডিল এর ক্ষেত্রে যাত্রা বাতিল করে মূল্য ফেরত নেবার জন্য নির্দিষ্ট সময়ের মধ্যে আমাদেরকে অবহিত করার জন্য অনুরোধ করা হচ্ছে । ৫. পরিশোধকৃত মূল্য ফেরত নেবার ক্ষেত্রে অবশ্যই ক্রেতাকে আমাদের অফিসে এসে মূল্য ফেরত নিতে হবে (অনলাইন পেমেন্ট এর ক্ষেএে প্রযোজ্য নয়)। ৬. মূল্য ফেরত পাবার জন্য অবহিত করার পর ৭ থেকে ২১ দিন পর্যন্ত অপেক্ষা করতে হতে পারে। ৭. অনলাইন পেমেন্ট ফেরত নেবার ক্ষেত্রে ক্রেতার ব্যাংক স্টেটমেন্ট দিতে হতে পারে। .</p>\r\n', '2019-10-06 07:30:58', 0, 'footer'),
(6, 'Track Your Order ', 'page_track', 'page_track', '<ul style=\"list-style-type:circle\">\r\n	<li>1.আপনার অর্ডারের আপডেট জানতে নিচের বক্সে অর্ডার নাম্বার অথবা আপনার মোবাইল নাম্বার দিয়ে Track order বাটনে চাপুন।</li>\r\n	<li>2.To get latest update about your order please enter your order number or mobile number and click on the Track order button</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n', '2019-12-01 12:10:59', 0, ''),
(7, 'Contact Us', 'contact', 'contact', '<h3>Call Us</h3>\r\n\r\n<p><br />\r\n<strong>info@ekusheshop.com<br />\r\nSupport: 017000000000<br />\r\nSales:0190000000000</strong><br />\r\n<strong>Hotline:01796-000000</strong></p>\r\n', '2019-11-10 03:39:39', 0, ''),
(8, 'Return Policy', 'return_policy', 'full_width', '**If your product arrives damaged or faulty, please do not accept it. If you did accept it, please get in contact with our customer service team on 16492**\r\n\r\n\r\nCan I return this product?\r\n\r\nYou can return this product for a replacement or a refund, within 7 days after receiving your original order.\r\n\r\nOnly Custom or Made-to-order products; Imported On-order products and delivered out of Bangladesh products cannot be returned.\r\n\r\n\r\nWhat are the required conditions?\r\n\r\nCondition A:\r\n\r\n    If the product is not as you expected/not as advertised; or\r\n    If you don\'t want the product anymore\r\n\r\nThe product must be returned unused, in original packaging and with all seals & tags intact.\r\n\r\nCondition B:\r\n\r\n    If the product is damaged, defective or counterfeit; or\r\n    If your fashion product is the wrong size\r\n\r\nThe product must be returned in its original packaging. All accessories, tags and free gifts must also be returned.\r\n\r\n\r\nHow to return this product?\r\n\r\nTo return a product, simply follow the steps below:\r\n\r\nYou can also request a return by calling Customer Service at 16492\r\n\r\n\r\nStep 1: Start the Easy & Fast Return\r\n\r\n    Go to Returns or call us at 16492\r\n    Select your order and click \"Return a product\"\r\n    Choose your preferred return and replacement/refund method\r\n\r\n\r\nStep 2: Pack your product\r\n\r\n    Pack your product according to the return conditions\r\n    Include all tags, accessories or free gifts you received\r\n    Fill and include the \"Easy & Fast Return\" form included in your package\r\n\r\n\r\nStep 3: Return your product\r\n\r\n    If you requested a pickup, we will contact you to arrange a pickup time\r\n    For further information please visit Help\r\n\r\n\r\n\r\nWhat\'s next?\r\n\r\nWe will send you a tracking number via SMS after the package has been picked up or dropped off. We will immediately initiate your replacement or refund when we have received your package and it has passed our Quality Evaluation. For expected timelines please visit Help\r\n\r\n', '2019-09-01 07:07:54', 0, ''),
(9, 'How to buy', 'buy', 'full_width', '<p>ddd</p>\r\n', '2019-11-10 03:33:59', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_price` double DEFAULT NULL,
  `purchase_price` double DEFAULT NULL,
  `discount_price` varchar(100) DEFAULT NULL,
  `product_summary` longtext,
  `product_description` longtext,
  `product_specification` longtext,
  `product_terms` text,
  `sku` varchar(255) DEFAULT NULL,
  `product_stock` int(11) DEFAULT NULL,
  `product_of_size` varchar(250) DEFAULT NULL,
  `product_color` varchar(255) DEFAULT NULL,
  `product_video` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1 active 0 in active',
  `product_type` varchar(15) DEFAULT 'general',
  `created_time` datetime NOT NULL,
  `modified_time` datetime NOT NULL,
  `folder` int(11) NOT NULL,
  `feasured_image` varchar(250) DEFAULT NULL,
  `galary_image_6` varchar(250) DEFAULT NULL,
  `galary_image_1` varchar(250) DEFAULT NULL,
  `galary_image_2` varchar(250) DEFAULT NULL,
  `galary_image_3` varchar(250) DEFAULT NULL,
  `galary_image_4` varchar(250) DEFAULT NULL,
  `galary_image_5` varchar(250) DEFAULT NULL,
  `seo_title` mediumtext,
  `seo_keywords` mediumtext,
  `seo_content` mediumtext,
  `stock_alert` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_title`, `product_name`, `product_price`, `purchase_price`, `discount_price`, `product_summary`, `product_description`, `product_specification`, `product_terms`, `sku`, `product_stock`, `product_of_size`, `product_color`, `product_video`, `status`, `product_type`, `created_time`, `modified_time`, `folder`, `feasured_image`, `galary_image_6`, `galary_image_1`, `galary_image_2`, `galary_image_3`, `galary_image_4`, `galary_image_5`, `seo_title`, `seo_keywords`, `seo_content`, `stock_alert`) VALUES
(1, 'WiFi IP Security Camera -wireless CCTV Camera for home and office security', 'wifi-ip-security-camera--wireless-cctv-camera-for-home-and-office-security', 2990, 0, '1990', ' ', '<h2><strong>WiFi IP Security Camera (বাসা/অফিস এর নিরাপত্তার জন্য সিকিউরিটি ক্যামেরা)</strong></h2>\r\n\r\n<p>✔ ক্যামেরা রেজুলেশন : 1 Mega Pixel (HD)</p>\r\n\r\n<p>✔ অটো নাইট ভিসন, রাতে/অন্ধকারে ক্লিয়ার ভিডিও দেখা যাবে</p>\r\n\r\n<p>✔ মেমোরি কার্ডে ভিডিও রেকর্ডিং সুবিধা</p>\r\n\r\n<p>✔ দুই প্রান্ত থেকে কথা বলা ও শোনা যাবে (Same Like Mobile)</p>\r\n\r\n<p>✔Mobile / Computer বা TAB যে কোন ডিভাইস থেকে চালানো যাবে</p>\r\n\r\n<p>✔ দীর্ঘ দূরত্ব নজরদারির জন্য শক্তিশালী Zooming লেন্স</p>\r\n\r\n<p>✔ পৃথিবীর সব জায়গা থেকে সরাসরি মনিটরিং করতে পারবেন</p>\r\n\r\n<p>✔ ওয়াল, ছাঁদ বা টেবিল যে কোন জায়গায় সেট করা যাবে</p>\r\n\r\n<p>✔ Still Picture তোলা যায়</p>\r\n\r\n<p>✔ HD কোয়ালিটি ভিডিও আউটপুট</p>\r\n\r\n<p>✔ স্মার্ট এলার্মিং সিস্টেম</p>\r\n\r\n<p>✔ Power Supply : 5 volt</p>\r\n\r\n<p>✔ Six Month Service warranty</p>\r\n\r\n<p>✔ Software : V380 / 360Eye</p>\r\n', NULL, '', '1001', 0, NULL, '', '', 1, 'home', '2020-01-07 10:34:37', '2020-01-07 10:34:37', 0, '', '', '', '', '', '', '', '', '', '', 0),
(2, 'Single Antenna WiFi IP Security Camera- wireless CCTV Camera for home and office security', 'single-antenna-wifi-ip-security-camera--wireless-cctv-camera-for-home-and-office-security', 3990, 0, '2990', ' ', '<h2><strong>Single Antenna WiFi IP Security Camera</strong></h2>\r\n\r\n<p>✔ ক্যামেরা রেজুলেশন : 1 Mega Pixel (HD)</p>\r\n\r\n<p>✔ অটো নাইট ভিসন, রাতে/অন্ধকারে ক্লিয়ার ভিডিও দেখা যাবে ।</p>\r\n\r\n<p>✔ মেমোরি কার্ডে ভিডিও রেকর্ডিং সিস্টেম।</p>\r\n\r\n<p>✔ দুই প্রান্ত থেকে কথা বলা ও শোনা যাবে। (Same Like Mobile)</p>\r\n\r\n<p>✔Mobile / Computer বা TAB যে কোন ডিভাইস থেকে চালানো যাবে।</p>\r\n\r\n<p>✔ দীর্ঘ দূরত্ব নজরদারির জন্য শক্তিশালী Zooming লেন্স।</p>\r\n\r\n<p>✔ পৃথিবীর সব জায়গা থেকে সরাসরি মনিটরিং করতে পারবেন।</p>\r\n\r\n<p>✔ ওয়াল, ছাঁদ বা টেবিল যে কোন জায়গায় সেট করা যাবে।</p>\r\n\r\n<p>✔ Still Picture তোলা যায়।</p>\r\n\r\n<p>✔ HD কোয়ালিটি ভিডিও আউটপুট।</p>\r\n\r\n<p>✔ স্মার্ট এলার্মিং সিস্টেম।</p>\r\n\r\n<p>✔ Power Supply : 5 volt</p>\r\n\r\n<p>✔ One Month Service warranty</p>\r\n\r\n<p>✔ Software : CamHi</p>\r\n', NULL, '<p>\r\n\r\nআমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন, জননী, সুন্দরবন ও করোতোয়া কুরিয়ারের মাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার মধ্যে হোম ডেলিভারি চার্জ ৬০টাকা, যা পন্য বুঝে নেয়ার সময় পরিশোধ করতে হবে।\r\n\r\n<br></p><p>✔&nbsp;ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১০০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ মূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে।\r\n\r\n\r\n\r\n<br></p>', '1002', 0, NULL, '', '', 1, 'home', '2020-01-07 10:55:53', '2020-01-07 10:55:53', 0, '', '', '', '', '', '', '', '', '', '', 0),
(3, 'Double Antenna WiFi IP Security Camera- wireless CCTV Camera for home and office security', 'double-antenna-wifi-ip-security-camera--wireless-cctv-camera-for-home-and-office-security', 3990, 0, '2990', ' ', '<h2>Double Antenna WiFi IP Security Camera</h2>\r\n\r\n<p>✔ ক্যামেরা রেজুলেশন : 1 Mega Pixel (HD)</p>\r\n\r\n<p>✔ অটো নাইট ভিসন, রাতে/অন্ধকারে ক্লিয়ার ভিডিও দেখা যাবে ।</p>\r\n\r\n<p>✔ মেমোরি কার্ডে ভিডিও রেকর্ডিং সিস্টেম।</p>\r\n\r\n<p>✔ দুই প্রান্ত থেকে কথা বলা ও শোনা যাবে। (Same Like Mobile)</p>\r\n\r\n<p>✔Mobile / Computer বা TAB যে কোন ডিভাইস থেকে চালানো যাবে।</p>\r\n\r\n<p>✔ দীর্ঘ দূরত্ব নজরদারির জন্য শক্তিশালী Zooming লেন্স।</p>\r\n\r\n<p>✔ পৃথিবীর সব জায়গা থেকে সরাসরি মনিটরিং করতে পারবেন।</p>\r\n\r\n<p>✔ ওয়াল, ছাঁদ বা টেবিল যে কোন জায়গায় সেট করা যাবে।</p>\r\n\r\n<p>✔ Still Picture তোলা যায়।</p>\r\n\r\n<p>✔ HD কোয়ালিটি ভিডিও আউটপুট।</p>\r\n\r\n<p>✔ স্মার্ট এলার্মিং সিস্টেম।</p>\r\n\r\n<p>✔ Power Supply : 5 volt</p>\r\n\r\n<p>✔ One Month Service warranty</p>\r\n\r\n<p>✔ Software : CamHi</p>\r\n', NULL, '', '1003', 0, NULL, '', '', 1, 'hotsell', '2020-01-07 11:00:56', '2020-01-07 11:00:56', 0, '', '', '', '', '', '', '', '', '', '', 0),
(4, 'Aluminium alloy hand operate keema machine manual meat grinder sausage beef meet mincer machine with tabletop clamp kitchen home tool', 'aluminium-alloy-hand-operate-keema-machine-manual-meat-grinder-sausage-beef-meet-mincer-machine-with-tabletop-clamp-kitchen-home-tool', 1490, 0, '1250', ' ', '<h2>অ্যালুমিনিয়াম মিট গ্রাইন্ডার</h2>\r\n\r\n<p>✔ ম্যাটেরিয়াল: স্টেইনলেস স্টিল</p>\r\n\r\n<p>✔ মাংসের সসেজ, প্যাটিস বা জার্কি বানানোর জন্য আদর্শ</p>\r\n\r\n<p>✔ এখন আপনি ঘরে বসেই করতে পারেন মাংসের কিমা</p>\r\n\r\n<p>✔ সময়, শ্রম, তেল, ও জ্বালানী সাশ্রয়ী</p>\r\n\r\n<p>✔ কর্মজীবী মানুষের জন্য খুবই প্রয়োজনীয় একটি গ্যাজেট</p>\r\n\r\n<p>✔ হাই কোয়ালিটি ও ব্র্যান্ড নিউ প্রোডাক্ট</p>\r\n', NULL, '', '1005', 0, NULL, '', '', 1, 'home', '2020-01-07 11:17:37', '2020-01-07 11:17:37', 0, '', '', '', '', '', '', '', '', '', '', 0),
(5, 'Clever Cutter 2 in 1 Stainless Steel Knife with Cutting Board, Smart vegetable Cutter, kitchen scissors for Quick and Easy Cutting, Food Scissors, Vegetable Slicer', 'clever-cutter-2-in-1-stainless-steel-knife-with-cutting-board-smart-vegetable-cutter-kitchen-scissors-for-quick-and-easy-cutting-food-scissors-vegetable-slicer', 790, 0, '390', ' ', '<h2><strong>Clever Cutter (সবজি কাটার কাচি)</strong></h2>\r\n\r\n<p>✔ 2 in 1 Clever Cutter.</p>\r\n\r\n<p>✔ Material: ABS.</p>\r\n\r\n<p>✔ Stainless steel blade.</p>\r\n\r\n<p>✔ Total length-24.7cm-9.7&quot;.</p>\r\n\r\n<p>✔ Blade length-10.5cm-4.1&quot;.</p>\r\n\r\n<p>✔ Easy to use.</p>\r\n\r\n<p>✔ Dish washer safe.</p>\r\n', NULL, '<p></p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ৬০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n<p>✔ ঢাকার\r\nসিটির বাহিরে ডেলিভারী চার্জ ১০০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ মূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। </p>\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1006', 0, NULL, '', 'https://www.youtube.com/watch?v=zK5A8sZ8OBE', 1, 'hotsell', '2020-01-08 08:36:33', '2020-01-08 08:36:33', 0, '', '', '', '', '', '', '', '', '', '', 0),
(6, 'Automatic Doi Maker - Electric Yogurt Maker, Kitchen Appliances, Stainless Steel Yogurt Maker', 'automatic-doi-maker---electric-yogurt-maker-kitchen-appliances-stainless-steel-yogurt-maker', 1590, 0, '1150', ' ', '<h2><strong>Automatic Doi Maker (বাড়িতে দই বানানো মেশিন)</strong></h2>\r\n\r\n<p>✔ ঘরে বসে সহজেই দই তৈরী করুন</p>\r\n\r\n<p>✔ হাতের কোন স্পর্শ ও পরিশ্রম ছাড়াই তৈরি হবে দই</p>\r\n\r\n<p>✔ On/Off সুইচ</p>\r\n\r\n<p>✔ লাইট ইনডিকেটর</p>\r\n\r\n<p>✔ ব্র্যান্ড নিউ</p>\r\n\r\n<p>✔ হাই কোয়ালিটি</p>\r\n', NULL, '<p></p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ৬০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n<p>✔ ঢাকার\r\nসিটির বাহিরে ডেলিভারী চার্জ ১০০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ মূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। </p>\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1007', 0, NULL, '', '', 1, 'home', '2020-01-08 08:42:02', '2020-01-08 08:42:02', 0, '', '', '', '', '', '', '', '', '', '', 0),
(7, 'Water Spray Mop With Reusable Microfiber Pads 360 Degree Metal Handle Mop For Home Kitchen Laminate Wood Ceramic Tiles Floor Cleaning, Quick floor Cleaner with Refillable Water Bottle', 'water-spray-mop-with-reusable-microfiber-pads-360-degree-metal-handle-mop-for-home-kitchen-laminate-wood-ceramic-tiles-floor-cleaning-quick-floor-cleaner-with-refillable-water-bottle', 1590, 0, '1250', ' ', '<h3><strong>বসে বসে কাপড় দিয়ে ঘর মোছার ঝামেলা এড়াতে এসে গেল অত্যাধুনিক একটি মব যা আপনাকে সাহায্য করবে সহজেই ঘর পরিষ্কার করতে। কোমর ব্যাথা থেকে হতে পারবেন পুরোপুরি মুক্ত।</strong></h3>\r\n\r\n<p>✔ হেলদি স্প্রে মপ</p>\r\n\r\n<p>✔ ম্যাটেরিয়াল: প্লাস্টিক ক্যাপাসিটি স্ট্যান্ডার্ড</p>\r\n\r\n<p>✔ কালার: র&zwj;্যান্ডম</p>\r\n\r\n<p>✔ আইটেম ওজন : 739 গ্রাম</p>\r\n\r\n<p>✔ মাত্রা : 64 x 14.4 x 10 সেমি</p>\r\n', NULL, '', '1008', 0, NULL, '', 'https://www.youtube.com/watch?v=4mnbohKqcn8', 1, 'home', '2020-01-08 08:45:47', '2020-01-08 08:45:47', 0, '', '', '', '', '', '', '', '', '', '', 0),
(8, 'Stainless Steel Kitchen Bathroom Shelf Wall-mounted Storage Rack Single Layer', 'stainless-steel-kitchen-bathroom-shelf-wall-mounted-storage-rack-single-layer', 990, 0, '750', ' ', '<p>✔ স্টেইনলেস স্টিল দ্বারা তৈরী, মরিচা পড়ার কোন চান্স নাই ।</p>\r\n\r\n<p>✔ বাথরুম, রান্নাঘর এর কোনায় সহজেই লাগাতে পারবেন ।</p>\r\n\r\n<p>✔ ওজনে হালকা ।</p>\r\n\r\n<p>✔ সর্বোচ্চ ৫ কেজি পর্যন্ত ওজন বহন করতে পারবে ।</p>\r\n', NULL, '<p></p><p></p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ৬০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n<p>✔ ঢাকার\r\nসিটির বাহিরে ডেলিভারী চার্জ ১০০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ মূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। </p>\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1009-1', 0, NULL, '', '', 1, 'general', '2020-01-08 08:54:26', '2020-01-08 08:54:26', 0, '', '', '', '', '', '', '', '', '', '', 0),
(9, 'Stainless Steel Kitchen Bathroom Shelf Wall-mounted Storage Rack Single Layer Corner Tray', 'stainless-steel-kitchen-bathroom-shelf-wall-mounted-storage-rack-single-layer-corner-tray', 990, 0, '750', ' ', '<p>✔ স্টেইনলেস স্টিল দ্বারা তৈরী, মরিচা পড়ার কোন চান্স নাই ।</p>\r\n\r\n<p>✔ বাথরুম, রান্নাঘর এর কোনায় সহজেই লাগাতে পারবেন ।</p>\r\n\r\n<p>✔ ওজনে হালকা ।</p>\r\n\r\n<p>✔ সর্বোচ্চ ৫ কেজি পর্যন্ত ওজন বহন করতে পারবে ।</p>\r\n', NULL, '<p></p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ৬০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n<p>✔ ঢাকার\r\nসিটির বাহিরে ডেলিভারী চার্জ ১০০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ মূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। </p>\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1009-2', 0, NULL, '', '', 1, 'general', '2020-01-08 08:57:06', '2020-01-08 08:57:06', 0, '', '', '', '', '', '', '', '', '', '', 0),
(12, 'Epilator, Finishing Touch Hair Remover Instant With Sensor Light, Women\'s Pain Free Hair Removal', 'epilator-finishing-touch-hair-remover-instant-with-sensor-light-womens-pain-free-hair-removal', 900, 0, '', '  ', '<h2>Finishing Touch Hair Remover</h2>\r\n\r\n<p>Safe and gentle on the most sensitive skin.</p>\r\n\r\n<p>No more painful or smelly hair removal methods.No more nicks, cuts, bumps or burns.</p>\r\n\r\n<p>The remover will activate and remove hair as long as the head is against your skin.</p>\r\n\r\n<p>Come with a Microfoil head for short hair, hair stubble or touch-ups.</p>\r\n\r\n<p>Use anywhere there&#39;s unwanted hair - safe on all skin types and colors.</p>\r\n\r\n<h3>Specification:</h3>\r\n\r\n<p>Type: Finishing Touch Hair Remover</p>\r\n\r\n<p>Material: Plastic</p>\r\n\r\n<p>Quantity: 1pcs</p>\r\n\r\n<p>Item Color: As shown</p>\r\n\r\n<p>Shaver Type: Rotary</p>\r\n\r\n<p>Use for Bikini Line, Face, Under Arm, Legs, Upper Lip</p>\r\n\r\n<p>Battery: Built-in rechargeable battery</p>\r\n\r\n<p>Size: 12*4.8*1.7cm / 4.7*1.9*0.6&quot;&quot;</p>\r\n\r\n<p>Weight: 175g</p>\r\n\r\n<h3>Product contains:</h3>\r\n\r\n<p>✔&nbsp;Hair Remover-1</p>\r\n\r\n<p>✔ Microfoil head-1</p>\r\n\r\n<p>✔&nbsp;Brush-1</p>\r\n\r\n<p>✔&nbsp;USB charging cable-1</p>\r\n\r\n<p>✔&nbsp;Power adapter-1</p>\r\n', NULL, '<p></p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ৬০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔&nbsp;ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১০০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ মূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n<br><p></p>', '1010', 0, NULL, '', '', 1, 'home', '2020-01-08 11:41:53', '2020-01-08 11:41:53', 0, '', '', '', '', '', '', '', '', '', '', 0),
(13, 'GSM 3G WiFi Modem For Any Device, Portable Mini Wi-fi Mobile Device 3G Wireless Dongle with TF SIM Card Slot', 'gsm-3g-wifi-modem-for-any-device-portable-mini-wi-fi-mobile-device-3g-wireless-dongle-with-tf-sim-card-slot', 1690, 0, '1550', ' ', '<p>✔ মডেমের মধ্যে 3G সিমকার্ড স্থাপন করে WiFi Networtk তৈরী করে আপনার কম্পিউটার ,ল্যাপটপ বা মোবাইলকে ইন্টারনেটের সাথে যুক্ত করতে পারেন।</p>\r\n\r\n<p>✔ USB Cable এর মাধ্যমে ইলেক্ট্রিক পাওয়ার দিয়ে উপভোগ করুন Wi-Fi Zone.</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ৬০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১০০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1011', 0, NULL, '', '', 1, 'home', '2020-01-08 01:00:57', '2020-01-08 01:00:57', 0, '', '', '', '', '', '', '', '', '', '', 0),
(14, 'Multifunction baby carrier 3-18 months for baby, baby sling breathable fabric baby backpack wrapping kangaroo front face Adjustable baby Carrier', 'multifunction-baby-carrier-3-18-months-for-baby-baby-sling-breathable-fabric-baby-backpack-wrapping-kangaroo-front-face-adjustable-baby-carrier', 990, 0, '850', '  ', '<h2><strong>বেবি ক্যারিয়ার</strong></h2>\r\n\r\n<p>✔ ৪ টি পজিশনে এই ক্যারিয়ারকে ব্যবহার করা যাবে</p>\r\n\r\n<p>✔ ৩.৫ থেকে ১২ কেজি ওজনের বাচ্চাদের ক্ষেত্রে প্রযোজ্য</p>\r\n\r\n<p>✔ হেড সাপোর্ট বাচ্চার মাথকে দুর্ঘটনা থেকে রক্ষা করবে</p>\r\n\r\n<p>✔ সহজেই পরিষ্কার করা যায়</p>\r\n\r\n<p>✔ কালার: Random</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ৬০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১০০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1012', 0, NULL, '', '', 1, 'home', '2020-01-09 09:07:37', '2020-01-09 09:07:37', 0, '', '', '', '', '', '', '', '', '', '', 0),
(15, 'Electric Digital Therapy Machine Massager Pulse Acupuncture Stiumlator Body Slimming Eletrode Treatment Device Relax Muscle Pain Relief Therapy ', 'electric-digital-therapy-machine-massager-pulse-acupuncture-stiumlator-body-slimming-eletrode-treatment-device-relax-muscle-pain-relief-therapy-', 790, 0, '750', ' ', '<h2><strong>ডিজিটাল থেরাপি মেশিন ( Therapy Machine)</strong></h2>\r\n\r\n<p>✔যে কোন ব্যাথায় ইনস্ট্যান্ট আরাম ,ঘাড়, পা, মেরুদন্ড, পিঠ, কোমর ব্যথা থেকে শুরু করে যে কোন ব্যথায় আরাম দিবে এই ডিজিটাল থেরাপি মেশিন,</p>\r\n\r\n<p>✔ ব্যাটারিতে চালানো সহ সরাসরি কারেন্ট কিংবা পিসির ইউএসবিতে চালানোর সুবিধা,</p>\r\n\r\n<p>✔ সমস্যা অনুযায়ী আছে ৮ ধরনের থেরাপি মুড</p>\r\n\r\n<p>✔ টাইমসেট করাসহ অনেক সুবিধা,</p>\r\n\r\n<p>✔ পরিবারের সবার জন্য ব্যবহার উপযোগী।</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ৬০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১০০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1022', 0, NULL, '', '', 1, 'hotsell', '2020-01-08 01:24:32', '2020-01-08 01:24:32', 0, '', '', '', '', '', '', '', '', '', '', 0),
(16, 'VIBRO shape high performance slimming belt, Vibration massage slimming belt, massager to loose weight waist belt power plate massageador for slimming', 'vibro-shape-high-performance-slimming-belt-vibration-massage-slimming-belt-massager-to-loose-weight-waist-belt-power-plate-massageador-for-slimming', 2090, 0, '1950', ' ', '<p>✔ এটা আপনার মেদ কমিয়ে শরীরে নিয়ে আসবে সুন্দর একটা সেপ</p>\r\n\r\n<p>✔ শরীর মাসাজ করতে পারবেন অনায়াসে</p>\r\n\r\n<p>✔ আপনার বাসা কিংবা অফিসে বসে প্রতিদিন মাত্র ১০ থেকে ১৫ মিনিট সময় কাটান, আর Vibro Shape থেকে নিন স্লিম ফিগার!</p>\r\n\r\n<p>✔ সহজে ব্যবহারযোগ্য স্লিমিং প্রোডাক্ট</p>\r\n\r\n<p>✔ এনার্জি সোর্স: পাওয়ার অ্যাডাপ্টার</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1023', 0, NULL, '', '', 1, 'home', '2020-01-08 01:29:26', '2020-01-08 01:29:26', 0, '', '', '', '', '', '', '', '', '', '', 0),
(17, 'Digital Quran learning Pen Reader, Quran Pen', 'digital-quran-learning-pen-reader-quran-pen', 3990, 0, '3500', ' ', '<h2><strong>ডিজিটাল কোরআন লার্নিং পেন</strong></h2>\r\n\r\n<p>✔ এটি একটি ডিজিটাল আল-কোরআন</p>\r\n\r\n<p>✔ সাথে দেয়া কলম দিয়ে কুরআনের যে কোন অক্ষরে, আয়াতে, পৃষ্ঠাও সুরার উপর স্পর্শ করা মাত্রই আরবীতে তেলাওয়াত করবে,ইংরেজী, বাংলা, উর্দু, ফার্সি সহ মোট টি ভাষায় তরজমা করবে।</p>\r\n\r\n<p>সাথে যা আছেঃ</p>\r\n\r\n<p>✔ একটি কুরআন লার্নিংপেন</p>\r\n\r\n<p>✔ একটি কুরআন শরিফ; নামায এবং প্রয়োজনীয় দোয়া শিক্ষার বই</p>\r\n\r\n<p>✔ একটি ডাটা ক্যাবল</p>\r\n\r\n<p>✔ একটি টাচ কার্ড; একটি চার্জার</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1027', 0, NULL, '', '', 1, 'home', '2020-01-08 01:32:57', '2020-01-08 01:32:57', 0, '', '', '', '', '', '', '', '', '', '', 0),
(18, 'Car and Home Relaxation Massage Pillow Vibrator Electric Shoulder Back Heating Kneading Massage Pillow with Heat for Shoulders, Massage Tool Relieve Stress Pillow', 'car-and-home-relaxation-massage-pillow-vibrator-electric-shoulder-back-heating-kneading-massage-pillow-with-heat-for-shoulders-massage-tool-relieve-stress-pillow', 1590, 0, '1500', ' ', '<h2>ইলেকট্রিক সেভার (8 in 1 Rechargeable Trimmer)</h2>\r\n\r\n<p>✔এর সাহায্যে শরীরের অবাঞ্ছিত লোম দূর করুন সহজেই, আরামদায়ক হেয়ার রিমুভার সহজে ব্যবহার করা যায়</p>\r\n\r\n<p>✔ শব্দহীন ও পারফেক্ট কাটিংসহজ ক্লিনিংয়ের জন্য</p>\r\n\r\n<p>✔ রিমুভেবল ব্লেড, ব্যবহার সহজ ও নিরাপদ অ্যাডভান্সড শেভিং সিস্টেম</p>\r\n\r\n<p>✔ প্যাকেজে রয়েছে : শেভার, অ্যাডাপ্টার, হেয়ার ট্রিমার হেড, নোজ ট্রিমার হেড, শেভার হেড, কম্ব, ব্রাশ ও ইউজার ম্যানুয়াল ।</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ৬০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১০০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1030', 0, NULL, '', '', 1, 'home', '2020-01-08 02:27:25', '2020-01-08 02:27:25', 0, '', '', '', '', '', '', '', '', '', '', 0),
(19, 'Paint Zoom Professional Electric Paint Sprayer Gun Adjustable Flow Control For Cars Furniture Woodworking painting machine tool', 'paint-zoom-professional-electric-paint-sprayer-gun-adjustable-flow-control-for-cars-furniture-woodworking-painting-machine-tool', 3990, 0, '3000', '  ', '<h2><strong>পোর্টেবল ইলেকট্রিক পেইন্ট মেশিন</strong></h2>\r\n\r\n<p>✔ এটি দিয়ে আপনি সব জায়গায় রং করতে পারবেন</p>\r\n\r\n<p>✔ ৩টি অ্যাডজাস্টেবল সিস্টেম, গ্লস পেইন্ট সিস্টেম</p>\r\n\r\n<p>✔ ডাইমেনশন:24 x 19 x 12 cm</p>\r\n\r\n<p>✔ টিউব লেন্থ: 1.6 m</p>\r\n\r\n<p>✔ কন্টেইনার ক্যাপাসিটি: 800 ml</p>\r\n\r\n<p>✔ মোটরপাওয়ার: 650W</p>\r\n', NULL, '<p>\r\n</p><p></p>\r\n<p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1033', 0, NULL, '', 'Bry7Srkoq1w', 1, 'home', '2020-01-08 06:23:59', '2020-01-08 06:23:59', 0, '', '', '', '', '', '', '', '', '', '', 0),
(20, 'Fast Hair Straightener Hair Brush Comb hair Electric brush comb Irons Auto Straight Hair Comb brush', 'fast-hair-straightener-hair-brush-comb-hair-electric-brush-comb-irons-auto-straight-hair-comb-brush', 890, 0, '790', ' ', '<p>Electric Hair Straightener Brush (চুল সোজা করার ব্রাশ)</p>\r\n\r\n<p>✔ আপনার কোকড়ানো চুল সোজা করতে পারবেন ।</p>\r\n\r\n<p>✔ সহজেই ব্যাবহার করতে পারবেন ।</p>\r\n\r\n<p>✔ 450F উত্তপ্ত হবে ।</p>\r\n\r\n<p>✔ সব ধরনের চুলের জন্য উপযোগী ।</p>\r\n\r\n<p>✔ দ্রুত,নিরাপদ এবং সহজ ।</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ৬০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১০০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1034', 0, NULL, '', '', 1, 'general', '2020-01-08 02:45:37', '2020-01-08 02:45:37', 0, '', '', '', '', '', '', '', '', '', '', 0),
(21, 'Deep Cleaning Facial Osenjie Professional Facial Steamer - Thermal Sprayer Skin Care Tool household Spa beauty instrument', 'deep-cleaning-facial-osenjie-professional-facial-steamer---thermal-sprayer-skin-care-tool-household-spa-beauty-instrument', 1490, 0, '1290', ' ', '<p>Facial Steamer and Moisture Machine (ফেস ষ্টিমার)</p>\r\n\r\n<p>✔ স্টিম ইনহেলারযুক্ত Facial Sauna</p>\r\n\r\n<p>✔ এটির মুখের ত্বককে গভীর থেকে পরিস্কার করে, ত্বক থেকে অতিরিক্ত তৈলাক্ত ভাব দূর করে ও ত্বককে সুস্থ ও সুন্দর রাখে</p>\r\n\r\n<p>✔ ত্বকের সুষম আর্দ্রতা নিশ্চিত করে</p>\r\n\r\n<p>✔ মুখমন্ডল বা নাকের ত্বক সুরক্ষায় কার্যকর</p>\r\n\r\n<p>✔ ম্যাটেরিয়াল: ABS,মেটাল, প্লাস্টিক</p>\r\n\r\n<p>✔ স্টিম তৈরি হতে ৩ মিনিট সময় লাগে</p>\r\n\r\n<p>✔ স্টিম টাইমঃ 15-20 মিনিট</p>\r\n\r\n<p>✔ অন/ অফ সুইচ</p>\r\n\r\n<p>✔ থ্রী-গিয়ার কনট্রোল</p>\r\n\r\n<p>✔ পাওয়ার কানেকশন: AC</p>\r\n\r\n<p>✔ পাওয়ার: 80-100W</p>\r\n\r\n<p>✔ ফিচার: Moisturizer, Deep moisturizing,Treatment of common cold</p>\r\n\r\n<p>✔ পাওয়ার: 220V /50 Hz /100W</p>\r\n\r\n<p>✔ পার্সোনাল স্কিন কেয়ার: Suitable use with essential oil</p>\r\n\r\n<p>✔ টেকনোলজি: টেলফন ননস্টিক</p>\r\n\r\n<p>✔ ফেসিয়াল ছাড়াও বন্ধ নাক, ঠান্ডা জনিত কাশিতে ব্যবহার করা যায়</p>\r\n\r\n<p>✔ এরগোনমিক ডিজাইন</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1035', 0, NULL, '', '4QpzIFjibRg', 1, 'hotsell', '2020-01-08 02:51:52', '2020-01-08 02:51:52', 0, '', '', '', '', '', '', '', '', '', '', 0),
(22, 'Kemei KM-531 Dry Professional Electric Hair Straightener Curling Iron Styling Hair Fast Heating Hair Splint', 'kemei-km-531-dry-professional-electric-hair-straightener-curling-iron-styling-hair-fast-heating-hair-splint', 1200, 0, '990', ' ', '<p>Kemei Hair Straightener (চুল সোজা করার মেশিন)</p>\r\n\r\n<p>✔ ব্র্যান্ডঃ KEMEI</p>\r\n\r\n<p>✔ মডেলঃ KM-531</p>\r\n\r\n<p>✔ পাওয়ারঃ ২৫ W</p>\r\n\r\n<p>✔ ১০০% সিরামিক কোটিং</p>\r\n\r\n<p>✔ PTC হিটার উইথ ফাস্ট হিট আপ</p>\r\n\r\n<p>✔ সব ধরনের চুলের জন্য উপযোগী</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ৬০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১০০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1036', 0, NULL, '', '', 1, 'hotsell', '2020-01-08 04:10:54', '2020-01-08 04:10:54', 0, '', '', '', '', '', '', '', '', '', '', 0),
(23, '50 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '50-feet-magic-hose-pipe-multifunctional-expandable-garden-hose-garden-water-magic-hose-spray-gun-telescopic-water-pipe-high-pressure-car-wash-gun-7-way-sprayer', 990, 0, '650', ' ', '<p>✔&nbsp;ম্যাজিক হস-পাইপ নরমাল অবস্থায় খুবই হাল্কা এবং ছোট থাকে, কিন্ত যখন এটির মধ্যে পানি যায় তখন এটি দিগুন লম্বা হয় এবং পানির গতি বাড়িয়ে দেয় ।<br />\r\n✔&nbsp;প্রতিনিয়ত বিভিন্ন কাজে আপনাকে গাড়ী ব্যবহার করতে হয় আর এতে করে আপনার গাড়িটি ধুলাবালিতে ভরে যায়; আপনার মূল্যবান গাড়িটি সুন্দরভাবে পানি দিয়ে পরিষ্কারের জন্য ব্যবহার করুন ম্যাজিক হোস পাইপ<br />\r\n✔&nbsp;এছাড়াও ম্যাজিক হোস পাইপ দিয়ে আপনি আপনার বাসা,অফিস,পরিস্কার কিংবা ফুল বাগানে খুব সহজে পানি দিতে পারেন<br />\r\n✔&nbsp;হাই কোয়ালিটি রাবারের তৈরী<br />\r\n✔&nbsp;ফ্লেক্সিবল ও এক্সটেন্ডেবল পাইপ<br />\r\n✔&nbsp;হাল্কা ওজন, তাই সহজে বহনযোগ্য</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ৬০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১০০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1037-50', 0, NULL, '', '', 1, 'hotsell', '2020-01-08 04:19:14', '2020-01-08 04:19:14', 0, '', '', '', '', '', '', '', '', '', '', 0),
(24, '75 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '75-feet-magic-hose-pipe-multifunctional-expandable-garden-hose-garden-water-magic-hose-spray-gun-telescopic-water-pipe-high-pressure-car-wash-gun-7-way-sprayer', 990, 0, '700', ' ', '<p>✔&nbsp;ম্যাজিক হস-পাইপ নরমাল অবস্থায় খুবই হাল্কা এবং ছোট থাকে, কিন্ত যখন এটির মধ্যে পানি যায় তখন এটি দিগুন লম্বা হয় এবং পানির গতি বাড়িয়ে দেয় ।<br />\r\n✔&nbsp;প্রতিনিয়ত বিভিন্ন কাজে আপনাকে গাড়ী ব্যবহার করতে হয় আর এতে করে আপনার গাড়িটি ধুলাবালিতে ভরে যায়; আপনার মূল্যবান গাড়িটি সুন্দরভাবে পানি দিয়ে পরিষ্কারের জন্য ব্যবহার করুন ম্যাজিক হোস পাইপ<br />\r\n✔&nbsp;এছাড়াও ম্যাজিক হোস পাইপ দিয়ে আপনি আপনার বাসা,অফিস,পরিস্কার কিংবা ফুল বাগানে খুব সহজে পানি দিতে পারেন<br />\r\n✔&nbsp;হাই কোয়ালিটি রাবারের তৈরী<br />\r\n✔&nbsp;ফ্লেক্সিবল ও এক্সটেন্ডেবল পাইপ<br />\r\n✔&nbsp;হাল্কা ওজন, তাই সহজে বহনযোগ্য</p>\r\n', NULL, '', '1037-75', 0, NULL, '', '', 1, 'home', '2020-01-08 04:22:07', '2020-01-08 04:22:07', 0, '', '', '', '', '', '', '', '', '', '', 0),
(25, '100 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '100-feet-magic-hose-pipe-multifunctional-expandable-garden-hose-garden-water-magic-hose-spray-gun-telescopic-water-pipe-high-pressure-car-wash-gun-7-way-sprayer', 1190, 0, '800', ' ', '<p>✔&nbsp;ম্যাজিক হস-পাইপ নরমাল অবস্থায় খুবই হাল্কা এবং ছোট থাকে, কিন্ত যখন এটির মধ্যে পানি যায় তখন এটি দিগুন লম্বা হয় এবং পানির গতি বাড়িয়ে দেয় ।<br />\r\n✔&nbsp;প্রতিনিয়ত বিভিন্ন কাজে আপনাকে গাড়ী ব্যবহার করতে হয় আর এতে করে আপনার গাড়িটি ধুলাবালিতে ভরে যায়; আপনার মূল্যবান গাড়িটি সুন্দরভাবে পানি দিয়ে পরিষ্কারের জন্য ব্যবহার করুন ম্যাজিক হোস পাইপ<br />\r\n✔&nbsp;এছাড়াও ম্যাজিক হোস পাইপ দিয়ে আপনি আপনার বাসা,অফিস,পরিস্কার কিংবা ফুল বাগানে খুব সহজে পানি দিতে পারেন<br />\r\n✔&nbsp;হাই কোয়ালিটি রাবারের তৈরী<br />\r\n✔&nbsp;ফ্লেক্সিবল ও এক্সটেন্ডেবল পাইপ<br />\r\n✔&nbsp;হাল্কা ওজন, তাই সহজে বহনযোগ্য</p>\r\n', NULL, '', '1037-100', 0, NULL, '', '', 1, 'general', '2020-01-08 04:28:52', '2020-01-08 04:28:52', 0, '', '', '', '', '', '', '', '', '', '', 0),
(26, '150 Feet Magic Hose Pipe, Multifunctional Expandable Garden Hose Garden Water Magic Hose Spray Gun Telescopic Water Pipe High Pressure Car Wash Gun 7 Way Sprayer', '150-feet-magic-hose-pipe-multifunctional-expandable-garden-hose-garden-water-magic-hose-spray-gun-telescopic-water-pipe-high-pressure-car-wash-gun-7-way-sprayer', 1390, 0, '850', ' ', '<p>✔&nbsp;ম্যাজিক হস-পাইপ নরমাল অবস্থায় খুবই হাল্কা এবং ছোট থাকে, কিন্ত যখন এটির মধ্যে পানি যায় তখন এটি দিগুন লম্বা হয় এবং পানির গতি বাড়িয়ে দেয় ।<br />\r\n✔&nbsp;প্রতিনিয়ত বিভিন্ন কাজে আপনাকে গাড়ী ব্যবহার করতে হয় আর এতে করে আপনার গাড়িটি ধুলাবালিতে ভরে যায়; আপনার মূল্যবান গাড়িটি সুন্দরভাবে পানি দিয়ে পরিষ্কারের জন্য ব্যবহার করুন ম্যাজিক হোস পাইপ<br />\r\n✔&nbsp;এছাড়াও ম্যাজিক হোস পাইপ দিয়ে আপনি আপনার বাসা,অফিস,পরিস্কার কিংবা ফুল বাগানে খুব সহজে পানি দিতে পারেন<br />\r\n✔&nbsp;হাই কোয়ালিটি রাবারের তৈরী<br />\r\n✔&nbsp;ফ্লেক্সিবল ও এক্সটেন্ডেবল পাইপ<br />\r\n✔&nbsp;হাল্কা ওজন, তাই সহজে বহনযোগ্য</p>\r\n', NULL, '', '1037-150', 0, NULL, '', '', 1, 'general', '2020-01-08 04:30:47', '2020-01-08 04:30:47', 0, '', '', '', '', '', '', '', '', '', '', 0),
(27, 'Sound Amplifier Hearing Aid Adjustable Tone Battery Mini In Ear Aids', 'sound-amplifier-hearing-aid-adjustable-tone-battery-mini-in-ear-aids', 990, 0, '800', ' ', '<h2>Hearing aid (কানে শুনার যন্ত্র )</h2>\r\n\r\n<p>✔ কানে শুনার যন্ত্র (Hearing Aid)</p>\r\n\r\n<p>✔ এই ডিভাইসটি আপনাকে পরিষ্কার ভাবে শুনতে সাহায্য করবে ।</p>\r\n\r\n<p>✔ সিভিয়ার ওপ্রোফাউন্ড হিয়ারিং লসের পেশেন্টদের উপযোগী।</p>\r\n\r\n<p>✔ শব্দ কমাতে-বাড়াতে পারবেন ।</p>\r\n\r\n<p>✔ ৩ টি ক্লক ব্যাটারীর ব্যাবহার করতে হবে ।</p>\r\n', NULL, '', '1038', 0, NULL, '', '', 1, 'hotsell', '2020-01-08 04:32:52', '2020-01-08 04:32:52', 0, '', '', '', '', '', '', '', '', '', '', 0),
(28, 'Infrared Foot Massager, Vibrating Massage Blood Circulation Pain Relief Pedicure Machine Electric 220V Infrared Treatment Magnetic Wave Heating Therapy', 'infrared-foot-massager-vibrating-massage-blood-circulation-pain-relief-pedicure-machine-electric-220v-infrared-treatment-magnetic-wave-heating-therapy', 2000, 0, '1900', ' ', '<h2>Infrared Foot Massager</h2>\r\n\r\n<p>✔ ডায়বেটিস রুগি ও যারা হাটতে পারেনা তাদের জন্য অত্যন্ত কার্যকর</p>\r\n\r\n<p>✔ এটি রক্ত সঞ্চালনে সহায়তা করে,</p>\r\n\r\n<p>✔ প্রতিদিন ১০ মিনিট ব্যবহার সুফল পেতে পারেন,</p>\r\n\r\n<p>✔ এটি সম্পুর্ন এক্সটারনাল তাই কোন পার্শ প্রতিক্রিয়া নেই</p>\r\n\r\n<p>✔ পরিবারের সবার জন্য ব্যবহার উপযোগী</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1039', 0, NULL, '', 'SRiYk4ksAzE', 1, 'home', '2020-01-08 04:38:12', '2020-01-08 04:38:12', 0, '', '', '', '', '', '', '', '', '', '', 0),
(29, 'Multifunction Hot Water Bag, Electric Rechargeable Heat Water Bag, Electric Hand Warmer Long Heat Stability', 'multifunction-hot-water-bag-electric-rechargeable-heat-water-bag-electric-hand-warmer-long-heat-stability', 790, 0, '590', ' ', '<p>Electric হট ওয়াটার ব্যাগ</p>\r\n\r\n<p>✔ ঠান্ডাজনিত যাদে বিভিন্ন ব্যথার জন্য যারা গরম পানির শেক দিতে হয় তাদের জন্য খুবই প্রয়োজনীয় একটি পণ্য।</p>\r\n\r\n<p>✔ ব্যবহার করা খুব সহজ।</p>\r\n\r\n<p>✔ ব্যাগে পানি ভরে পাওয়ার কর্ড লাগিয়ে পানি গরম করে নিতে পারবেন ২-৩ মিনিটের মধ্যেই।</p>\r\n\r\n<p>✔ Its auto warm function থাকার কারনে পানি গরম থাকবে দীর্ঘক্ষণ।</p>\r\n\r\n<p>✔ এটি shock proof এবং low power cost</p>\r\n\r\n<p>✔ যাবতীয় ব্যাথার স্থানে ব্যবহারযোগ্য।</p>\r\n\r\n<p>✔ গরম করা খুব সহজ, plug টি কানেক্ট কেরো রেখে দেন indicator light off হওয়া পর্যন্ত।</p>\r\n\r\n<p>✔ Color: Random</p>\r\n', NULL, '', '1040', 0, NULL, '', 'N-KA1JR_pVA', 1, 'general', '2020-01-08 04:59:56', '2020-01-08 04:59:56', 0, '', '', '', '', '', '', '', '', '', '', 0),
(30, 'Mini Digital Scale Luggage Travel Weighing Scale Hanging Electronic Hook Scales Portable Weighing Tool with LCD display', 'mini-digital-scale-luggage-travel-weighing-scale-hanging-electronic-hook-scales-portable-weighing-tool-with-lcd-display', 590, 0, '490', ' ', '<h2><strong>Portable Scale (ওজন পরিমাপের স্কেল)</strong></h2>\r\n\r\n<p>✔ ওজন মাপার জন্য আদর্শ ,উচ্চক্ষমতা সম্পন্ন ডিভাইস</p>\r\n\r\n<p>✔ এটি সহজে বহন করা যায়</p>\r\n\r\n<p>✔ ওয়েট রেঞ্জ ৫০kg</p>\r\n', NULL, '', '1041', 0, NULL, '', '', 1, 'hotsell', '2020-01-08 05:05:34', '2020-01-08 05:05:34', 0, '', '', '', '', '', '', '', '', '', '', 0),
(31, 'Wax Vac Gentle and Effective Ear Cleaner, Ear Wax Remover Electric Vac Vacuum Cordless Earwax Removal Painlessly Tool', 'wax-vac-gentle-and-effective-ear-cleaner-ear-wax-remover-electric-vac-vacuum-cordless-earwax-removal-painlessly-tool', 590, 0, '450', ' ', '<h2><strong>কান পরিষ্কার করার যন্ত্র</strong></h2>\r\n\r\n<p>✔ Wax Vac ইয়ার ক্লিনার |</p>\r\n\r\n<p>✔ আপনার কান পরিস্কারের সহজ ও নিরাপদ উপায় |</p>\r\n\r\n<p>✔ কোমল suction draw আপনার কানের ভেতর থেকে ময়লা এবং ময়েশ্চারবের করে নিয়ে আসে |</p>\r\n\r\n<p>✔ এখন থেকে চিরতরে কটনবাডকে বলে দিন বিদায় |</p>\r\n\r\n<p>✔ কোমল এবং কার্যকর ইউনিক সেফটি গাইড টিপকে আপনার কানের ক্যানালকে রাখে নিরাপদ |</p>\r\n\r\n<p>✔ ব্যবহারযোগ্য ৮ টি কালারকোডেড সিলিকন টিপস এবং হ্যান্ডি ক্লিনিং ব্রাশ |</p>\r\n\r\n<p>✔ ব্যাটারি চালিতএকটি শক্তিশালী পরীক্ষণ লাইট |</p>\r\n\r\n<p>✔ টিপ ম্যাটেরিয়াল: নন-টক্সিক সিলিকন |</p>\r\n\r\n<p>✔ পাওয়ার: ২&times;AA ব্যাটারি (ব্যাটারি সাথে দেওয়া নেই) |</p>\r\n', NULL, '', '1042', 0, NULL, '', '', 1, 'home', '2020-01-08 05:07:26', '2020-01-08 05:07:26', 0, '', '', '', '', '', '', '', '', '', '', 0),
(32, 'Real Time Mini GPS Tracker for Vehicles - Smart Magnetic Car Tracker Locator Device Voice Recorder - Location Tracker for Cars, Boats, Motorcycle', 'real-time-mini-gps-tracker-for-vehicles---smart-magnetic-car-tracker-locator-device-voice-recorder---location-tracker-for-cars-boats-motorcycle', 1490, 0, '1390', ' ', '<h2><strong>GPS Location Tracker with Sim Device</strong></h2>\r\n\r\n<p>✔ হারিয়ে বা চুরি হলেও জানতে পারবেন গাড়ির লোকেশন</p>\r\n\r\n<p>✔ ডিভাইসটির ভিতর আপনার পছন্দ মতো সিম ঢুকিয়ে কোন গোপন জায়গায় রেখে দিবেন,তারপর আপনার এই সিম নম্বরে আপনি পৃথিবীর যে কোন জায়গা থেকে কল দিলে,,সেইজায়গার ১০ মিটারের মধ্যে যে বা যারা কথা বলবে তা আপনি শুনতে পারবেন, কেউ টেরই পাবে না আপনি শুনছেন</p>\r\n\r\n<p>✔ যেকোনো সিম কার্ড যুক্ত করে অ্যাকটিভ করুন, এর জন্য ইন্টারনেট সংযোগের প্রয়োজন নেই।</p>\r\n\r\n<p>✔ লোকেশন দেখার জন্য মোবাইল ফোন থেকে &quot; DW&#39;&#39; লিখে SMS করতে হবে ডিভাইস এ রাখা সিমে।</p>\r\n\r\n<p>✔ রিটার্ন SMS এ Google Map এর একটি লিংক আসবে। এবার মোবাইলে ইন্টারনেট সংযোগ সচল করুন এবং লিংকে যান।</p>\r\n\r\n<p>✔ লিংকে Google Map এর মতই আসবে লোকেশন। এভাবেই ট্র্যাক করতে পারবেন আপনার গাড়ি বা যেকোন পরিবহন।</p>\r\n\r\n<p>✔ ১ বার চার্জ দিলে ২-৩ দিন চলে।</p>\r\n', NULL, '', '1043', 0, NULL, '', '', 1, 'hotsell', '2020-01-08 05:10:07', '2020-01-08 05:10:07', 0, '', '', '', '', '', '', '', '', '', '', 0),
(33, 'Multifunctional Manual Hand Juicer', 'multifunctional-manual-hand-juicer', 1290, 0, '890', ' ', '<h2><strong>Manual Hand Juicer</strong></h2>\r\n\r\n<p>✔ ম্যানুয়াল ফ্রুট এন্ড ভেজিটেবল জুসার</p>\r\n\r\n<p>✔ হাই কোয়ালিটি</p>\r\n\r\n<p>✔ ম্যাটেরিয়াল- প্লাস্টিক ও স্টেইনলেস স্টিল</p>\r\n\r\n<p>✔ এটা চালাতে বিদ্যুৎ লাগে না</p>\r\n\r\n<p>✔ জুস বানাতে ব্যবহার করুন</p>\r\n\r\n<p>✔ সব অংশ খোলা যাবে</p>\r\n\r\n<p>✔ সহজে পরিষ্কার করা যায়</p>\r\n', NULL, '', '1044', 0, NULL, '', '', 1, 'general', '2020-01-08 05:12:26', '2020-01-08 05:12:26', 0, '', '', '', '', '', '', '', '', '', '', 0),
(34, 'Digital LCD Upper Arm Blood Pressure Monitor Medical Equipment Heart Beat Meter Machine Adjustable Wrist Cuffs for Health Monitoring', 'digital-lcd-upper-arm-blood-pressure-monitor-medical-equipment-heart-beat-meter-machine-adjustable-wrist-cuffs-for-health-monitoring', 2200, 0, '1490', ' ', '<h2><strong>ব্লাড প্রেসার মাপার যন্ত্র</strong></h2>\r\n\r\n<p>✔ এক্সট্রা লার্জ LCD ডিসপ্লে উইথ ডিজিটাল ডিসপ্লে সিস্টেম</p>\r\n\r\n<p>✔ ১২০ মেমোরি স্টোরেজ</p>\r\n\r\n<p>✔ ব্লাড প্রেসার লেভেল ইন্ডিকেটর</p>\r\n\r\n<p>✔ ডিটেক্ট ইরেগুলার হার্টবিট ডিটেক্ট</p>\r\n\r\n<p>✔ মুভমেন্ট ডিটেকশন</p>\r\n\r\n<p>✔ Charger/ ৪টি AA ব্যাটারি দ্বারা চালিত</p>\r\n\r\n<p>✔ ভয়েজ সিষ্টেম যা আপনাকে প্রয়োজনীয় তথ্য ভয়েজ আকারে শুনিয়ে দিবে। তাই অনভিজ্ঞ যে কেউ এই মেশিনটি ব্যবহার করতে পারবেন।</p>\r\n', NULL, '', '1046', 0, NULL, '', 'I_jvJpSEyqA', 1, 'home', '2020-01-08 05:15:11', '2020-01-08 05:15:11', 0, '', '', '', '', '', '', '', '', '', '', 0),
(35, 'Hot Sweat Neoprene Body Shaper Slimming Belt Waist for Weight Loss Women & Men ', 'hot-sweat-neoprene-body-shaper-slimming-belt-waist-for-weight-loss-women--men-', 550, 0, '450', ' ', '<p>✔ আপনি প্রতিদিন এক্সারসাইজের সময় বা দৈনন্দিন কাজের সময় পোশাকের নিচে পড়তে পারেন।</p>\r\n\r\n<p>✔ এটা Neoprene Fabric-এ তৈরী যা আপনার বডি টেম্পারেচার বাড়িয়ে দেয়; আপনার ঘাম বেড়ে যায় এবং ফ্যাট বার্ন হয় যা আপনাকে আকর্ষনীয় ওয়েস্টলাইনের অধিকারী করে।</p>\r\n\r\n<p>✔ Febrics এর internal texture আপনাকে ঘর্মাক্ত করে আর external tuxture আপনার ঘাম ও আর্দ্রতা শোষন করে নেয়</p>\r\n\r\n<p>✔ এর Unique outer texture আপনাকে শুষ্ক রাখে সবসময়।</p>\r\n\r\n<p>✔ এটা রীতিমত ব্যবহারে আপনি হবেন স্লিম ও আকর্ষণীয়।</p>\r\n\r\n<p>✔ এটা পড়তে আপনি বিরক্তিবোধ করবেন না, স্বস্তি ও আরামদায়ক মনে হবে।</p>\r\n\r\n<p>✔ পুরুষ ও মহিলা উভয়ের ব্যবহারপোযোগী।</p>\r\n\r\n<p>✔ সাইজঃ M, L, XL,XXL</p>\r\n', NULL, '', '1048', 0, NULL, '', '', 1, 'home', '2020-01-08 05:29:57', '2020-01-08 05:29:57', 0, '', '', '', '', '', '', '', '', '', '', 0),
(36, 'Single Air Bed Air Mattress Camping Mat Inflatable Mattress Camping Bed Beach mat With Electric Pump', 'single-air-bed-air-mattress-camping-mat-inflatable-mattress-camping-bed-beach-mat-with-electric-pump', 2590, 0, '2300', ' ', '<p>Single Air Bed with pumper (এয়ার বেড উইথ পাম্পার)</p>\r\n\r\n<p>✔ Intex সিঙ্গেল এয়ার বেড উইথ এয়ার পাম্পার</p>\r\n\r\n<p>✔ আরামদায়ক</p>\r\n\r\n<p>✔ ফোল্ডিং ডিজাইন</p>\r\n\r\n<p>✔ সাইজ: 30&rdquo; x 75&rdquo; x 8 &frac34;&rdquo;</p>\r\n\r\n<p>✔ ম্যাটেরিয়ালঃ 0.30 mm PVC</p>\r\n\r\n<p>✔ ওজন: 3 কেজি</p>\r\n\r\n<p>✔ ফ্রি এয়ার পাম্পার</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1049', 0, NULL, '', '', 1, 'home', '2020-01-08 05:32:57', '2020-01-08 05:32:57', 0, '', '', '', '', '', '', '', '', '', '', 0),
(37, 'Round shape Inflatable air Sofa Bed for 2 person, Creative Lazy Sofa Home Air Bed Household Products', 'round-shape-inflatable-air-sofa-bed-for-2-person-creative-lazy-sofa-home-air-bed-household-products', 9200, 0, '8500', ' ', '<p>Intex Round Shape Air Sofa (এয়ার সোফা)</p>\r\n\r\n<p>✔ রাউন্ড শেপ 2 পারসন ডাবল সাইজ এয়ার ম্যাট্রেস</p>\r\n\r\n<p>✔ ইনফ্লাটেবল</p>\r\n\r\n<p>✔ ম্যাটেরিয়াল: PVC</p>\r\n\r\n<p>✔ আউটডোর এক্টিভিটি, পিকনিক, বারবিকিউ</p>\r\n\r\n<p>✔ ডাম্প প্রুফ</p>\r\n\r\n<p>✔ ম্যাট টাইপ: ম্যাট্রেস</p>\r\n\r\n<p>✔ টপ ফ্লোকড</p>\r\n\r\n<p>✔ কালর: Random</p>\r\n\r\n<p>✔ সাইজ: 191cm X 53cm</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1050', 0, NULL, '', '', 1, 'home', '2020-01-08 05:35:09', '2020-01-08 05:35:09', 0, '', '', '', '', '', '', '', '', '', '', 0),
(38, 'Kemei KM-1055 2 in 1 Professional Hair Straightener Iron Hair Curler, Hair Straightening Styling Tools', 'kemei-km-1055-2-in-1-professional-hair-straightener-iron-hair-curler-hair-straightening-styling-tools', 1290, 0, '990', ' ', '<p>Kemei 2 in 1 Hair Straightener (চুল সোজা ও কার্লার করার মেশিন)</p>\r\n\r\n<p>✔ 2 In 1 হেয়ার স্ট্রেইটনিং ও কার্লিং আইরন</p>\r\n\r\n<p>✔ ম্যাটেরিয়াল: ABS+ Tourmaline ceramic</p>\r\n\r\n<p>✔ ভোল্টেজ: 110~240V</p>\r\n\r\n<p>✔ অন/অফ সুইচ পাওয়ার ইনডিকেটর লাইট</p>\r\n\r\n<p>✔ ১০০% শক proof ফিলামেন্ট</p>\r\n\r\n<p>✔ কালারঃ পিঙ্ক</p>\r\n\r\n<p>✔ প্লেট টাইপ: সিরামিক</p>\r\n\r\n<p>✔ স্টেইনলেস স্টিল</p>\r\n\r\n<p>✔ স্টাইলিশ ডিজাইন।</p>\r\n', NULL, '', '1051', 0, NULL, '', '', 1, 'home', '2020-01-08 05:36:37', '2020-01-08 05:36:37', 0, '', '', '', '', '', '', '', '', '', '', 0),
(39, 'Easy Egg Cracker - Creative Kitchen Egg Tools  with Egg White Separator Cooking Tool', 'easy-egg-cracker---creative-kitchen-egg-tools--with-egg-white-separator-cooking-tool', 490, 0, '450', ' ', '<p>Egg Cracker &amp; Separator (ডিম ভাঙ্গার যন্ত্র)</p>\r\n\r\n<p>✔ এর সাহায্যে কোন প্রকার ঝামেলা ছাড়াই ডিম ভাঙ্গতে পারবেন ।</p>\r\n\r\n<p>✔ বিশেষ ছাকনির সাহায্যে সাদা অংশ এবং কুসুমকে আলাদা করতে পারবেন ।</p>\r\n', NULL, '', '1052', 0, NULL, '', '', 1, 'home', '2020-01-08 05:37:58', '2020-01-08 05:37:58', 0, '', '', '', '', '', '', '', '', '', '', 0),
(40, 'Aluminum Hack Saw Handsaw Frame Blade Dual Rubber Handles ', 'aluminum-hack-saw-handsaw-frame-blade-dual-rubber-handles-', 690, 0, '590', ' ', '<p>✔ Hacksaw Frame</p>\r\n\r\n<p>✔ এ্যালুমিনিয়াম এবং TPR হ্যান্ডেল।</p>\r\n\r\n<p>✔ ১ টি স&#39;ব্লেড ফ্রী ।</p>\r\n\r\n<p>✔ টেকশই, মজবুত।</p>\r\n\r\n<p>✔ সাইজ: 330mm, 13&quot;</p>\r\n', NULL, '', '1053', 0, NULL, '', '', 1, 'general', '2020-01-08 05:39:05', '2020-01-08 05:39:05', 0, '', '', '', '', '', '', '', '', '', '', 0),
(41, 'Multi-function Adjustable Wrench Snap\'N Grip Tools (2Pcs 9-32mm Spanner Set)', 'multi-function-adjustable-wrench-snapn-grip-tools-2pcs-9-32mm-spanner-set', 390, 0, '350', ' ', '<p>✔ প্লাম্বিং, কার্পেন্ট্রি, মেকানিকাল ওয়ার্ক ও গার্ডেনিং -এর জন্য আদর্শ</p>\r\n\r\n<p>✔ ম্যাটেরিয়ালঃ স্টেইনলেস স্টিল ম্যাটেরিয়াল+ রাবার +প্লাস্টিক</p>\r\n\r\n<p>✔ SNAP &amp; GRIP স্প্যানার সেট</p>\r\n\r\n<p>✔ সেলফ অ্যাডজাস্টিং টেকনোলজি</p>\r\n\r\n<p>✔ হাই কোয়ালিটি ব্র্যান্ড নিউ প্রোডাক্ট</p>\r\n', NULL, '', '1054', 0, NULL, '', '', 1, 'home', '2020-01-08 05:42:01', '2020-01-08 05:42:01', 0, '', '', '', '', '', '', '', '', '', '', 0),
(42, 'USB Mini Fish Tank Desktop Aquarium With Lamp Light, Clock, Water Recirculation Best Gift Item', 'usb-mini-fish-tank-desktop-aquarium-with-lamp-light-clock-water-recirculation-best-gift-item', 2590, 0, '2300', ' ', '<p>Mini USB Desktop Aquarium</p>\r\n\r\n<p>✔ বাসা বা অফিসে শোভা বর্ধনে আকর্ষনীয় পন্য মিনি একুরিয়াম ।</p>\r\n\r\n<p>✔ এতে রয়েছে ন্যাচারাল সাউন্ড সিস্টেম ।</p>\r\n\r\n<p>✔ LED লাইট থাকায় রাতেও আপনার ঘরের সৌন্ধর্য বৃদ্ধি করবে ।</p>\r\n\r\n<p>✔ অক্সিজেনের জন্য কল রয়েছে।</p>\r\n\r\n<p>✔ ডিজিটাল ঘড়ি ।</p>\r\n\r\n<p>✔ ডিজিটাল রুম টেম্পারেচার মিটার,ক্যালেন্ডার,কলমদানি/ফুলদানি,</p>\r\n\r\n<p>✔ এর মধ্যে 1.5L পানি দিতে পারবেন।</p>\r\n', NULL, '', '1055', 0, NULL, '', '', 1, 'home', '2020-01-08 05:55:53', '2020-01-08 05:55:53', 0, '', '', '', '', '', '', '', '', '', '', 0),
(43, 'Flawless Hair Remover, Facial Hair Removal for Women, Painless Electric Hair Remover for Women\'s Cheeks, Lips, Chin and Neck Built-in LED Light', 'flawless-hair-remover-facial-hair-removal-for-women-painless-electric-hair-remover-for-womens-cheeks-lips-chin-and-neck-built-in-led-light', 790, 0, '650', ' ', '<p>✔ মুখ মন্ডলের অবাঞ্চিত লোম পরিষ্কার করতে পারেন ।</p>\r\n\r\n<p>✔ ভেতরে লাইট থাকায় একটি লোম কাটতে সুবিধা ।</p>\r\n\r\n<p>✔ হাতের মুঠোয় ধরে ব্যাবহার করতে পারবেন ।</p>\r\n\r\n<p>✔ সব মহিলাদের জন্য উপযুক্ত।</p>\r\n\r\n<p>✔ প্রতিদিন ব্যবহার করলে আপনি পাবেন নিখুঁত এবং দীর্ঘস্থায়ী মসৃণতা ।</p>\r\n\r\n<p>✔ অত্যন্ত ছোট তাই হাত ব্যাগে বহন করা যায়।</p>\r\n', NULL, '', '1056', 0, NULL, '', '-deyfWXRvxM', 1, 'general', '2020-01-08 06:00:38', '2020-01-08 06:00:38', 0, '', '', '', '', '', '', '', '', '', '', 0),
(44, 'Pain Relief Vibrating Massage Bed / Electric Vibrator Heating Back Neck Massager Mattress Leg Waist Cushion Mat Home Office Relax Bed  Health Care', 'pain-relief-vibrating-massage-bed--electric-vibrator-heating-back-neck-massager-mattress-leg-waist-cushion-mat-home-office-relax-bed--health-care', 2790, 0, '2650', ' ', '<p>✔ আপনার সারাদিনের ক্লান্তি দুর করতে ব্যাবহার করুন রিলাক্সিং ম্যাসেজ বেড।</p>\r\n\r\n<p>✔ আপনার ক্লান্তি দুর করার জন্য আমরা নিয়ে এলাম রিলাক্সিং ম্যাসেজ বেড।</p>\r\n\r\n<p>✔ ভাইব্রেশনের মাধ্যমে আপনার শরীর ম্যাসেজ করতে পারবেন।</p>\r\n\r\n<p>✔ কন্ট্রোলারের সাহায্যে প্রয়োজন অনুযায়ী ভাইব্রেশন কমাতে ও বাড়াতে পারবেন ।</p>\r\n\r\n<p>✔ হিট বাটন চেপে সহনীয় তাপমাত্রা নিতে পারবেন।</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1057', 0, NULL, '', '', 1, 'home', '2020-01-08 06:04:37', '2020-01-08 06:04:37', 0, '', '', '', '', '', '', '', '', '', '', 0),
(45, 'Power Extension Socket Outlet Portable Travel Power Strip Surge Protector With 4 USB port Smart Charger Wall', 'power-extension-socket-outlet-portable-travel-power-strip-surge-protector-with-4-usb-port-smart-charger-wall', 590, 0, '550', ' ', '<p>Multifunctional 4-Port USB Travel Charger</p>\r\n\r\n<p>✔ স্টাইলিশ ডিজাইনের ইউনিভার্সাল সকেট</p>\r\n\r\n<p>✔ ৫ টি পোর্ট</p>\r\n\r\n<p>✔ ৪ টি USB সকেট</p>\r\n\r\n<p>✔ পাওয়ার অ্যাডাপ্টারঃ EU প্লাগ</p>\r\n\r\n<p>✔ ক্যাবল লেন্থঃ ১৩০ সেন্টিমিটার</p>\r\n\r\n<p>✔ ইনপুটঃ 110-240V, 50/60Hz</p>\r\n\r\n<p>✔ আউটপুটঃ DC5V 3.5A</p>\r\n', NULL, '', '1058', 0, NULL, '', '', 1, 'home', '2020-01-08 06:06:16', '2020-01-08 06:06:16', 0, '', '', '', '', '', '', '', '', '', '', 0);
INSERT INTO `product` (`product_id`, `product_title`, `product_name`, `product_price`, `purchase_price`, `discount_price`, `product_summary`, `product_description`, `product_specification`, `product_terms`, `sku`, `product_stock`, `product_of_size`, `product_color`, `product_video`, `status`, `product_type`, `created_time`, `modified_time`, `folder`, `feasured_image`, `galary_image_6`, `galary_image_1`, `galary_image_2`, `galary_image_3`, `galary_image_4`, `galary_image_5`, `seo_title`, `seo_keywords`, `seo_content`, `stock_alert`) VALUES
(46, '5 in 1 Large Inflatable Sofa cum bed, Double Sofa Bed Double Air Bed Multifunction Couch Camping Mattress', '5-in-1-large-inflatable-sofa-cum-bed-double-sofa-bed-double-air-bed-multifunction-couch-camping-mattress', 6500, 0, '5290', ' ', '<p>✔ বাতাসে ফুলাতে হয়,আবার বাতাস বের করে ছোট্ট ব্যাগেই বহন করতে পারবেন যেকোন জায়গায়।</p>\r\n\r\n<p>✔ একের ভিতর পাঁচ! এই ইনফ্লাটেবল এয়ারপাম্প সোফাকে সামান্য ফ্লিপ করে আপনি করে ফেলতে পারবেন মাস্টার বেড, কিডস সিঙ্গল বেড, রেকলাইনার, লাউঞ্জার এবং লাক্সারিয়ার সোফা।</p>\r\n\r\n<p>✔ সাথে পাচ্ছেন ৭৭০ টাকার ইলেক্ট্রিক পাম্পার একদম ফ্রি।</p>\r\n\r\n<p>✔ এটি একটি Sophisticated সোফা, একটি লাক্সারিয়াস lounger, একটি relaxed recliner, বাচ্চাদের একটি হাই রাইজ বোস্টার স্লিপার, একটি চমৎকার blissful বেড</p>\r\n\r\n<p>✔ অবিশ্বাস্য All in one প্রোডাক্ট এবং এই সবই আপনার ট্রাভেল ব্যাগের ভেতর এটে যাবে এবং আপনি যেখানেই যান, বহন করে নিয়ে যেতে পারেন সাথে করে!</p>\r\n\r\n<p>✔ ৫ ইন ১ সোফা বেড</p>\r\n\r\n<p>✔ ডুয়াল অ্যাকশন টার্বো পাওয়ার পাম্প</p>\r\n\r\n<p>✔ ট্রাভেল ক্যারি ব্যাগ</p>\r\n\r\n<p>✔ একটি ফ্যাশনেবল-স্টাইল সোফা বেড যা আপনার যে কোন প্রকার ডেকোরেশনের সাথে মানানসই</p>\r\n\r\n<p>✔ লাক্সারিয়াস লেদার ফিনিশ ইফেক্ট</p>\r\n\r\n<p>✔ স্ট্রং এবং লাইটওয়েট</p>\r\n\r\n<p>✔ এক মুহুর্তে Rolled-Up থেকে Set &ndash;Up</p>\r\n\r\n<p>✔ সাথে আছে মাল্টি-পারপাজ ডাবল অ্যাকশন Inflation/Deflation পাম্প যা ১২০ সেকেন্ডে বায়ু পরিপূর্ণ করে।</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1059', 0, NULL, '', '', 1, 'general', '2020-01-08 06:08:55', '2020-01-08 06:08:55', 0, '', '', '', '', '', '', '', '', '', '', 0),
(47, 'Professional Drill Machine Set with 100 pcs Tool Kit', 'professional-drill-machine-set-with-100-pcs-tool-kit', 2290, 0, '2050', ' ', '<p>ড্রিল মেশিন টুল বক্স (১০০ পিস সেট)</p>\r\n\r\n<p>✔ বাসা বা অফিসের দৈনন্দিন কাজের জন্য প্রয়োজনীয় কিছু টুলসের সমন্বয়ে একটি টুল বক্স</p>\r\n\r\n<p>✔ যা হাতের কাছে থাকলে আর আপনার দৌড়াতে হবেনা কোন ইলেকট্রেশিয়ানের কাছে</p>\r\n\r\n<p>✔ এতে যা থাকছে :</p>\r\n\r\n<p>১ পিস ড্রিল</p>\r\n\r\n<p>১ পিস ড্রিল মেশিনের কার্বন</p>\r\n\r\n<p>১ পিস হ্যামার হ্যান্ডেল</p>\r\n\r\n<p>১ পিস হাতুড়ি</p>\r\n\r\n<p>১ পিস স্ক্রু ড্রাইভার</p>\r\n\r\n<p>১ পিস কম্বিনেশন প্লাস</p>\r\n\r\n<p>১ পিস সিলাই রেন্জ</p>\r\n\r\n<p>১ পিস কেবল কাটার</p>\r\n\r\n<p>১ পিস মেজারিং টেপ</p>\r\n\r\n<p>৯ পিস সকেট রেন্জ (গুটি সেট)</p>\r\n\r\n<p>১২ পিস স্ক্রু সেট (১২ রকমের)</p>\r\n\r\n<p>১৫ পিস ড্রিল বিট</p>\r\n\r\n<p>৫০ পিস রয়েল প্লাগ</p>\r\n', NULL, '', '1060', 0, NULL, '', '', 1, 'general', '2020-01-08 06:10:53', '2020-01-08 06:10:53', 0, '', '', '', '', '', '', '', '', '', '', 0),
(48, 'Stainless Steel 8 inches Roti Maker/Puri Press/Puri Maker/Papad maker/Khakhra Maker/paratha maker', 'stainless-steel-8-inches-roti-makerpuri-presspuri-makerpapad-makerkhakhra-makerparatha-maker', 1290, 0, '990', ' ', '<h2><strong>Roti Maker (Manual)</strong></h2>\r\n\r\n<p>✔ ৮ ইঞ্চি ম্যনুয়াল রুটি মেকার...ফ্যমিলি size রুটি।</p>\r\n\r\n<p>✔ এটা কারেন্ট ছাড়া কাজ করে</p>\r\n\r\n<p>✔ কষ্ট ছাড়া রুটি বানানো যায়</p>\r\n\r\n<p>✔ স্টেইনলেস স্টীল কভার</p>\r\n', NULL, '', '1061', 0, NULL, '', '', 1, 'general', '2020-01-08 06:13:20', '2020-01-08 06:13:20', 0, '', '', '', '', '', '', '', '', '', '', 0),
(49, 'Waterproof Siren Alarm Padlock Alarm Lock for Motorcycle Bike Bicycle Perfect Security with 110dB Alarm Pad locks', 'waterproof-siren-alarm-padlock-alarm-lock-for-motorcycle-bike-bicycle-perfect-security-with-110db-alarm-pad-locks', 790, 0, '750', ' ', '<p>সিকিউরিটি এলার্ম লক (Security Alarm Lock)</p>\r\n\r\n<p>✔ মোটরসাইকেল, বাইসাইকেল এবং বাসা -বাড়ির নিরাপত্তায় বিশেষ উপযোগী</p>\r\n\r\n<p>✔ লকের গায়ে সামান্য আঘাত প্রদান মাত্রই উচ্চশব্দে (১১০ডেসিবল) অ্যালার্ম বেজে উঠবে</p>\r\n\r\n<p>✔ সাধারণ তালা হিসেবেও ব্যবহার করা যাবে অ্যালার্ম বিহীন।</p>\r\n\r\n<p>✔ দীর্ঘ স্থায়ী ব্যাটারি, তাই চলে বহু দিন. ব্যাটারি খুব সহজেই প্রতিস্থাপন যোগ্য</p>\r\n\r\n<p>✔ সম্পূর্ণ স্টেইনলেস স্টিলের তৈরি</p>\r\n\r\n<p>✔ সাথে পাচ্ছেন এক সেট ব্যাটারি ফ্রি।</p>\r\n', NULL, '', '1063', 0, NULL, '', 'T32-w9gL9yg', 1, 'general', '2020-01-08 06:15:39', '2020-01-08 06:15:39', 0, '', '', '', '', '', '', '', '', '', '', 0),
(50, 'KeySmart Compact Key Holder(2 to 10 Keys) Pocket Key Wallet Smart keychain Key Ring Wallets Portable Compact Aluminum key clip Multi-functional Smart Clip', 'keysmart-compact-key-holder2-to-10-keys-pocket-key-wallet-smart-keychain-key-ring-wallets-portable-compact-aluminum-key-clip-multi-functional-smart-clip', 390, 0, '300', ' ', '<p>KEY SMART ( চাবি গুছিয়ে রাখার অসাধারন একটি ডিভাইস )</p>\r\n\r\n<p>✔ আপনার চাবিগুলো খুব সুন্দরভাবে গুছিয়ে রাখতে পারবেন।</p>\r\n\r\n<p>✔ এতে আপনি ৮ টি থেকে ১২ টি চাবি রাখতে পারবেন,</p>\r\n\r\n<p>✔ অ্যালুমিনিয়াম এর তৈরি</p>\r\n\r\n<p>✔ সাইজে ছোট তাই সহজেই বহন পকেটে বা সাইট ব্যাগে নিয়ে চলাফেরা করা যাবে।</p>\r\n', NULL, '', '1064', 0, NULL, '', '', 1, 'general', '2020-01-08 06:17:50', '2020-01-08 06:17:50', 0, '', '', '', '', '', '', '', '', '', '', 0),
(51, 'ECO Fire Stop Aluminum Flame Retardant Fuild Portable Fire Extinguisher for home and car,500ml', 'eco-fire-stop-aluminum-flame-retardant-fuild-portable-fire-extinguisher-for-home-and-car500ml', 890, 0, '690', ' ', '<p>অগ্নি নির্বাপক স্প্রে ( Fire Stop Spray)</p>\r\n\r\n<p>✔ আপনার বাসা,অফিস,দোকান,গাড়ি নিরাপদ রাখতে ব্যবহার করুন</p>\r\n\r\n<p>✔ অগ্নি নির্বাপক স্প্রে ,যা মুহূর্তেই আগুন নিভিয়ে দেয়।</p>\r\n\r\n<p>✔ এটি আপনার পরিবারের জীবন নিরাপদ রাখতে সহায়তা করে</p>\r\n', NULL, '', '1065', 0, NULL, '', '', 1, 'home', '2020-01-08 06:20:01', '2020-01-08 06:20:01', 0, '', '', '', '', '', '', '', '', '', '', 0),
(52, 'Dual SIM supported GSM landphone wireless Phone  Desktop cordless phone', 'dual-sim-supported-gsm-landphone-wireless-phone--desktop-cordless-phone', 2900, 0, '2550', ' ', '<p>Dual SIM Supported GSM Landphone</p>\r\n\r\n<p>✔ রিচার্জেবেল তাই যে কোনো জায়গায় সহজেই নিয়ে যেতে পারবেন</p>\r\n\r\n<p>✔ অফিস এর ফ্রন্টডেস্কে- যারা টিঅ্যান্ডটি ফোনের ঝামেলা পোহাতে চাননা তাদের জন্য এই ফোন</p>\r\n\r\n<p>✔ বাড়িতে একটি কমন (সকলের জন্য) ফোন হিসাবে ব্যবহার করা যায়</p>\r\n\r\n<p>✔ Customer Care বা Service Center-এ ব্যবহার উপযোগী</p>\r\n\r\n<p>✔ Flexi load বা Bkash করার জন্য ব্যবহার করা যায়</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1066', 0, NULL, '', '', 1, 'general', '2020-01-08 06:23:16', '2020-01-08 06:23:16', 0, '', '', '', '', '', '', '', '', '', '', 0),
(53, 'Double Air Bed Air Mattress Camping Mat Inflatable Mattress Camping Bed Beach mat With Electric Pump', 'double-air-bed-air-mattress-camping-mat-inflatable-mattress-camping-bed-beach-mat-with-electric-pump', 3590, 0, '3250', ' ', '<p>Double Air Bed with pumper (এয়ার বেড উইথ পাম্পার)</p>\r\n\r\n<p>✔ ভ্রমনে বা অ্যাডভ্যাঞ্চার এ যাচ্ছেন, সাথে নিয়ে যেতে হবে আপনার বিছানা-তোষক !</p>\r\n\r\n<p>✔ যেটি আপনি আপনার ব্যাগের ভিতর করে নিয়ে যেতে পারবেন দূর থেকে দুরান্তর ।</p>\r\n\r\n<p>✔ যেখানে খুশি সেখানে আপনি বানিয়ে নিতে পারবেন ✔ আরামের একটি অস্থায়ী বিছানা ।</p>\r\n\r\n<p>✔ ব্রান্ড : JILONG</p>\r\n\r\n<p>✔ ফ্রি এয়ার পাম্পার</p>\r\n\r\n<p>✔ ম্যাটারিয়াল : PVC,Suede</p>\r\n\r\n<p>✔ ওজন : 1.5 কেজি</p>\r\n\r\n<p>✔ সাইজ : 75&Prime; x 30&Prime; x 9&Prime;</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1068', 0, NULL, '', '', 1, 'general', '2020-01-08 06:38:03', '2020-01-08 06:38:03', 0, '', '', '', '', '', '', '', '', '', '', 0),
(54, 'Tolsen Rechargeable Drill Machine / cordless screwdriver', 'tolsen-rechargeable-drill-machine-cordless-screwdriver', 1890, 0, '1690', ' ', '<p>Rechargeable Drill Machine</p>\r\n\r\n<p>✔ সব ধরনের নাট ও বোল্ট খুলতে এবং লাগাতে পারবেন</p>\r\n\r\n<p>✔ সব ধরণের কাঠ এর মধ্যে ড্রিল করতে পারবেন</p>\r\n\r\n<p>✔ অত্যাধুনিক প্লাম্বিং , কার্পেন্ট্রি, মেকানিক্যাল ও গার্ডেনিং -এর জন্য আদর্শ</p>\r\n\r\n<p>✔ এটি আপনার গৃহ এবং গৃহের বাইরের যাবতীয় কাজকে আরও সহজ করে তুলবে</p>\r\n\r\n<p>✔ একবার চার্জ করলে অনেক সময় ব্যবহার করতে পারবেন।</p>\r\n', NULL, '', '1069', 0, NULL, '', '', 1, 'general', '2020-01-08 06:40:49', '2020-01-08 06:40:49', 0, '', '', '', '', '', '', '', '', '', '', 0),
(55, 'Professional Bluetooth Wireless Microphone Karaoke Speaker, Music Player Singing Recorder Handheld Microphone', 'professional-bluetooth-wireless-microphone-karaoke-speaker-music-player-singing-recorder-handheld-microphone', 1990, 0, '1690', ' ', '<p>Karaoke:( নিজে নিজে গান করুন মিউজিকের সাথে)</p>\r\n\r\n<p>✔ মিউজিক ভলিউম পরিবর্তন,</p>\r\n\r\n<p>✔ মাইক্রোফোন ভলিউম পরিবর্তন ও ইকো/রিভারব পরিবর্তনের সুবিধা,</p>\r\n\r\n<p>✔ গান রেকর্ড ও প্লে-ব্যাক সুবিধা</p>\r\n\r\n<p>✔ একটি ব্লু টুথ স্পিকার ,</p>\r\n\r\n<p>✔ মাইক্রোফোন,</p>\r\n\r\n<p>✔ একটি USB ক্যাবল,</p>\r\n\r\n<p>✔ ইউজার ম্যানুয়াল,</p>\r\n\r\n<p>✔ মাইক্রো USB টু অডিও ক্যাবল।</p>\r\n', NULL, '', '1070', 0, NULL, '', '', 1, 'general', '2020-01-08 06:47:10', '2020-01-08 06:47:10', 0, '', '', '', '', '', '', '', '', '', '', 0),
(56, 'U-shaped Neck Massage Pillow, electric Battery Operated Vibrating Ergonomic Neck & Head Rest Massager Health Care Tools', 'u-shaped-neck-massage-pillow-electric-battery-operated-vibrating-ergonomic-neck--head-rest-massager-health-care-tools', 990, 0, '890', ' ', '<p>নেক ম্যাসাজ পিলো</p>\r\n\r\n<p>✔ এই পিলোটি ভাইব্রেশনের মাধ্যমে আপনার ঘাড় ও মাথার রক্ত সঞ্চালন বৃদ্ধি করে</p>\r\n\r\n<p>✔ পাশাপাশি মাংশ পেশীকে রাখে সতেজ</p>\r\n\r\n<p>✔ অফিসে বা ভ্রমণে আপনাকে রাখবে রিলাক্স</p>\r\n\r\n<p>✔ অন/ অফ বাটন রয়েছে</p>\r\n', NULL, '', '1072', 0, NULL, '', '', 1, 'general', '2020-01-08 06:48:22', '2020-01-08 06:48:22', 0, '', '', '', '', '', '', '', '', '', '', 0),
(57, 'Electronics Mosquito Killer Lamp LED Electric Bug Zapper Lamp Anti Mosquito Repeller Electronic Mosquito Trap Killer', 'electronics-mosquito-killer-lamp-led-electric-bug-zapper-lamp-anti-mosquito-repeller-electronic-mosquito-trap-killer', 890, 0, '700', ' ', '<p>✔ মশা-মাছি, কীট-পতঙ্গ মারা যায় (১০০% নিশ্চয়তা) ,</p>\r\n\r\n<p>✔ কোনো রাসায়নিক, ধোঁয়া বা গন্ধ নেই; তাই মানব শরীরের জন্য ক্ষতিকর নয়,</p>\r\n\r\n<p>✔ একটি শক্তিশালী আলোর সাহায্যে পতঙ্গকে আকৃষ্ট করে এবং ইলেক্ট্রিক ওয়েভ দিয়ে ধ্বংস করে দেয়।</p>\r\n', NULL, '', '1073', 0, NULL, '', '', 1, 'general', '2020-01-08 06:50:06', '2020-01-08 06:50:06', 0, '', '', '', '', '', '', '', '', '', '', 0),
(58, 'Cordless Motion Sensor Light Wireless Infrared Motion Activated Sensor Light 360 Degree Rotation Motion Wall Lamp Outdoor Lights', 'cordless-motion-sensor-light-wireless-infrared-motion-activated-sensor-light-360-degree-rotation-motion-wall-lamp-outdoor-lights', 790, 0, '700', ' ', '<p>✔ সিড়ি বা ঘর যেখানে এটি সংযুক্ত করবেন সেখানে কেউ প্রবেশ করার সাথে সাথে এটি অটোমেটিক ভাবে লাইট জ্বলে উঠবে, যতক্ষণ সেখানে কেউ অবস্থান করবে ততক্ষন জ্বলে থাকবে, চলে যাওয়ার পর অটোমেটিক ভাবে বন্ধ হয়ে যাবে,</p>\r\n\r\n<p>✔ লইটটি অন্ধকারের মধ্যে বেশী কার্যকরী,</p>\r\n\r\n<p>✔ ৪টা ব্যাটারীর সাহায্যে চলে ( ব্যাটারী সাথে দেয়া নেই ) ।</p>\r\n', NULL, '', '1074', 0, NULL, '', '', 1, 'general', '2020-01-08 06:52:20', '2020-01-08 06:52:20', 0, '', '', '', '', '', '', '', '', '', '', 0),
(59, 'Nima Electric Spice Grinder', 'nima-electric-spice-grinder', 990, 0, '690', ' ', '<p>মসলা গুড়া করার মেশিন</p>\r\n\r\n<p>✔ যে কোন শুকনা মশলা বা চাল সহজেই গুড়া করার জন্য,কালোজিরা, শুকনামরিচ, জিরা, মেথি, সরিষা, গোলমরিচ, এলাচি, দারুচিনি সহ যে কোন ধরনের ডাল যে কোন ধরনের বাদাম ইত্যাদি গুড়া বা পাউডার করা যাবে।</p>\r\n\r\n<p>✔ পাওয়ার ফুল মোটরঃ 150W</p>\r\n\r\n<p>✔ ক্যাপাসিটি 50-100g</p>\r\n\r\n<p>✔ একটি শক্তিশালী 150W মোটর যা খুব অল্প সময়ের মধ্যে মশলাকে গুড়ো করতে সক্ষম</p>\r\n\r\n<p>✔ সহজেই বোতামটি পরিচালনা করা যায়</p>\r\n\r\n<p>✔ কভারটি স্বচ্ছ প্লাস্টিকের তৈরি</p>\r\n\r\n<p>✔ বাটি এবং ব্লেড স্টেইনলেস স্টীলের তৈরী যা একটি দীর্ঘদিন ব্যবহারের উপযোগী</p>\r\n', NULL, '', '1075', 0, NULL, '', '', 1, 'general', '2020-01-08 06:53:44', '2020-01-08 06:53:44', 0, '', '', '', '', '', '', '', '', '', '', 0),
(60, '24 LED IR Color CMOS Loop Recording CCTV Security Camera TV Out Remote Control', '24-led-ir-color-cmos-loop-recording-cctv-security-camera-tv-out-remote-control', 2490, 0, '2290', ' ', '<p>TV Out CCTV Camera ( CCTV এক ক্যামেরার সেটআপ)</p>\r\n\r\n<p>✔ এই ক্যামেরা সেটআপে কোন DVR বা অন্য কিছুই লাগবেনা, শুধু Charging Plug লাগান আর চালু হয়ে যাবে।</p>\r\n\r\n<p>✔ TV Jack লাগিয়ে (Not included with Package) আপনি সরাসরি টিভি-তে ভিডিও দেখতে পারবেন।</p>\r\n\r\n<p>✔ 32GB পর্যন্ত মেমোরি কার্ড Insert করে আপনি ২০ দিন পর্যন্ত ভিডিও রেকর্ড করতে পারবেন।</p>\r\n\r\n<p>✔ ক্যামেরা রেজুলেশন : 1.3 Mega Pixel - 720P</p>\r\n\r\n<p>✔ অটো নাইটভিসন,শক্তিশালী লেন্স।</p>\r\n\r\n<p>✔ ওয়াল, ছাঁদ বা টেবিল যে কোন জায়গায় সেট করা যাবে।</p>\r\n\r\n<p>✔ HD কুয়ালিটি ভিডিও আউট পুট।</p>\r\n\r\n<p>✔ Power Supply : 5 volt</p>\r\n\r\n<p>✔ 1 year Service warranty</p>\r\n', NULL, '', '1076', 0, NULL, '', '', 1, 'general', '2020-01-08 06:55:20', '2020-01-08 06:55:20', 0, '', '', '', '', '', '', '', '', '', '', 0),
(61, 'Portable Mini Refillable Perfume Bottle With Spray Scent Pump / Empty Cosmetic Containers Spray Atomizer Bottle For Travel 5ml', 'portable-mini-refillable-perfume-bottle-with-spray-scent-pump--empty-cosmetic-containers-spray-atomizer-bottle-for-travel-5ml', 390, 0, '250', ' ', '<p>Travel Perfume Bottle ( মিনি রিফিল পারফিঊম বোতল)</p>\r\n\r\n<p>✔ বড় পারফিউম বোতল বহনের ঝামেলা এড়াতে ব্যাবহার করুন, মিনি পারফিউম রিফিল বোতল।</p>\r\n\r\n<p>✔ সব পরিবেশে নিজেকে রাখুন রি-ফ্রেশ।</p>\r\n', NULL, '', '1077', 0, NULL, '', '', 1, 'home', '2020-01-08 07:05:44', '2020-01-08 07:05:44', 0, '', '', '', '', '', '', '', '', '', '', 0),
(62, 'Credit card holder', 'credit-card-holder', 390, 0, '250', ' ', '<h2><strong>Credit card holder ( ক্রেডিট কার্ড হোল্ডার )</strong></h2>\r\n\r\n<p>✔ ক্রেডিট কার্ড, ভিজিটিং কার্ড, চাবি ও নগদ অর্থ নিরাপদ রাখে</p>\r\n\r\n<p>✔ স্লিম ও হ্যান্ডি ডিজাইন</p>\r\n\r\n<p>✔ সাইজঃ ১১০ x ৭৫ x ২০ মিমি</p>\r\n\r\n<p>✔ ওজনঃ ৬২ গ্রাম</p>\r\n', NULL, '', '1078', 0, NULL, '', '', 1, 'home', '2020-01-08 07:07:08', '2020-01-08 07:07:08', 0, '', '', '', '', '', '', '', '', '', '', 0),
(63, 'Baby Bouncer - Newborn Baby Rocking Chair Multi-range Adjustment 0-2 yeaars Old', 'baby-bouncer---newborn-baby-rocking-chair-multi-range-adjustment-0-2-yeaars-old', 2250, 0, '1690', '  ', '<p>✔ বয়স: নিউবর্ন থেকে শুরু করে প্রায় ২ বছর পর্যন্ত প্রায় সব বাচ্চাদের জন্য</p>\r\n\r\n<p>✔ সাধারণত এই বয়সের বাচ্চাদের পরে যাওয়ার ভয় থাকে এই বেবি বাঊন্সারে নিশ্চিন্তে বসিয়ে কাজ করতে পারেবেন।</p>\r\n\r\n<p>✔ ওয়েট ক্যাপাসিটিঃ 8-29 lbs/3.5 &ndash; 13kg</p>\r\n\r\n<p>✔ ম্যাটেরিয়াল: কটন 60% এবং 40% পলিয়েস্টার</p>\r\n\r\n<p>✔ সহজেই খুলে রাখা যায় এবং মেশিন ওয়াসের জন্য উপযোগী</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1079', 0, NULL, '', '', 1, 'home', '2020-01-09 09:07:06', '2020-01-09 09:07:06', 0, '', '', '', '', '', '', '', '', '', '', 0),
(64, '3 IN 1 Round Mandoline Slicer Vegetable Cutter Cheese Grater Nut Chopper Grinder Salad Shooter Vegetable Slicer with a Stainless Steel peeler', '3-in-1-round-mandoline-slicer-vegetable-cutter-cheese-grater-nut-chopper-grinder-salad-shooter-vegetable-slicer-with-a-stainless-steel-peeler', 1190, 0, '990', ' ', '<p>✔ সকল ধরনের সবজী কুচি করতে পারবেন বিভিন্ন শেপে</p>\r\n\r\n<p>✔ নিজের ইচ্ছা মত কুচি সালাদ করতে পারবেন</p>\r\n\r\n<p>✔ বিস্কুট কুচি, মাংস কিমা করতে পারবেন</p>\r\n', NULL, '', '1080', 0, NULL, '', '', 1, 'home', '2020-01-08 07:11:10', '2020-01-08 07:11:10', 0, '', '', '', '', '', '', '', '', '', '', 0),
(65, 'Panasonic Boom Microphone Unidirectional Microphone EM-2800A Microphone for Youtubing', 'panasonic-boom-microphone-unidirectional-microphone-em-2800a-microphone-for-youtubing', 1890, 0, '1390', ' ', '<h2><strong>Panasonic Boom Microphone</strong></h2>\r\n\r\n<p>✔ Unidirectional microphone</p>\r\n\r\n<p>✔ Electret condenser cardioid super,</p>\r\n\r\n<p>✔ Equipped with standard XLR connector, the integrated switcher can choose tele or normal function,</p>\r\n\r\n<p>✔ Sensitivity 66dB short distance, long-distance 50dB</p>\r\n\r\n<p>✔ Frequency response 80-13Khz, 120dB maximum</p>\r\n\r\n<p>✔ battery: 1.5 V (AA) or AA battery</p>\r\n\r\n<p>✔ Dimensions 360mm long x 21mm diameter,</p>\r\n\r\n<p>✔ Weight 175 grams.</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1082', 0, NULL, '', '', 1, 'home', '2020-01-08 07:16:33', '2020-01-08 07:16:33', 0, '', '', '', '', '', '', '', '', '', '', 0),
(66, 'Clip Microphone BOYA BY-M1 Directional Lavalier Microphone for iPhone Android Mac Vlog Mic for DSLR Camera Camcorder Recorder Boya M1', 'clip-microphone-boya-by-m1-directional-lavalier-microphone-for-iphone-android-mac-vlog-mic-for-dslr-camera-camcorder-recorder-boya-m1', 1790, 0, '990', ' ', '<h2><strong>Original Boya BY-M1 Microphone</strong></h2>\r\n\r\n<p>✔ কম্পিউটার, ক্যামেরা, ল্যাপটপ, মোবাইল এ ব্যাবহার করতে পারবেন ।</p>\r\n\r\n<p>✔ ৬ মিটার লম্বা তার</p>\r\n\r\n<p>✔ সুদৃশ্য ব্যাগ থাকায় গুছিয়ে রাখা যায় ।</p>\r\n\r\n<p>✔ যে কোন এম্প্লীফায়ার এ ব্যাবহার করতে পারবেন</p>\r\n', NULL, '', '1083', 0, NULL, '', '', 1, 'home', '2020-01-08 07:18:30', '2020-01-08 07:18:30', 0, '', '', '', '', '', '', '', '', '', '', 0),
(67, 'Electric Knife Sharpener Swifty Sharp Motorized Knife Sharpener Rotating Sharpening Stone Sharpening Tool', 'electric-knife-sharpener-swifty-sharp-motorized-knife-sharpener-rotating-sharpening-stone-sharpening-tool', 490, 0, '450', ' ', '<p>✔ পুরাতন দা,বটি,চাকু নতুনের মত ধার করতে পারবেন ।</p>\r\n\r\n<p>✔ ঘরে বসেই শান করুন আপনার ছুরি-কাচি এবং দা,বটি</p>\r\n\r\n<p>✔ ব্যাটারিতে চলবে</p>\r\n\r\n<p>✔ হাই কোয়ালিটি নাইফ শার্পনার</p>\r\n\r\n<p>✔ ম্যাটারিয়াল: Polypropylene</p>\r\n', NULL, '', '1084', 0, NULL, '', '', 1, 'home', '2020-01-08 07:19:42', '2020-01-08 07:19:42', 0, '', '', '', '', '', '', '', '', '', '', 0),
(68, 'Mini Portable Car Fire Extinguisher with Hook Dry Chemical Fire Extinguisher Safety Flame Fighter for Home Office Car Fire Stop', 'mini-portable-car-fire-extinguisher-with-hook-dry-chemical-fire-extinguisher-safety-flame-fighter-for-home-office-car-fire-stop', 1490, 0, '990', ' ', '<p>✔ আপনার বাসা,অফিস,দোকান,গাড়ি নিরাপদ রাখতে ব্যবহার করুন</p>\r\n\r\n<p>✔ অগ্নি নির্বাপক স্প্রে ,যা মুহূর্তেই আগুন নিভিয়ে দেয়।</p>\r\n\r\n<p>✔ এটি আপনার পরিবারের জীবন নিরাপদ রাখতে সহায়তা করে</p>\r\n', NULL, '', '1088', 0, NULL, '', '', 1, 'home', '2020-01-08 07:21:11', '2020-01-08 07:21:11', 0, '', '', '', '', '', '', '', '', '', '', 0),
(69, 'Rechargeable Electric portable Juicer portable Smoothie Maker - Blender Machine', 'rechargeable-electric-portable-juicer-portable-smoothie-maker---blender-machine', 990, 0, '850', ' ', '<p>✔ স্মল সাইজ</p>\r\n\r\n<p>✔ পোর্টেবল</p>\r\n\r\n<p>✔ মাল্টি-ইউজ - কাপ/ জুসার ব্লেন্ডার</p>\r\n\r\n<p>✔ বিভিন্ন ফল ও সব্জী মিক্স করতে পারে</p>\r\n\r\n<p>✔ স্বাস্থ্য সম্মত ও পরিবেশবান্ধব</p>\r\n\r\n<p>✔ নন-টক্সিক ফুড গ্রেড PP/PC ম্যাটেরিয়াল</p>\r\n\r\n<p>✔ ডাবল সেফটি প্রোটেকশন সুইচ</p>\r\n\r\n<p>✔ চার্জ/ ডিসচার্জ প্রোটেকশন</p>\r\n\r\n<p>✔ কুইক স্পিড, ১ মিনিটেই তৈরি হয়ে যায় জুস</p>\r\n\r\n<p>✔ ফুল চার্জে ১০-১২ বার ব্যবহার করা যায়</p>\r\n', NULL, '', '1092', 0, NULL, '', '', 1, 'hotsell', '2020-01-08 07:23:11', '2020-01-08 07:23:11', 0, '', '', '', '', '', '', '', '', '', '', 0),
(70, 'Rechareable Callous Remover / Electric Foot Care Tool Grinding Pedicure Kit', 'rechareable-callous-remover-electric-foot-care-tool-grinding-pedicure-kit', 890, 0, '800', ' ', '<h2><strong>পায়ের গোড়ালি পরিষ্কার করার যন্ত্র</strong></h2>\r\n\r\n<p>✔ ওয়াশার দিয়ে পায়ের গোড়ালি পরিস্কার করতে পারবেন</p>\r\n\r\n<p>✔ পা ফাটা বন্ধ করে, ব্যথা কমে যাবে,</p>\r\n\r\n<p>✔ আপনার পায়ের যত্নে ব্যবহার করুন</p>\r\n\r\n<p>✔ Pedi Spin ইলেক্ট্রনিক পেডিকিউর কিট</p>\r\n\r\n<p>✔ ৪ টি AA ব্যাটারি চালিত (সংযুক্ত নয়)</p>\r\n', NULL, '', '1093', 0, NULL, '', '', 1, 'home', '2020-01-08 07:25:08', '2020-01-08 07:25:08', 0, '', '', '', '', '', '', '', '', '', '', 0),
(71, 'Stainless Steel Easy to use Pineapple Corer Slicer Cutter Peeler Kitchen Tools', 'stainless-steel-easy-to-use-pineapple-corer-slicer-cutter-peeler-kitchen-tools', 590, 0, '490', ' ', '<p>✔ আনারস কাটার সবচেয়ে সহজ একটি যন্ত্র</p>\r\n\r\n<p>✔ চামড়া খসানোর পাশাপাশি স্লাইস হয়ে যাবে</p>\r\n\r\n<p>✔ যন্ত্রটি ব্যবহার করা এবং পরিষ্কার করা অত্যন্ত সহজ</p>\r\n\r\n<p>✔ কোন রকম পূর্ব অভিজ্ঞতা ছাড়াই ব্যবহার করা যাবে।</p>\r\n', NULL, '', '1097', 0, NULL, '', '', 1, 'hotsell', '2020-01-08 07:26:31', '2020-01-08 07:26:31', 0, '', '', '', '', '', '', '', '', '', '', 0),
(72, 'Havoc SILVER Deodorant Spray - For Men & Women  (200 ml)', 'havoc-silver-deodorant-spray---for-men--women--200-ml', 390, 0, '250', ' ', '<p>✔ বিশ্বে বহুল ব্যবহৃত এই বডি স্প্রে</p>\r\n\r\n<p>✔ অত্যন্ত সুমিষ্ট ঘ্রান</p>\r\n\r\n<p>✔ অনেকক্ষন ধরে বজায় থাকে ঘ্রানটি</p>\r\n', NULL, '', '1098', 0, NULL, '', '', 1, 'hotsell', '2020-01-08 07:28:00', '2020-01-08 07:28:00', 0, '', '', '', '', '', '', '', '', '', '', 0),
(73, 'Brut Original Deodorant Spray for Men - 200ml', 'brut-original-deodorant-spray-for-men---200ml', 390, 0, '250', ' ', '<p>✔ বিশ্বে বহুল ব্যবহৃত এই বডি স্প্রে</p>\r\n\r\n<p>✔ অত্যন্ত সুমিষ্ট ঘ্রান</p>\r\n\r\n<p>✔ অনেকক্ষন ধরে বজায় থাকে ঘ্রানটি</p>\r\n', NULL, '', '1099', 0, NULL, '', '', 1, 'home', '2020-01-08 07:28:59', '2020-01-08 07:28:59', 0, '', '', '', '', '', '', '', '', '', '', 0),
(74, 'Brut Perfume Green Eau de Toilette - 100 ml  (For Men & Women)', 'brut-perfume-green-eau-de-toilette---100-ml--for-men--women', 1090, 0, '890', ' ', '<p>✔ বিশ্বে বহুল ব্যবহৃত একটি পারফিউম</p>\r\n\r\n<p>✔ অত্যন্ত সুমিষ্ট ঘ্রান</p>\r\n\r\n<p>✔ অনেকক্ষন ধরে বজায় থাকে ঘ্রানটি</p>\r\n\r\n<p>✔ ১০০ এম.এল।</p>\r\n', NULL, '', '1100', 0, NULL, '', '', 1, 'hotsell', '2020-01-08 07:30:40', '2020-01-08 07:30:40', 0, '', '', '', '', '', '', '', '', '', '', 0),
(75, 'Wardrobe Cloth Storage Organizer, Portable Folding Fabric Wardrobe', 'wardrobe-cloth-storage-organizer-portable-folding-fabric-wardrobe', 2290, 0, '1990', ' ', '<p>Folding Wardrobe for Cloth Storage</p>\r\n\r\n<p>✔ বাইরে কাভারটা কাপড়ের ও বডি মেটাল।</p>\r\n\r\n<p>✔ এটা খুলে বক্স বা ব্যাগে করে যে কোন জায়গায় নিয়ে যেতে পারবেন খুব সহজে।</p>\r\n\r\n<p>✔ আপনার বাসা এবং অফিসের জন্য খুবই সুন্দর একটা আলমিরা।</p>\r\n\r\n<p>✔ আপনার প্রতিদিনের কাপড় জুতা রাখতে পারবেন সহজেই।</p>\r\n\r\n<p>✔ ব্যাচেলরদের জন্য খুবই দরকারি একটি আলমিরা কারন এটা ফোল্ড করে রাখা যায়।</p>\r\n\r\n<p>✔ স্টিল পাইপের থিকনেস: 13.5x0.22 মিমি</p>\r\n\r\n<p>✔ ইনার বক্স: 66 x 33 x 7 সেমি.</p>\r\n\r\n<p>✔ সাইজ: 84 X 45 X 160 সেমি.</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1109', 0, NULL, '', '', 1, 'home', '2020-01-08 07:33:17', '2020-01-08 07:33:17', 0, '', '', '', '', '', '', '', '', '', '', 0),
(76, 'High Quality Microwave Oven Storage Racks / Stainless Steel Adjustable Multi functional Microwave Oven Shelf Rack', 'high-quality-microwave-oven-storage-racks--stainless-steel-adjustable-multi-functional-microwave-oven-shelf-rack', 1990, 0, '1390', ' ', '<p>✔ ২ তাকের সেল্ফ ।</p>\r\n\r\n<p>✔ প্লাস্টিক এবং স্টেইনলেস স্টিল দ্বারা তৈরী ।</p>\r\n\r\n<p>✔ প্রয়োজন অনুযায়ী তাকের সাইজ ছোট বড় করতে পারবেন ।</p>\r\n\r\n<p>✔ আপনার ঘরকে গুছিয়ে রাখবে ।</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1110', 0, NULL, '', '', 1, 'hotsell', '2020-01-08 07:35:21', '2020-01-08 07:35:21', 0, '', '', '', '', '', '', '', '', '', '', 0),
(77, 'Multi Functional Mobile Folding Racks Cloth Drying Rack', 'multi-functional-mobile-folding-racks-cloth-drying-rack', 1990, 0, '1450', ' ', '<p>✔ কাপড় শুকাতে দেয়ার জন্য আদর্শ একটি ডিভাইস</p>\r\n\r\n<p>✔ প্রয়োজন শেষে ভাজ করে রেখে দেয়া যায়</p>\r\n\r\n<p>✔ স্ট্যান্ড ম্যাটেরিয়াল: প্লাস্টিক এবং স্টেইনলেস স্টিল</p>\r\n\r\n<p>✔ আধুনিকতার সাথে মানানসই</p>\r\n\r\n<p>✔ প্যাকেজ ডাইমেনশন: 18x5.5x16cm (LxWxH)</p>\r\n\r\n<p>✔ স্টাইলিশ ডিজাইন</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1111', 0, NULL, '', '', 1, 'hotsell', '2020-01-08 07:36:56', '2020-01-08 07:36:56', 0, '', '', '', '', '', '', '', '', '', '', 0),
(78, 'Egg Master Automatic Egg Roll Maker, New Electric Egg Boiler, Egg Omelette Master Sausage Machine Bottle-Shaped For Breakfast', 'egg-master-automatic-egg-roll-maker-new-electric-egg-boiler-egg-omelette-master-sausage-machine-bottle-shaped-for-breakfast', 1990, 0, '1390', ' ঝটপট ঝামেলাহীন ডিমের রোল তৈরি করুন মাত্র ১-২ মিনিটে', '<p>ঝটপট ঝামেলাহীন ডিমের রোল তৈরি করুন মাত্র ১-২ মিনিটে</p>\r\n', NULL, '', '1112', 0, NULL, '', '', 1, 'home', '2020-01-08 07:38:39', '2020-01-08 07:38:39', 0, '', '', '', '', '', '', '', '', '', '', 0),
(79, 'Wardrobe Cloth Storage Organizer (Large Size) - Portable Folding Fabric Wardrobe', 'wardrobe-cloth-storage-organizer-large-size-portable-folding-fabric-wardrobe', 2490, 0, '2290', ' ', '<p>✔ Material : Cloth and Steel PP pipe</p>\r\n\r\n<p>✔ বাইরের কাভারটা কাপড়ের ও বডি মেটাল</p>\r\n\r\n<p>✔এটা খুলে বক্স বা ব্যাগে করে যে যে কোনো জায়গায় নিয়ে যেতে পারবেন খুব সহজেই</p>\r\n\r\n<p>✔ প্রতি তাকে 8 কেজি করে রাখাতে পারবেন</p>\r\n\r\n<p>✔ ৫০-৬০ কেজি ওজন দিতে পারবেন সম্পূর্ণ</p>\r\n\r\n<p>✔ আলমিরাতে ও ১০-১৫ টি শার্ট ঝুলিয়ে রাখতে পারবেন।</p>\r\n\r\n<p>✔ আপনার বাসা বা অফিসের জন্য খুবই সুন্দর ও আনকমন একটি আলমিরা।</p>\r\n\r\n<p>✔ আপানার প্রতিদিনের ব্যাবহারের কাপড় - বই - জুতা বা যে কোনো জিনিস রাখতে পারবেন।</p>\r\n\r\n<p>✔ যারা ব্যাচেলর তাদের জন্য এটা খুবই দরকারি।</p>\r\n\r\n<p>✔ সাইজঃ লাম্বাঃ 5.4 ফুট +চওড়া 5.5 ফুট</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1113', 0, NULL, '', '', 1, 'hotsell', '2020-01-08 07:40:14', '2020-01-08 07:40:14', 0, '', '', '', '', '', '', '', '', '', '', 0),
(80, 'Air Dragon Portable Air Compressor Pumper', 'air-dragon-portable-air-compressor-pumper', 2490, 0, '2390', ' ', '<p>✔ গাড়ি, মোটর সাইকেল, বাই সাইকেল, বল, এয়ার বেড, পাম্প করতে পারবেন ।</p>\r\n\r\n<p>✔ ১২v গাড়ির আওটলেট এ ব্যবহার করতে পারবেন</p>\r\n\r\n<p>✔ মিটার থাকায় সঠিক পরিমাপে হাওয়া দিতে পারবেন</p>\r\n', NULL, '', '1114', 0, NULL, '', '', 1, 'home', '2020-01-08 07:41:13', '2020-01-08 07:41:13', 0, '', '', '', '', '', '', '', '', '', '', 0),
(81, 'Mini Bluetooth Earphone Wireless Sports Headset Earpiece Headphone with Mic Handsfree For iPhone Samsung Xiaomi Huawei etc', 'mini-bluetooth-earphone-wireless-sports-headset-earpiece-headphone-with-mic-handsfree-for-iphone-samsung-xiaomi-huawei-etc', 390, 0, '250', ' ', '<p>✔ V4.1 +EDR</p>\r\n\r\n<p>✔ Smart voice prompt</p>\r\n\r\n<p>✔ রেন্জ: ১০ মিটার</p>\r\n\r\n<p>✔ ৪ ঘন্টা মিউজিক এবং ৩ ঘন্টা স্ট্যান্ডবাই টাইম ।</p>\r\n', NULL, '', '1115', 0, NULL, '', '', 1, 'home', '2020-01-08 07:42:34', '2020-01-08 07:42:34', 0, '', '', '', '', '', '', '', '', '', '', 0),
(82, 'Philips BT1210/15 Cordless Trimmer for Men, USB Charging Trimmer Rechargeable Beard Trimmer', 'philips-bt121015-cordless-trimmer-for-men-usb-charging-trimmer-rechargeable-beard-trimmer', 2160, 0, '1490', ' ', '<p>✔ Dura Power technology (4x longer battery life)<br />\r\n✔ USB charging, 8 hours full charge<br />\r\n✔ Stainless Steel Blades for long-lasting sharpness<br />\r\n✔ 30 minutes run time cordless use<br />\r\n✔ 1 beard comb (5mm) and 1 stubble comb (1mm)<br />\r\n✔ Automatic voltage: 100-240 V</p>\r\n', NULL, '', '1116', 0, NULL, '', '', 1, 'hotsell', '2020-01-08 08:23:07', '2020-01-08 08:23:07', 0, '', '', '', '', '', '', '', '', '', '', 0),
(83, 'Original Magic Bullet - Hi-Speed Blender/Mixer System 21 Pcs Set', 'original-magic-bullet-hi-speed-blender-mixer-system-21-pcs-set', 3290, 0, '2490', ' ', '<p>✔ ম্যাজিক বুলেট ব্লেন্ডার</p>\r\n\r\n<p>✔ এটি একটি কফি মগের মতোই স্লিম!</p>\r\n\r\n<p>✔ এই ব্লেন্ডার আপনার ফুড প্রসেসর, ব্লেন্ডার, ইলেকট্রিক জুসার এবং কফি গ্রাইন্ডার হিসেবে কাজ করবে</p>\r\n\r\n<p>✔ সহজেই ব্যবহার করা যায়</p>\r\n\r\n<p>✔ ম্যাজিক বুলেট ব্লেন্ডারে ভিন্ন কোন পাওয়ার বাটন নেই। শুধুমাত্র উপকরণগুলো ব্লেন্ডারে দিন আর</p>\r\n\r\n<p>ব্লেন্ডারটিকে পাওয়ার বেজের ওপর রেখে নীচে চাপ দিন কয়েক সেকেন্ডের মধ্যেই আপনি পেয়ে যাবেন spaghetti সস, অনিয়ন চপ, সালসা, রসুন জুস, পনির, স্যুপ, চিকেন সালাদ ম্যাজিক বুলেট অবিশ্বাস্য দ্রুতগতিতে কাজ করে</p>\r\n\r\n<p>✔ ৩ সেকেন্ডে তৈরি হয় রসুন বাটা! ৫ সেকেন্ডে তৈরি হয় সালসা, চিকেন সালাদ!</p>\r\n\r\n<p>✔ বক্সে আছে ২১ পিস ম্যাজিক বুলেট ব্লেন্ডার সেট</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1117', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 11:46:19', '2020-01-09 11:46:19', 0, '', '', '', '', '', '', '', '', '', '', 0),
(84, 'Android TV Box, X96 Mini Smart TV Box / 4K HD Smart Media Player', 'android-tv-box-x96-mini-smart-tv-box-4k-hd-smart-media-player', 3800, 0, '3450', ' ', '<p>✔ আপনার নরমাল টিভিটিতে এই ডিভাইসটি কানেক্ট করে বানিয়ে নিতে পারেন স্মার্ট টিভি</p>\r\n\r\n<p>✔ ওয়াইফাই কানেক্ট করে ব্রাউজিং ও অনলাইন টিভি চ্যানেলগুলো উপভোগ করেতে পারবেন</p>\r\n\r\n<p>✔ Processor: Amlogic S905X Quad Core Cortex ✔ A-53, 64 Bit, 2GHz Processing Speed</p>\r\n\r\n<p>✔ RAM: 2 GB DDR3 RAM</p>\r\n\r\n<p>✔ Storage : 16 GB ROM</p>\r\n\r\n<p>✔ Graphics: Mali 450 Penta Core GPU 750 MHz, H.265 ,VP9 HDR 10, Supports Upto 4K Resolution</p>\r\n\r\n<p>✔ Card Slot: Micro SD Card Slot</p>\r\n\r\n<p>✔ Connectivity: USB x2, HDMI Out, AV Out, Mirco SD Card Slot, External IR, Optical, WiFi, Miracast, LAN</p>\r\n\r\n<p>✔ OS: Android</p>\r\n', NULL, '', '1118', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 11:47:44', '2020-01-09 11:47:44', 0, '', '', '', '', '', '', '', '', '', '', 0),
(85, 'Hot Glue Gun, High Temperature Glue Gun for DIY Crafts, Projects, Fast Home Repairs & Creative Arts', 'hot-glue-gun-high-temperature-glue-gun-for-diy-crafts-projects-fast-home-repairs--creative-arts', 390, 0, '300', ' ', '<p>✔ ম্যাটেরিয়ালঃ প্লাস্টিক</p>\r\n\r\n<p>✔ ইলেকট্রিক গ্লু গান ডাইমেনশনঃ 7.60 in x 1.10 in x 6.46 in (19.3 cm x 2.8 cm x 16.4 cm)</p>\r\n\r\n<p>✔ ওজনঃ 7.84 oz (222 g)</p>\r\n\r\n<p>✔ পাওয়ার: ৪০ ওয়াট</p>\r\n\r\n<p>✔ ম্যাটেরিয়ালঃ প্লাস্টিক</p>\r\n\r\n<p>✔ কাঠ বা প্লাস্টিকের সরঞ্জাম তৈরী, সার্কিট বোর্ড নির্দিষ্ট স্থানে শক্তভাবে লাগানো, আর্টিফিসিয়াল ফ্লাওয়ার, ক্রাফট প্রজেক্টস, ফার্নিচার ও কাঠের কাজের জন্য দরকারি টুলস</p>\r\n', NULL, '', '1119', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 11:51:18', '2020-01-09 11:51:18', 0, '', '', '', '', '', '', '', '', '', '', 0),
(86, '4 Grids Remote Control Holder Stand Organizer 4 grids Remote Control Storage Racks', '4-grids-remote-control-holder-stand-organizer-4-grids-remote-control-storage-racks', 390, 0, '350', ' ', '<p>✔ টিভি ,ফ্রীজ, এয়ার-কন্ডিশন সহ সকল প্রকার রিমোট সাজিয়ে রাখতে পারবেন ।</p>\r\n\r\n<p>✔ মেটাল বডি</p>\r\n\r\n<p>✔ ৪টি রিমোট রাখা যাবে</p>\r\n', NULL, '', '1120', 0, NULL, '', '', 1, 'home', '2020-01-09 11:52:43', '2020-01-09 11:52:43', 0, '', '', '', '', '', '', '', '', '', '', 0),
(87, 'Rasasi Blue Lady Eau de Parfum - 40 ml (For Women)', 'rasasi-blue-lady-eau-de-parfum-40-ml-for-women', 1090, 0, '990', ' ', '<h2><strong>Blue Lady Perfume</strong></h2>\r\n\r\n<p>✔ বিশ্বে বহুল ব্যবহৃত মহিলাদের পারফিউম</p>\r\n\r\n<p>✔ অত্যন্ত সুমিষ্ট ঘ্রান</p>\r\n\r\n<p>✔ অনেকক্ষন ধরে বজায় থাকে ঘ্রানটি</p>\r\n\r\n<p>✔ ৪০ এম.এল</p>\r\n\r\n<p>✔ বোতলের ডিজিইনটিও মনকাড়া</p>\r\n', NULL, '', '1121', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 11:56:09', '2020-01-09 11:56:09', 0, '', '', '', '', '', '', '', '', '', '', 0),
(88, 'Rasasi Blue For Men EDP - Eau De Parfum 100ML ', 'rasasi-blue-for-men-edp-eau-de-parfum-100ml', 1490, 0, '990', ' ', '<h2><strong>Blue for Men Perfume</strong></h2>\r\n\r\n<p>✔ বিশ্বে বহুল ব্যবহৃত পুরুষদের পারফিউম</p>\r\n\r\n<p>✔ অত্যন্ত সুমিষ্ট ঘ্রান</p>\r\n\r\n<p>✔ অনেকক্ষন ধরে বজায় থাকে ঘ্রানটি</p>\r\n\r\n<p>✔ ১০০ এম.এল</p>\r\n\r\n<p>✔ বোতলের ডিজিইনটিও মনকাড়া</p>\r\n', NULL, '', '1122', 0, NULL, '', '', 1, 'home', '2020-01-09 11:58:10', '2020-01-09 11:58:10', 0, '', '', '', '', '', '', '', '', '', '', 0),
(89, 'One Man Show Perfum For Men. Eau De Toilette Spray 100ml', 'one-man-show-perfum-for-men-eau-de-toilette-spray-100ml', 1490, 0, '1190', ' ', '<h2><strong>One Man Show Perfume</strong></h2>\r\n\r\n<p>✔ বিশ্বে বহুল ব্যবহৃত পুরুষদের পারফিউম</p>\r\n\r\n<p>✔ অত্যন্ত সুমিষ্ট ঘ্রান</p>\r\n\r\n<p>✔ অনেকক্ষন ধরে বজায় থাকে ঘ্রানটি</p>\r\n\r\n<p>✔ ১০০ এম.এল</p>\r\n\r\n<p>✔ এই ব্রান্ডটি দীর্ঘ্যদিন থেকে মানুষের মনে স্থান করে রেখেছে অত্যন্ত সুনামের সহিত</p>\r\n', NULL, '', '1123', 0, NULL, '', '', 1, 'home', '2020-01-09 11:59:18', '2020-01-09 11:59:18', 0, '', '', '', '', '', '', '', '', '', '', 0),
(90, 'Carry Furnishings Easier  Furniture Carry Tools Useful Lifting Moving Strap Furniture Transport Belt In Shoulder Straps Team Straps Mover Conveying carry furnishing easier', 'carry-furnishings-easier--furniture-carry-tools-useful-lifting-moving-strap-furniture-transport-belt-in-shoulder-straps-team-straps-mover-conveying-carry-furnishing-easier', 490, 0, '450', ' ', '<p>✔ এটি ব্যাবহার করে অতি সহজেই যে কোন ভারি আসবাবপত্র সরাতে বা বহন করতে পারবেন ।</p>\r\n\r\n<p>✔ কটন হওয়ায় ব্যাহার করাও খুব সহজ ।</p>\r\n', NULL, '', '1124', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 12:00:46', '2020-01-09 12:00:46', 0, '', '', '', '', '', '', '', '', '', '', 0),
(91, 'Automatic Self Stirring Coffee Mug Stainless Steel 400ml coffee mug, Home Office Smart Mixer Cup', 'automatic-self-stirring-coffee-mug-stainless-steel-400ml-coffee-mug-home-office-smart-mixer-cup', 590, 0, '490', ' ', '<p>✔ Dimension: 11cm (H) x 8.5cm (D)</p>\r\n\r\n<p>✔ স্টেইনলেস স্টিল দ্বারা তৈরী ।</p>\r\n\r\n<p>✔ Battery : 2 AAA ব্যাটারী দ্বারা চলবে ।</p>\r\n\r\n<p>✔ একটি সুইচ চেপে স্টার্ট করার সুবিধা ।</p>\r\n\r\n<p>✔ সহজেই ব্যবহার করতে পারবেন ।</p>\r\n', NULL, '', '1125', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 12:02:11', '2020-01-09 12:02:11', 0, '', '', '', '', '', '', '', '', '', '', 0),
(92, 'Portable Medicine Box 14/7 Grids 7 Days Medicine Storage Container Weekly Medicine Organizer', 'portable-medicine-box-147-grids-7-days-medicine-storage-container-weekly-medicine-organizer', 590, 0, '490', ' ', '<h2><strong>Medicine Box</strong></h2>\r\n\r\n<p>✔ মেডিসিন বক্সে পুরো ৭ দিনের প্রতি বেলার ঔষধ সাজিয়ে রাখতে পারবেন ।</p>\r\n\r\n<p>✔ প্রতিদিনের আলাদা আলাদা চেম্বার ।</p>\r\n\r\n<p>✔ লক সিষ্টেম ।</p>\r\n\r\n<p>✔ ফুড-গ্রেড এবং দৃষ্টি নন্দন রং এ তৈরী ।</p>\r\n\r\n<p>✔ সপ্তাহ জুড়ে নির্ভুল ভাবে ঔষধ খেয়ে সুস্থ্য থাকুন</p>\r\n', NULL, '', '1126', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 12:03:44', '2020-01-09 12:03:44', 0, '', '', '', '', '', '', '', '', '', '', 0),
(93, 'Backlit wireless Mini Keyboard Controller With Touchpad Mouse, Mini Keyboard for android TV Box', 'backlit-wireless-mini-keyboard-controller-with-touchpad-mouse-mini-keyboard-for-android-tv-box', 1290, 0, '1150', ' ', '<h2><strong>Multi Color Mini Keyboard/ Bluetooth Keyboard</strong></h2>\r\n\r\n<p>✔ মিনি কি বোর্ড সহজে ব্যাবহার করতে পারবেন ।</p>\r\n\r\n<p>✔ মাউস প্যাড (1,2,3 ফিংগার কন্ট্রোল ।</p>\r\n\r\n<p>✔ লাইট অফ-অন রং পরিবর্তন করতে পারবেন ।</p>\r\n\r\n<p>✔ মাউস বাটন ।</p>\r\n\r\n<p>✔ মিউজিক,জয়েস্টিক কন্ট্রোল বাটন ।</p>\r\n', NULL, '', '1127', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 12:05:27', '2020-01-09 12:05:27', 0, '', '', '', '', '', '', '', '', '', '', 0),
(94, 'Capsule Cutter with super fast motor ideal kitchen tool for slicing boneless meat, vegetable, fruit salads, onion and garlic, cutting various foods for baby, chopping herbs', 'capsule-cutter-with-super-fast-motor-ideal-kitchen-tool-for-slicing-boneless-meat-vegetable-fruit-salads-onion-and-garlic-cutting-various-foods-for-baby-chopping-herbs', 1490, 0, '1290', ' ', '<p>✔ সকল ধরনের সবজী কাটতে পারবেন ।</p>\r\n\r\n<p>✔ সহজে ব্যাহার করা যায় ।</p>\r\n\r\n<p>✔ সাইজ: 116 x d 116 x 233 mm</p>\r\n\r\n<p>✔ ওজন: ১.২কেজি।</p>\r\n\r\n<p>✔ ধারণ ক্ষমতা : ২০০ গ্রাম,</p>\r\n\r\n<p>✔ ABS প্লাস্টিক , ট্রাইটন ব্লেড স্টেইনেলস স্টিল দ্বারা তৈরী ।</p>\r\n\r\n<p>✔ Power consumption: 200 W</p>\r\n\r\n<p>✔ Voltage rating: 100V 50 / 60 Hz</p>\r\n\r\n<p>✔ Cable length: 1 m</p>\r\n', NULL, '', '1129', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 12:07:26', '2020-01-09 12:07:26', 0, '', '', '', '', '', '', '', '', '', '', 0),
(95, 'Foldable Silicone electric water heater kettle for outdoor travel home Camping', 'foldable-silicone-electric-water-heater-kettle-for-outdoor-travel-home-camping', 1690, 0, '1390', ' ', '<h2><strong>Travel Water Heater Pot</strong></h2>\r\n\r\n<p>✔ পানি গরম করার একটি ডিভাইস</p>\r\n\r\n<p>✔ ভাজ করে রাখতে ছোট করে রাখতে পারবেন ।</p>\r\n\r\n<p>✔ আন অফ সুইচ ।</p>\r\n\r\n<p>✔ ফুড গ্রেডে উপাদান দিয়ে তৈরি ।</p>\r\n\r\n<p>✔ সহজে বহনযোগ্য</p>\r\n', NULL, '', '1130', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 12:09:20', '2020-01-09 12:09:20', 0, '', '', '', '', '', '', '', '', '', '', 0),
(96, 'AnyCast M2 Plus Wireless WiFi Display Dongle Receiver 1080P HD Interface TV Stick, HDMI Dongle', 'anycast-m2-plus-wireless-wifi-display-dongle-receiver-1080p-hd-interface-tv-stick-hdmi-dongle', 1490, 0, '1350', ' ', '<p>✔ যে কোন নরমাল টিভি কে স্মার্ট টিভি বানাতে পারবেন ।</p>\r\n\r\n<p>✔ মোবাইলের স্ক্রিন টিভি তে শেয়ার করতে পারবেন ✔ গেমস খেলতে ও মুভি দেখতে পারবেন ।</p>\r\n', NULL, '', '1131', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 12:10:39', '2020-01-09 12:10:39', 0, '', '', '', '', '', '', '', '', '', '', 0),
(97, '5pcs Professional Paint Roller Brush For Room Wall Painting Edge Painting Decorative Multifunctional Paint Roller Brush Set', '5pcs-professional-paint-roller-brush-for-room-wall-painting-edge-painting-decorative-multifunctional-paint-roller-brush-set', 1490, 0, '1150', ' ', '<p>✔ আপনার বাসা বাড়ি রং করতে পারবেন অতি সহজেই</p>\r\n\r\n<p>✔ অল্প সময়ে বেশী জায়গা রং করতে পাবেন</p>\r\n\r\n<p>✔ চমৎকার ফিনিশিংদিবে ,কোন প্রকার ডাষ্ট লাগবেনা</p>\r\n\r\n<p>✔ আছে কর্ণারে রং করার সু ব্যাবস্থা।</p>\r\n\r\n<p>✔ পরিস্কার করা খুবই সহজ ।</p>\r\n', NULL, '', '1132', 0, NULL, '', '', 1, 'home', '2020-01-09 12:13:01', '2020-01-09 12:13:01', 0, '', '', '', '', '', '', '', '', '', '', 0),
(98, '360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box (Black)', '360-degrees-rotating-cosmetics-organizer-jewelry-storage-shelf-makeup-organizer-lipstick-brush-holder-storage-box-black', 1590, 0, '1390', ' ', '<p>✔ মহিলাদের কসমেটিকস সাজিয়ে রাখার জন্য সুন্দর একটি ডিভাইস</p>\r\n\r\n<p>✔ দেখতে অসাধারন যা আপনার ঘরের সৌন্দর্য্য বাড়িয়ে দিবে</p>\r\n\r\n<p>✔ শক্ত চাচের তৈরী। সাদা, কালো এবং গোলাপী কালারে পাওয়া যায়</p>\r\n\r\n<p>✔ ৩ লেয়ার। লেয়ারগুলো নিজের মত করে এডজাষ্ট করে নেয়া যায়।</p>\r\n\r\n<p>✔ 360 Degree move করা যায় ।</p>\r\n', NULL, '', '1133B', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 12:16:18', '2020-01-09 12:16:18', 0, '', '', '', '', '', '', '', '', '', '', 0),
(99, '360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box (White)', '360-degrees-rotating-cosmetics-organizer-jewelry-storage-shelf-makeup-organizer-lipstick-brush-holder-storage-box-white', 1490, 0, '1390', ' ', '<p>✔ মহিলাদের কসমেটিকস সাজিয়ে রাখার জন্য সুন্দর একটি ডিভাইস</p>\r\n\r\n<p>✔ দেখতে অসাধারন যা আপনার ঘরের সৌন্দর্য্য বাড়িয়ে দিবে</p>\r\n\r\n<p>✔ শক্ত চাচের তৈরী। সাদা, কালো এবং গোলাপী কালারে পাওয়া যায়</p>\r\n\r\n<p>✔ ৩ লেয়ার। লেয়ারগুলো নিজের মত করে এডজাষ্ট করে নেয়া যায়।</p>\r\n\r\n<p>✔ 360 Degree move করা যায় ।</p>\r\n', NULL, '', '1133W', 0, NULL, '', '', 1, 'home', '2020-01-09 12:17:45', '2020-01-09 12:17:45', 0, '', '', '', '', '', '', '', '', '', '', 0),
(100, '360 Degrees Rotating Cosmetics Organizer Jewelry Storage Shelf Makeup Organizer Lipstick Brush Holder Storage Box (Pink)', '360-degrees-rotating-cosmetics-organizer-jewelry-storage-shelf-makeup-organizer-lipstick-brush-holder-storage-box-pink', 1490, 0, '1390', ' ', '<p>✔ মহিলাদের কসমেটিকস সাজিয়ে রাখার জন্য সুন্দর একটি ডিভাইস</p>\r\n\r\n<p>✔ দেখতে অসাধারন যা আপনার ঘরের সৌন্দর্য্য বাড়িয়ে দিবে</p>\r\n\r\n<p>✔ শক্ত চাচের তৈরী। সাদা, কালো এবং গোলাপী কালারে পাওয়া যায়</p>\r\n\r\n<p>✔ ৩ লেয়ার। লেয়ারগুলো নিজের মত করে এডজাষ্ট করে নেয়া যায়।</p>\r\n\r\n<p>✔ 360 Degree move করা যায় ।</p>\r\n', NULL, '', '1133P', 0, NULL, '', '', 1, 'home', '2020-01-09 12:19:09', '2020-01-09 12:19:09', 0, '', '', '', '', '', '', '', '', '', '', 0),
(101, 'Portable Electric BBQ Stove - Smokeless Electric Pan Grill, Barbecue machine with 5 Temperature Mode for Home Camping', 'portable-electric-bbq-stove---smokeless-electric-pan-grill-barbecue-machine-with-5-temperature-mode-for-home-camping', 1590, 0, '1390', ' ', '<h2><strong>Portable Electric BBQ Grill</strong></h2>\r\n\r\n<p>✔ ইলেকট্রিক BBQ গ্রিল মেকার</p>\r\n\r\n<p>✔ BBQ গ্রিল তৈরী করার একটি ইলেকট্রিক টুল</p>\r\n\r\n<p>✔ মাংস বা সী-ফুড, ভেজিটেবল, প্যানকেক গ্রীল, বেক, ফ্রাই করার উপযোগী</p>\r\n\r\n<p>✔ অ্যাডজাস্টেবল হিট কন্ট্রোল</p>\r\n\r\n<p>✔ হালকা, মজবুত, পোর্টেবল</p>\r\n\r\n<p>✔ স্টেইনলেস স্টীল হিটিং এলিমেন্ট</p>\r\n\r\n<p>✔ হিট-রেজিস্ট্যান্ট গ্রীপ</p>\r\n\r\n<p>✔ নন-স্টিক প্যান</p>\r\n\r\n<p>✔ পাওয়ার সোর্স: AC 220-240v/50Hz</p>\r\n\r\n<p>✔ পাওয়ার: 2000W</p>\r\n\r\n<p>✔ ডাইমেনসন: ৫১x৫০x৩৭সে.মি.</p>\r\n\r\n<p>✔ হাই কোয়ালিটি প্রোডাক্ট</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1134', 0, NULL, '', '', 1, 'home', '2020-01-09 12:21:03', '2020-01-09 12:21:03', 0, '', '', '', '', '', '', '', '', '', '', 0),
(102, 'Stainless Steel Adjustable Clothes Hanger Rack- Double Rail Clothes Rack Adjustable Height Rolling Garment Rack Stainless Steel 2 Shelf Pole Clothes Hanger Freestanding Organizer', 'stainless-steel-adjustable-clothes-hanger-rack--double-rail-clothes-rack-adjustable-height-rolling-garment-rack-stainless-steel-2-shelf-pole-clothes-hanger-freestanding-organizer', 1790, 0, '1650', ' ', '<p>✔ ক্লথ হ্যাঙ্গিং স্ট্যান্ড স্ট্যান্ড</p>\r\n\r\n<p>✔ ম্যাটেরিয়াল: স্টেইনলেস স্টীল</p>\r\n\r\n<p>✔ কাপড় রাখার জন্য পর্যাপ্ত জাগা রয়েছে</p>\r\n\r\n<p>✔ জুতা রাখার জন্য নিচে একটি তাক রয়েছে</p>\r\n\r\n<p>✔ ফোল্ডেবল তাই ঘরের জায়গা বাঁচায়</p>\r\n\r\n<p>✔ অ্যাডজাস্টেবল হাইট</p>\r\n\r\n<p>✔ যে কোনো জায়গায় মুভ করার জন্য চাকা রয়েছে</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1135', 0, NULL, '', '', 1, 'home', '2020-01-09 12:24:38', '2020-01-09 12:24:38', 0, '', '', '', '', '', '', '', '', '', '', 0),
(103, 'Mini Sewing Machine, Portable Electric Double Speed Sewing Machine with Foot Pedal Power Supply for Household Travel and Beginner - Stitch Set 16', 'mini-sewing-machine-portable-electric-double-speed-sewing-machine-with-foot-pedal-power-supply-for-household-travel-and-beginner---stitch-set-16', 1790, 0, '1450', ' ', '<h2><strong>Mini Sewing Machine Double Speed</strong></h2>\r\n\r\n<p>✔ দ্বিগুন গতি</p>\r\n\r\n<p>✔ সহজে বহনযোগ্য এবং হালকা</p>\r\n\r\n<p>✔ সামনে-পিছনে সমানভাবে সেলাই করা যাবে</p>\r\n\r\n<p>✔ সুইচ অথবা প্যাডেলের মাধ্যমে চালনা করা যায়</p>\r\n\r\n<p>✔ ব্যাটারি চালিত, এডাপ্টার দিয়েও চালানো যায় ( ৬ ভোল্ট ডিসি ৬০০মিলিএম্প.)</p>\r\n\r\n<p>✔ ওজনঃ ৬৪৮ গ্রাম</p>\r\n\r\n<p>✔ সাইজঃ ২১x১২.৫x২০ সেন্টিমিটার</p>\r\n\r\n<p>✔ সাথে আপনি আরো যা যা পাচ্ছেন- ১টি সুঁই, এডাপ্টার, একটি ফুট প্যাডেল, ববিন ৪ টা।</p>\r\n', NULL, '', '1136', 0, NULL, '', '', 1, 'home', '2020-01-09 12:29:03', '2020-01-09 12:29:03', 0, '', '', '', '', '', '', '', '', '', '', 0),
(104, 'Electric Indoor Insect Mosquito Killer, UV LED Light Fly Zapper, Indoor Fly Catcher, Insect Trap Lamp, for Residential, Commercial and Industrial Use (Large)', 'electric-indoor-insect-mosquito-killer-uv-led-light-fly-zapper-indoor-fly-catcher-insect-trap-lamp-for-residential-commercial-and-industrial-use-large', 1890, 0, '1750', '  ', '<p>✔ মশা-মাছি, কীট-পতঙ্গ মারা যায় (১০০% নিশ্চয়তা) ।</p>\r\n\r\n<p>✔ কোনো রাসায়নিক, ধোঁয়া বা গন্ধ নেই; তাই মানব শরীরের জন্য ক্ষতিকর নয়।</p>\r\n\r\n<p>✔ একটি শক্তিশালী আলোর সাহায্যে পতঙ্গকে আকৃষ্ট করে এবং ইলেক্ট্রিক ওয়েভ দিয়ে ধ্বংস করে দেয়।</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1137L', 0, NULL, '', '', 1, 'home', '2020-01-09 12:31:12', '2020-01-09 12:31:12', 0, '', '', '', '', '', '', '', '', '', '', 0);
INSERT INTO `product` (`product_id`, `product_title`, `product_name`, `product_price`, `purchase_price`, `discount_price`, `product_summary`, `product_description`, `product_specification`, `product_terms`, `sku`, `product_stock`, `product_of_size`, `product_color`, `product_video`, `status`, `product_type`, `created_time`, `modified_time`, `folder`, `feasured_image`, `galary_image_6`, `galary_image_1`, `galary_image_2`, `galary_image_3`, `galary_image_4`, `galary_image_5`, `seo_title`, `seo_keywords`, `seo_content`, `stock_alert`) VALUES
(105, 'Electric Indoor Insect Mosquito Killer, UV LED Light Fly Zapper, Indoor Fly Catcher, Insect Trap Lamp, for Residential, Commercial and Industrial Use (Small)', 'electric-indoor-insect-mosquito-killer-uv-led-light-fly-zapper-indoor-fly-catcher-insect-trap-lamp-for-residential-commercial-and-industrial-use-small', 1490, 0, '1350', ' ', '<p>✔ মশা-মাছি, কীট-পতঙ্গ মারা যায় (১০০% নিশ্চয়তা) ।</p>\r\n\r\n<p>✔ কোনো রাসায়নিক, ধোঁয়া বা গন্ধ নেই; তাই মানব শরীরের জন্য ক্ষতিকর নয়।</p>\r\n\r\n<p>✔ একটি শক্তিশালী আলোর সাহায্যে পতঙ্গকে আকৃষ্ট করে এবং ইলেক্ট্রিক ওয়েভ দিয়ে ধ্বংস করে দেয়।</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1137S', 0, NULL, '', '', 1, 'home', '2020-01-09 12:32:30', '2020-01-09 12:32:30', 0, '', '', '', '', '', '', '', '', '', '', 0),
(106, 'Kitchen Stainless Steel Garlic Press Crusher Home Kitchen Mincer Tool', 'kitchen-stainless-steel-garlic-press-crusher-home-kitchen-mincer-tool', 490, 0, '390', ' ', '<p>✔ আদা-রশুন জাতীয় সকল ধরনের মশলা পেষ্ট করতে পারবেন ।</p>\r\n\r\n<p>✔ স্টেইনলেস স্টিল দ্বারা তৈরী তাই মরিচা পড়ার কোন শংকা নেই।</p>\r\n', NULL, '', '1139', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 12:34:40', '2020-01-09 12:34:40', 0, '', '', '', '', '', '', '', '', '', '', 0),
(107, 'Pop up Spice Rack - Smartlife Kitchen Storage Racks Organizer Spice Tree Pots, 6 Cans Set', 'pop-up-spice-rack-smartlife-kitchen-storage-racks-organizer-spice-tree-pots-6-cans-set', 590, 0, '550', ' ', '<p>✔ Pop Up স্পাইস র&zwj;্যাক</p>\r\n\r\n<p>✔ ৬ টির সেট</p>\r\n\r\n<p>✔ সাথে Pop-up রাবার লিড</p>\r\n\r\n<p>✔ প্রয়োজনীয় স্পাইস, জিরা পাউডার, লবন, চিনি বা ✔ যেকোনো মসলা এতে সহজেই রাখা যায়</p>\r\n\r\n<p>✔ আকর্ষনীয় ডিজাইন</p>\r\n\r\n<p>✔ রান্নাঘরের জন্য প্রয়োজনীয় একটি উপকরন</p>\r\n', NULL, '', '1140', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 12:36:12', '2020-01-09 12:36:12', 0, '', '', '', '', '', '', '', '', '', '', 0),
(108, 'Manual Stainless Steel Vegetable Chopper, Easy Salad Maker, Onion Chopper', 'manual-stainless-steel-vegetable-chopper-easy-salad-maker-onion-chopper', 590, 0, '490', ' ', '<h3><strong>Manual Onion Garlic Vegetable Food Chopper</strong></h3>\r\n\r\n<p>✔ আপনার রান্নাঘরের জন্য একটি আদর্শ টুল</p>\r\n\r\n<p>✔ ব্যবহার করা খুবই সহজ</p>\r\n\r\n<p>✔ যে কোন সবজি, পেঁয়াজ, আদা এর ভিতর বসিয়ে হাতের তালুর সাহায্যে চাপ দিলেই স্লাইস হয়ে যাবে</p>\r\n\r\n<p>✔ স্টেইনলেস স্টিল দিয়ে তৈরি ব্লেড যা খুব সহজেই পরিষ্কার করা যায়</p>\r\n\r\n<p>✔ ব্লেড সাইজ: উচ্চতা - ২১.৫ সেমি প্রস্থ - ৮ সেমি</p>\r\n', NULL, '', '1141', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 12:37:35', '2020-01-09 12:37:35', 0, '', '', '', '', '', '', '', '', '', '', 0),
(109, 'Manual Multifunctional Vegetable Chopper, Powerful Hand Held Vegetable Chopper / Kitchen Gadgets', 'manual-multifunctional-vegetable-chopper-powerful-hand-held-vegetable-chopper-kitchen-gadgets', 590, 0, '490', ' ', '<h3><strong>Manual Vegetable Fruit Garlic Chopper</strong></h3>\r\n\r\n<p>✔ আপনার রান্নাঘরের সবজি কাটাকুটি করতে পারবেন</p>\r\n\r\n<p>✔ যেকোন সবজি চপিং করতে পারবেন খুবই সহজে</p>\r\n\r\n<p>✔ মজবুত প্লাস্টিক দ্বারা তৈরী ।</p>\r\n\r\n<p>✔ স্টেইনলেস স্টিল ব্লেড ।</p>\r\n', NULL, '', '1142', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 12:39:13', '2020-01-09 12:39:13', 0, '', '', '', '', '', '', '', '', '', '', 0),
(110, 'Nicer Dicer Plus, Vegetable Cutter Chopper', 'nicer-dicer-plus-vegetable-cutter-chopper', 790, 0, '690', ' ', '<h2><strong>Nicer Dicer Plus</strong></h2>\r\n\r\n<p>✔ রান্না ঘরের শাকসব্জী, ফল মূল কাটা, স্লাইস করা, গ্রেট করতে পারেন।</p>\r\n\r\n<p>✔ এর সাহায্যে সালাদ / ফলকিউব, স্টিক, স্ট্রিপ, কোয়ার্টার বা eighths করে কাটুন ,খুবতাড়াতাড়ি।</p>\r\n\r\n<p>✔ স্পেস সেভিং,ক্যাপাসিটি: ১৫০০মিলি,</p>\r\n\r\n<p>✔ ৫টি আলাদা পার্ট সের সাহায্যে ১১টি বিভিন্ন ভাবে সালাদ /ফল কাটা যায়।</p>\r\n', NULL, '', '1143', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 12:40:30', '2020-01-09 12:40:30', 0, '', '', '', '', '', '', '', '', '', '', 0),
(111, 'Infrared Motion Sensor Holder for Light, Human Body Sensor Lamp Holder', 'infrared-motion-sensor-holder-for-light-human-body-sensor-lamp-holder', 790, 0, '690', ' ', '<h2><strong>Motion Sensor Holder</strong></h2>\r\n\r\n<p>✔ অটোমেটিক মোশন সেন্সর হোল্ডার-এ যে কোন ব্র্যান্ড এর প্যাচ মাথার বাতি এই হোল্ডারে ব্যবহার করা যায়</p>\r\n\r\n<p>✔ একবার সুইচ অন করে দিলে সেন্সর, বাতি অটো অন/ অফ করবে</p>\r\n\r\n<p>✔ মানুষ বা যেকোনো প্রাণীর আগমনে এই হোল্ডারের বাতি অটো জ্বলে এবং নির্গমনে অটো নিভে যায়</p>\r\n\r\n<p>✔ গ্যারেজ/ অন্ধকার প্যাসেজ/ সিড়িতে, অন্ধকার রুম অথবা বাথরুমে ব্যবহার করা যায়</p>\r\n\r\n<p>✔ বিদ্যুৎ বিল সাশ্রয় করতে&#39;&#39; এবং &#39;&#39;চোরকে ধোঁকা দিতে&#39;&#39; ও বাড়ীর সিকিউরিটি গার্ড হিসেবে কাজ করতে ব্যবহার করা যায়</p>\r\n\r\n<p>✔ আপনার বাড়ীর সিড়িঁ কোঠা, কার পাকিং, স্টোর রুম ,রানা ঘর, বাথ রুম, মেইন গেইট ইত্যাদি জায়গায় লাগাতে পারবেন।</p>\r\n\r\n<p>✔ প্যাকেজে আছে: সেন্সর হোল্ডার ও এক জোড়া স্ক্র ✔ ড্রাইভিং লোড: 30W CFL / LED</p>\r\n', NULL, '', '1144', 0, NULL, '', '', 1, 'general', '2020-01-09 12:41:59', '2020-01-09 12:41:59', 0, '', '', '', '', '', '', '', '', '', '', 0),
(112, 'Portable Medium Size First Aid Kit Box, Household Multi Layer Medicine Drawer Health Box', 'portable-medium-size-first-aid-kit-box-household-multi-layer-medicine-drawer-health-box', 890, 0, '790', ' ', '<p>✔ এই বক্সে আপনি আপনার ব্যবহৃত সকল যন্ত্রপাতি, ঔষধ রাখতে পারবেন।</p>\r\n\r\n<p>✔ লক সিস্টেম ।</p>\r\n\r\n<p>✔ ভেতরে শক্ত পার্টিশন, থাকায় সব কিছু সাজিয়ে রাখতে পারবেন ।</p>\r\n\r\n<p>✔ এয়ার-প্রুভ ।</p>\r\n\r\n<p>✔ শক্ত প্লাস্টিক দ্বারা তৈরী ।</p>\r\n', NULL, '', '1145', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 12:44:37', '2020-01-09 12:44:37', 0, '', '', '', '', '', '', '', '', '', '', 0),
(113, 'Suction Mug - Creative Insulated Plastic Bottle Magic \"not Fall Down\" Travel Coffee Cup Travel Mug Balance Cups', 'suction-mug-creative-insulated-plastic-bottle-magic-not-fall-down-travel-coffee-cup-travel-mug-balance-cups', 990, 0, '790', ' ', '<p>✔ এই মগ টি ঠেলে ফেলানো যাবে না। তাই চা-কফি পড়ে কোন কিছু নষ্ট হবে না ।</p>\r\n\r\n<p>✔ পিপি. স্টেইনলেস স্টিল দ্বারা তৈরী ।</p>\r\n\r\n<p>✔ ধারণ ক্ষমতা : 540 ml</p>\r\n\r\n<p>✔ তাপ প্রতিরোধক ।</p>\r\n\r\n<p>✔ পানি ঝরবে না ।</p>\r\n', NULL, '', '1146', 0, NULL, '', '', 1, 'general', '2020-01-09 12:50:51', '2020-01-09 12:50:51', 0, '', '', '', '', '', '', '', '', '', '', 0),
(114, 'Multi Functional Electric Egg Boiler & Fryer, Non-Stick Frying Pan, Mini Egg Pan Steam Boiler Fried Steak Sandwich', 'multi-functional-electric-egg-boiler--fryer-non-stick-frying-pan-mini-egg-pan-steam-boiler-fried-steak-sandwich', 990, 0, '890', ' ', '<p>✔ ইলেকট্রিক এগ বয়লার অ্যান্ড ফ্রাইং প্যান</p>\r\n\r\n<p>✔ এখন ইলেকট্রিক এগ বয়লার এর সাহায্যে ডিম সেদ্ধ করুন নিমিষেই</p>\r\n\r\n<p>✔ একসাথে ৭টি ডিম সেদ্ধ করা যায়</p>\r\n\r\n<p>✔ নন-স্টিকি</p>\r\n\r\n<p>✔ সহজে ব্যবহার ও পরিষ্কার করা যায়</p>\r\n\r\n<p>✔ রাউন্ড প্লেট তাই সহজে হিট ছড়িয়ে যায়</p>\r\n\r\n<p>✔ হাই থার্মাল ইফিশিয়েন্সি</p>\r\n\r\n<p>✔ অটোমেটিক টেম্পারেচার অ্যাডজাস্টমেন্ট</p>\r\n\r\n<p>✔ টাইম ও ইলেকট্রিসিটি সেভিং</p>\r\n\r\n<p>✔ ডিমের জন্য রয়েছে স্টিমিং র&zwnj;্যাক</p>\r\n\r\n<p>✔ সাথে প্লাস্টিকের স্মল মেজারিং কাপ রয়েছে</p>\r\n\r\n<p>✔ হাউজিং ম্যাটেরিয়াল: প্লাস্টিক</p>\r\n\r\n<p>✔ পাওয়ার (W): 350</p>\r\n\r\n<p>✔ সাইজঃ ১৫৫ x ১৫৫ x ১৩০ মিমি</p>\r\n\r\n<p>✔ ভোল্টেজঃ 220V/50Hz</p>\r\n', NULL, '', '1147', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 07:19:30', '2020-01-09 07:19:30', 0, '', '', '', '', '', '', '', '', '', '', 0),
(115, 'Iron Metal Multi Remote Control Stand,4 Remote Stand Holder, Remote Holder for Home,tv Remote Holder Stand', 'iron-metal-multi-remote-control-stand4-remote-stand-holder-remote-holder-for-hometv-remote-holder-stand', 990, 0, '590', ' ', '<h2><strong>Remote Stand Organizer</strong></h2>\r\n\r\n<p>✔ ম্যাটেরিয়ালঃ প্লাস্টিক</p>\r\n\r\n<p>✔ হাই কোয়ালিটি প্রোডাক্ট</p>\r\n\r\n<p>✔ সহজেই ব্যবহার করা যায়</p>\r\n\r\n<p>✔ পরিবেশবান্ধব</p>\r\n\r\n<p>✔ লং লাস্টিং</p>\r\n', NULL, '', '1148', 0, NULL, '', '', 1, 'home', '2020-01-09 07:26:23', '2020-01-09 07:26:23', 0, '', '', '', '', '', '', '', '', '', '', 0),
(116, 'LED Colorful music flowerpot Bluetooth Speaker, Colorful LED Night Light Touch Plant Piano Music Playing, Creative Birthday Gifts Gifts or home office', 'led-colorful-music-flowerpot-bluetooth-speaker-colorful-led-night-light-touch-plant-piano-music-playing-creative-birthday-gifts-gifts-or-home-office', 1090, 0, '950', ' ', '<h3><strong>Smart Flowerpot Music Plant Pot with LED Night Light</strong></h3>\r\n\r\n<p>✔ মোবাইলের সাথে কানেক্ট করে গান বাজাতে পারবেন ।</p>\r\n\r\n<p>✔ টবে গাছ রোপন করতে পারবেন ।</p>\r\n\r\n<p>✔ জীবন্ত গাছের পাতা ছুলেই আলো জ্বলবে এবং মিউজিক বাজবে ।</p>\r\n', NULL, '', '1149', 0, NULL, '', '', 1, 'home', '2020-01-09 07:30:56', '2020-01-09 07:30:56', 0, '', '', '', '', '', '', '', '', '', '', 0),
(117, 'Casio Scientific Calculator FX-991ES Plus LED Display, Battery and Solar Dual Power Supply, 417 Functions Calculator for students', 'casio-scientific-calculator-fx-991es-plus-led-display-battery-and-solar-dual-power-supply-417-functions-calculator-for-students', 1590, 0, '1290', ' ', '<h3><strong>Casio FX991ES Plus Scientific Calculator</strong></h3>\r\n\r\n<p>✔ Equation calculations</p>\r\n\r\n<p>✔ Integration/differential calculations</p>\r\n\r\n<p>✔ Matrix calculations</p>\r\n\r\n<p>✔ Vector calculations</p>\r\n\r\n<p>✔ Complex number calculations</p>\r\n\r\n<p>✔ CALC function</p>\r\n\r\n<p>✔ SOLVE function</p>\r\n\r\n<p>✔ Base-n calculation</p>\r\n\r\n<p>✔ 1 Year Warranty</p>\r\n', NULL, '', '1150', 0, NULL, '', '', 1, 'home', '2020-01-09 07:34:21', '2020-01-09 07:34:21', 0, '', '', '', '', '', '', '', '', '', '', 0),
(118, 'Adjustable Handheld Micro Boom Pole Microphone Mic Holder (Boom Stick) 3 Section Boompole 67.5inch Extension', 'adjustable-handheld-micro-boom-pole-microphone-mic-holder-boom-stick-3-section-boompole-675inch-extension', 2990, 0, '2590', ' ', '<h2><strong>Boom Stick Pro/Big</strong></h2>\r\n\r\n<p>✔ A device to hold the boom microphone</p>\r\n\r\n<p>✔ Idle for professional video maker</p>\r\n\r\n<p>✔ Materials : Aluminium</p>\r\n\r\n<p>✔ Max Hight : 9 ft</p>\r\n\r\n<p>✔ Max Load : 4000gm</p>\r\n\r\n<p>✔ Type : Hand Held Boom</p>\r\n\r\n<p>✔ Colour : Black</p>\r\n\r\n<p>✔ Weight : 1342gm</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1151', 0, NULL, '', '', 1, 'home', '2020-01-09 07:38:11', '2020-01-09 07:38:11', 0, '', '', '', '', '', '', '', '', '', '', 0),
(119, 'Stainless Steel Manual Pasta Maker, Noodles Maker - Silver', 'stainless-steel-manual-pasta-maker-noodles-maker---silver', 1900, 0, '1590', ' ', '<h2><strong>নুডুলস, সেমাই ও পাস্তা মেকার</strong></h2>\r\n\r\n<p>✔ নুডুলস, সেমাই ও পাস্তা তৈরি করুন এখন ঘরেই</p>\r\n\r\n<p>✔ এই সহজ যন্ত্রটি দিয়ে তৈরি করুন নিজে নিজেই বিভিন্ন সাইজের ও স্বাদের সেমাই, নুডুলস ও পাস্তা</p>\r\n\r\n<p>তৈরি করতে পারবেন</p>\r\n\r\n<p>✔ ম্যাটেরিয়াল: স্টেইনলেস স্টীল</p>\r\n\r\n<p>✔ হালকা ও সহজ প্রক্রিয়া</p>\r\n\r\n<p>✔ কোন রকম ক্ষতিকর প্রতিক্রিয়া বা ঝুঁকি নেই</p>\r\n\r\n<p>✔ ডো রোলার: ১৫০ মিমি।</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1152', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 07:40:11', '2020-01-09 07:40:11', 0, '', '', '', '', '', '', '', '', '', '', 0),
(120, 'Best Quality non-stick Electric Roti Maker / chapati maker (Black)', 'best-quality-non-stick-electric-roti-maker--chapati-maker-black', 2700, 0, '2300', ' ', '<h3><strong>Special Electric Roti Maker (বাজারের সেরা রুটি মেকারটি)</strong></h3>\r\n\r\n<p>✔ স্টেইনলেস স্টীল</p>\r\n\r\n<p>✔ উপরের প্লেটটি লিফট করার জন্য নব রয়েছে</p>\r\n\r\n<p>✔ ডাইমেন্সনঃ ৩১৫ x ২২৫ x ২৪৫ মিমি</p>\r\n\r\n<p>✔ ওজনঃ ৩.৫ কেজি</p>\r\n\r\n<p>✔ ১০০০ ওয়াট</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1154B', 0, NULL, '', 'eDZCSGg3NOU', 1, 'home', '2020-01-09 07:48:11', '2020-01-09 07:48:11', 0, '', '', '', '', '', '', '', '', '', '', 0),
(121, 'Best Quality non-stick Electric Roti Maker / chapati maker (SS)', 'best-quality-non-stick-electric-roti-maker--chapati-maker-ss', 2700, 0, '2300', ' ', '<h3><strong>Special Electric Roti Maker (বাজারের সেরা রুটি মেকারটি)</strong></h3>\r\n\r\n<p>✔ স্টেইনলেস স্টীল</p>\r\n\r\n<p>✔ উপরের প্লেটটি লিফট করার জন্য নব রয়েছে</p>\r\n\r\n<p>✔ ডাইমেন্সনঃ ৩১৫ x ২২৫ x ২৪৫ মিমি</p>\r\n\r\n<p>✔ ওজনঃ ৩.৫ কেজি</p>\r\n\r\n<p>✔ ১০০০ ওয়াট</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1154SS', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 07:50:07', '2020-01-09 07:50:07', 0, '', '', '', '', '', '', '', '', '', '', 0),
(122, 'Electric Muffin Maker Electric Cupcake Maker Automatic Temperature Control Mini Cake Machine', 'electric-muffin-maker-electric-cupcake-maker-automatic-temperature-control-mini-cake-machine', 2990, 0, '2690', ' ', '<p>✔ Makes 7 cupcakes at one time</p>\r\n\r\n<p>✔ Power and preheat indicator lights</p>\r\n\r\n<p>✔ 5-Minute cooking time</p>\r\n\r\n<p>✔ Non-stick coating</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1155', 0, NULL, '', '', 1, 'home', '2020-01-09 07:51:51', '2020-01-09 07:51:51', 0, '', '', '', '', '', '', '', '', '', '', 0),
(123, 'Portable Electric Lunch Box Food Container / Food Warmer Heater Rice Container', 'portable-electric-lunch-box-food-container--food-warmer-heater-rice-container', 850, 0, '750', ' ', '<p>✔ এই বক্সটি আপনার খাবারকে গরম করবে মাত্র কয়েক মিনিটে</p>\r\n\r\n<p>✔ এই লাঞ্চ বক্স হতে পারে আপনার নিত্য দিনের প্রয়োজনীয় সঙ্গী</p>\r\n\r\n<p>✔ এটি শক Proof এবং কম বিদ্যুৎ খরচে চলে</p>\r\n\r\n<p>✔ সহজে বহনযোগ্য</p>\r\n\r\n<p>✔ পাওয়ার: ৪০ ওয়াট</p>\r\n\r\n<p>✔ ডাইমেনশন: 180 x 115 x 247mm</p>\r\n\r\n<p>✔ কালার: Random</p>\r\n', NULL, '', '1156', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 07:53:54', '2020-01-09 07:53:54', 0, '', '', '', '', '', '', '', '', '', '', 0),
(124, 'Revoflex Xtreme Multi-function Full Body Workout Exercise Equipment', 'revoflex-xtreme-multi-function-full-body-workout-exercise-equipment', 1090, 0, '790', ' ', '<p><strong>Revoflex xtreme (একের ভিতর সব। একটি মাত্র যন্ত্র দিয়ে সব ব্যায়াম চালিয়ে যাবেন নিজের বাসায়। REVOFLEX XTREME Workout Set)</strong></p>\r\n\r\n<p>✔ যারা জিম এ গিয়ে ব্যায়াম করার কথা ভাবছেন তাদের জন্য আমরা নিয়ে এসেছি এই পন্যটি।খুব সহজেই আপনি বাসায় বসে 80 ধরনের করতে পারবেন।<br />\r\n✔ এই পন্যটি পুরুষ এবং মহিলা উভয়ই ব্যবহার করতে পারবে।&nbsp;<br />\r\n✔ এই প্যাকেটে পরিবহন করার জন্য একটি ব্যাগ দেয়া আছে। চাইলে আপনি খুব সহজেই এটি যে কোন জায়গায় বহন করতে পারবেন।&nbsp;<br />\r\n✔&nbsp;Expand chest, back, arms, sho ulders and abs in one motion.<br />\r\n✔&nbsp;Shape your body quickly, easily and effortlessly.<br />\r\n✔ Compact so that you can take it anywhere!<br />\r\n✔&nbsp;Material: Pressured PP, ABS plastic, latex rubber rope, and EVA pad.<br />\r\n✔&nbsp;Dimensions: 43*19* 13sm.<br />\r\n✔&nbsp;Weight: 900.00gm.<br />\r\n✔&nbsp;Package includes</p>\r\n', NULL, '', '1157', 0, NULL, '', 'RzqJdOpDRsQ', 1, 'hotsell', '2020-01-09 08:00:06', '2020-01-09 08:00:06', 0, '', '', '', '', '', '', '', '', '', '', 0),
(125, 'Veet Sensitive Touch Electric Trimmer for Women', 'veet-sensitive-touch-electric-trimmer-for-women', 700, 0, '550', ' ', '<h2>Veet Sensitive Touch Electric Trimmer</h2>\r\n\r\n<p>✔ Veet লেডিজ শেভার</p>\r\n\r\n<p>✔ এর সাহায্যে শরীরের অবাঞ্ছিত লোম দূর করুন নিখুঁতভাবে ও নিরাপদে</p>\r\n\r\n<p>✔ ১ টি AA ব্যাটারি দ্বারা চালিত</p>\r\n\r\n<p>✔ ০.৫মিমি কাটিং লেন্থ</p>\r\n\r\n<p>✔ ডাবল-সাইড রেজর</p>\r\n\r\n<p>✔ আরামদায়ক হেয়ার রিমুভাল</p>\r\n\r\n<p>✔ ভিজানো যাবে</p>\r\n\r\n<p>✔ সহজে ব্যবহার করা যায়</p>\r\n\r\n<p>✔ সাথে রয়েছে ক্লিনিং ব্রাশ</p>\r\n', NULL, '', '1158', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 08:06:52', '2020-01-09 08:06:52', 0, '', '', '', '', '', '', '', '', '', '', 0),
(126, 'Portable Folding Pocket Prayer Mat with Compass /Islamic Janamaz / Easy Carry Prayer Mat', 'portable-folding-pocket-prayer-mat-with-compass-islamic-janamaz--easy-carry-prayer-mat', 250, 0, '', ' ', '<p>✔ পোর্টেবল পকেট জায়নামাজ<br />\r\n✔ অত্যাধুনিক প্রযুক্তিতে তৈরি এ জায়নামায সহজে পরিবহন যোগ্য এবং ভাজ করে পকেটে নেয়া যায়!<br />\r\n✔ এটি সম্পূর্ণ water proof!<br />\r\n✔ণ্যটি মুসলমানদের জন্য খুবই দরকারী<br />\r\n✔ সাথে আছে দিক নির্ণয় করার জন্য কম্পাস<br />\r\n✔ যে কোন স্থানের পশ্চিম দিক স্বয়ংক্রিয় ভাবে নির্দেশ করে দিবে!<br />\r\n✔ ম্যাটেরিয়াল: পলিয়েস্টার<br />\r\n✔ কালার: Random<br />\r\n✔ ওজনঃ মাত্র ৮০ গ্রাম<br />\r\n✔ ওয়াটার প্রুফ<br />\r\n✔ সাইজঃ 47x23 inch</p>\r\n', NULL, '', '1161', 0, NULL, '', '', 1, 'general', '2020-01-09 08:16:53', '2020-01-09 08:16:53', 0, '', '', '', '', '', '', '', '', '', '', 0),
(127, 'Portable Digital Infrared Ear Thermometer with LCD Display, Digital LCD Thermometer, Pocket Thermometer', 'portable-digital-infrared-ear-thermometer-with-lcd-display-digital-lcd-thermometer-pocket-thermometer', 1490, 0, '1290', '  ', '<p>✔ Measure in ear</p>\r\n\r\n<p>✔ No probe covers needed</p>\r\n\r\n<p>✔ 10 reading memory</p>\r\n\r\n<p>✔ 2 seconds reading</p>\r\n\r\n<p>✔ Dual scale</p>\r\n\r\n<p>✔ Compact ergonomic size</p>\r\n\r\n<p>✔ Beeps when ready</p>\r\n\r\n<p>✔ Jumbo display</p>\r\n\r\n<p>✔ Replaceable battery</p>\r\n\r\n<p>✔ Auto off</p>\r\n', NULL, '', '1162', 0, NULL, '', '', 1, 'home', '2020-01-09 09:08:45', '2020-01-09 09:08:45', 0, '', '', '', '', '', '', '', '', '', '', 0),
(128, '3 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup', '3-drawers-acrylic-transparent-makeup-organizer-cosmetics-storage-box-cosmetics-brush-organizer-clear-storage-box-for-jewelry-makeup', 1490, 0, '1290', ' ', '<h2><strong>3 Tray Cosmetics Organizer</strong></h2>\r\n\r\n<p>সকল ধরনের সাজ সামগ্রী সাজিয়ে রাখতে পারবেন ।</p>\r\n\r\n<h3>পন্যের বিবরণ:</h3>\r\n\r\n<p>✔&nbsp;মেক আপ অর্গানাইজার</p>\r\n\r\n<p>✔ গহনা ও কসমেটিক্স রাখার উপযোগী</p>\r\n\r\n<p>✔&nbsp;Acrylic কসমেটিক অর্গানাইজার স্টোরেজ বক্স।</p>\r\n\r\n<p>✔&nbsp;আপনার কসমেটিকস, মেকআপ সামগ্রী, জুয়েলারি গুছিয়ে রাখার জন্য ৩টি ড্রয়ার রয়েছে</p>\r\n\r\n<p>✔&nbsp;হাই কোয়ালিটি Acrylic ম্যাটেরিয়ালে তৈরি ও ডেলিকেট হ্যান্ডেল ।</p>\r\n\r\n<p>✔&nbsp;ক্রিস্টাল ক্লিয়ার এবং ট্র্যান্সপারেন্ট ।</p>\r\n\r\n<p>✔&nbsp;আকর্ষনীয় ডিজাইন।</p>\r\n\r\n<p>✔ ম্যাটেরিয়াল-উন্নত প্লাস্টিক</p>\r\n', NULL, '', '1163', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 08:32:18', '2020-01-09 08:32:18', 0, '', '', '', '', '', '', '', '', '', '', 0),
(129, '4 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup', '4-drawers-acrylic-transparent-makeup-organizer-cosmetics-storage-box-cosmetics-brush-organizer-clear-storage-box-for-jewelry-makeup', 1490, 0, '1290', ' ', '<h2><strong>4 Tray Cosmetics Organizer</strong></h2>\r\n\r\n<p>সকল ধরনের সাজ সামগ্রী সাজিয়ে রাখতে পারবেন ।</p>\r\n\r\n<h3><strong>পন্যের বিবরণ:</strong></h3>\r\n\r\n<p>✔ মেক আপ অর্গানাইজার</p>\r\n\r\n<p>✔ গহনা ও কসমেটিক্স রাখার উপযোগী</p>\r\n\r\n<p>✔&nbsp;Acrylic কসমেটিক অর্গানাইজার স্টোরেজ বক্স।</p>\r\n\r\n<p>✔&nbsp;আপনার কসমেটিকস, মেকআপ সামগ্রী, জুয়েলারি গুছিয়ে রাখার জন্য ৪টি ড্রয়ার রয়েছে ।</p>\r\n\r\n<p>✔&nbsp;২টি ছোট ড্রয়ার ও ২টি বড় হাই ড্রয়ার</p>\r\n\r\n<p>✔&nbsp;হাই কোয়ালিটি Acrylic ম্যাটেরিয়ালে তৈরি ও ডেলিকেট হ্যান্ডেল ।</p>\r\n\r\n<p>✔&nbsp;ক্রিস্টাল ক্লিয়ার এবং ট্র্যান্সপারেন্ট ।</p>\r\n\r\n<p>✔&nbsp;আকর্ষনীয় ডিজাইন।</p>\r\n\r\n<p>✔ ম্যাটেরিয়াল-উন্নত প্লাস্টিক</p>\r\n', NULL, '', '1164', 0, NULL, '', '', 1, 'home', '2020-01-09 08:47:47', '2020-01-09 08:47:47', 0, '', '', '', '', '', '', '', '', '', '', 0),
(130, '5 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup', '5-drawers-acrylic-transparent-makeup-organizer-cosmetics-storage-box-cosmetics-brush-organizer-clear-storage-box-for-jewelry-makeup', 1490, 0, '1290', ' ', '<h2><strong>5 Tray Cosmetics Organizer</strong></h2>\r\n\r\n<p>সকল ধরনের সাজ সামগ্রী সাজিয়ে রাখতে পারবেন ।</p>\r\n\r\n<h3>পন্যের বিবরণ:</h3>\r\n\r\n<p>✔&nbsp;মেক আপ অর্গানাইজার</p>\r\n\r\n<p>✔ গহনা ও কসমেটিক্স রাখার উপযোগী</p>\r\n\r\n<p>✔&nbsp;Acrylic কসমেটিক অর্গানাইজার স্টোরেজ বক্স।</p>\r\n\r\n<p>✔&nbsp;আপনার কসমেটিকস, মেকআপ সামগ্রী, জুয়েলারি গুছিয়ে রাখার জন্য ৩টি ড্রয়ার রয়েছে</p>\r\n\r\n<p>✔&nbsp;হাই কোয়ালিটি Acrylic ম্যাটেরিয়ালে তৈরি ও ডেলিকেট হ্যান্ডেল ।</p>\r\n\r\n<p>✔&nbsp;ক্রিস্টাল ক্লিয়ার এবং ট্র্যান্সপারেন্ট ।</p>\r\n\r\n<p>✔&nbsp;আকর্ষনীয় ডিজাইন।</p>\r\n\r\n<p>✔ ম্যাটেরিয়াল-উন্নত প্লাস্টিক</p>\r\n', NULL, '', '1165', 0, NULL, '', '', 1, 'general', '2020-01-09 08:50:09', '2020-01-09 08:50:09', 0, '', '', '', '', '', '', '', '', '', '', 0),
(131, '6 Drawers Acrylic transparent Makeup Organizer Cosmetics Storage Box Cosmetics Brush Organizer Clear Storage Box for Jewelry Makeup', '6-drawers-acrylic-transparent-makeup-organizer-cosmetics-storage-box-cosmetics-brush-organizer-clear-storage-box-for-jewelry-makeup', 1490, 0, '1290', ' ', '<h2><strong>6 Tray Cosmetics Organizer</strong></h2>\r\n\r\n<p>সকল ধরনের সাজ সামগ্রী সাজিয়ে রাখতে পারবেন ।</p>\r\n\r\n<h3>পন্যের বিবরণ:</h3>\r\n\r\n<p>✔&nbsp;মেক আপ অর্গানাইজার</p>\r\n\r\n<p>✔ গহনা ও কসমেটিক্স রাখার উপযোগী</p>\r\n\r\n<p>✔&nbsp;Acrylic কসমেটিক অর্গানাইজার স্টোরেজ বক্স।</p>\r\n\r\n<p>✔&nbsp;আপনার কসমেটিকস, মেকআপ সামগ্রী, জুয়েলারি গুছিয়ে রাখার জন্য ৩টি ড্রয়ার রয়েছে</p>\r\n\r\n<p>✔&nbsp;হাই কোয়ালিটি Acrylic ম্যাটেরিয়ালে তৈরি ও ডেলিকেট হ্যান্ডেল ।</p>\r\n\r\n<p>✔&nbsp;ক্রিস্টাল ক্লিয়ার এবং ট্র্যান্সপারেন্ট ।</p>\r\n\r\n<p>✔&nbsp;আকর্ষনীয় ডিজাইন।</p>\r\n\r\n<p>✔ ম্যাটেরিয়াল-উন্নত প্লাস্টিক</p>\r\n', NULL, '', '1166', 0, NULL, '', '', 1, 'general', '2020-01-09 08:51:30', '2020-01-09 08:51:30', 0, '', '', '', '', '', '', '', '', '', '', 0),
(132, 'Professional Adjustable LED Lighted Vanity Makeup Mirror, Touch Screen Mirrors For Beauty Makeup Eyelash Brush', 'professional-adjustable-led-lighted-vanity-makeup-mirror-touch-screen-mirrors-for-beauty-makeup-eyelash-brush', 1290, 0, '890', ' ', '<p>Large 16 LED lighted desktop 360 degree adjustable folding screen touch LED makeup mirror with touch screen</p>\r\n\r\n<h3><strong>Features:</strong></h3>\r\n\r\n<p>✔ Can stand in a flat position</p>\r\n\r\n<p>✔ Use battery: 4 x AAA batteries (Battery not included)</p>\r\n\r\n<p>✔ Unlimited gear touch screen intelligent switch</p>\r\n\r\n<p>✔ Can be stopped at various angles to use</p>\r\n\r\n<p>✔ Full range of illumination without dead angle</p>\r\n\r\n<p>✔ 16 LED lights, In a dark place can clearly reflect your appearance</p>\r\n\r\n<p>✔ Easy to operate a powerful switch, the ability to adapt to different light, different light environment. Can find the light intensity that you need in touch screen intelligent switch</p>\r\n\r\n<p>✔ Color: white, pink, black</p>\r\n', NULL, '', '1169', 0, NULL, '', '', 1, 'general', '2020-01-09 08:56:23', '2020-01-09 08:56:23', 0, '', '', '', '', '', '', '', '', '', '', 0),
(133, 'Acrylic Makeup Organizer 16 Slot with Removable Mirror Cosmetic Organizers', 'acrylic-makeup-organizer-16-slot-with-removable-mirror-cosmetic-organizers', 1290, 0, '890', ' ', '', NULL, '', '1170', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 09:00:11', '2020-01-09 09:00:11', 0, '', '', '', '', '', '', '', '', '', '', 0),
(134, 'Original 10000mAh Xiaomi MI Power Bank (Dual Output)', 'original-10000mah-xiaomi-mi-power-bank-dual-output', 1690, 0, '1250', ' ', '', NULL, '', '1171', 0, NULL, '', '', 1, 'home', '2020-01-09 09:01:35', '2020-01-09 09:01:35', 0, '', '', '', '', '', '', '', '', '', '', 0),
(135, 'Automatic Toothpaste Dispenser, 5 Toothbrush Holder Stand Set Wall Mount', 'automatic-toothpaste-dispenser-5-toothbrush-holder-stand-set-wall-mount', 590, 0, '450', ' ', '<p>✔ এটি অটোমেটিক ভাবে বাথরুমের দেয়ালে আটকে থাকে।</p>\r\n\r\n<p>✔ টুথব্রাশ প্রবেশ করানোর সাথে সাথেই অটোমেটিক ভাবে টুথপেষ্ট ব্রাশে প্রয়োজনমত জমা হবে।</p>\r\n\r\n<p>✔ একসাথে টুথব্রাশ হোল্ডারে পাঁচটি ব্রাশ রাখা যাবে।</p>\r\n\r\n<p>✔ একসাথে টুথব্রাশ ডিসপেনসার এবং টুথব্রাশ হোল্ডার</p>\r\n', NULL, '', '1174', 0, NULL, '', '', 1, 'home', '2020-01-09 09:03:25', '2020-01-09 09:03:25', 0, '', '', '', '', '', '', '', '', '', '', 0),
(136, 'Exclusive lage cosmetic organizer box mirror (beautiful two-sided round mirror) - Transparent Acrylic cosmetic storage box- 3 Drawers', 'exclusive-lage-cosmetic-organizer-box-mirror-beautiful-two-sided-round-mirror---transparent-acrylic-cosmetic-storage-box--3-drawers', 1590, 0, '1390', ' ', '<p>সকল ধরনের সাজ সামগ্রী সাজিয়ে রাখতে পারবেন ।</p>\r\n\r\n<p>✔ মেক আপ অর্গানাইজার</p>\r\n\r\n<p>✔ গহনা ও কসমেটিক্স রাখার উপযোগী</p>\r\n\r\n<p>✔ ম্যাটেরিয়াল-উন্নত প্লাস্টিক</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1175', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 09:05:22', '2020-01-09 09:05:22', 0, '', '', '', '', '', '', '', '', '', '', 0),
(137, '360 Rotating Design Acrylic Clear Makeup Rack 3D Cosmetic Organizer', '360-rotating-design-acrylic-clear-makeup-rack-3d-cosmetic-organizer', 1590, 0, '1390', ' ', '<h3><strong>3D 360 DEGREE ACRYLIC MAKE UP ORGANISER/STAND</strong></h3>\r\n\r\n<p>The 360-degree Rotating Cosmetic Organizer stores all your makeup in a simple and awesome design. The organizer stores all your daily beauty essentials, arranging them in elaborately designed compartments. What&rsquo;s more, it can spin so that you can easily access to your skin care, colored cosmetics, makeup pads, brushes, jewelry and other items.</p>\r\n\r\n<h3><strong>Features:</strong></h3>\r\n\r\n<p>Compact size with large capacity.</p>\r\n\r\n<p>Cleans easily with soap and water.</p>\r\n\r\n<p>Multi-functional assemble cosmetics organizer.</p>\r\n\r\n<p>Adequate space for storing different accessories.</p>\r\n\r\n<p>Makeup Storage can be used as a desk organizer, too.</p>\r\n\r\n<p>Convenient to find cosmetics because it rotates 360 degrees.</p>\r\n\r\n<p>Makeup storage drawers keep everything neatly stored and within reach. Stores cosmetic, skin care, makeup pads, and other bathroom accessories.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h3><strong>Specifications</strong></h3>\r\n\r\n<p>Type: Cosmetic Organizer</p>\r\n\r\n<p>Material: Acrylic</p>\r\n\r\n<p>Movement: Rotating Spinning</p>\r\n\r\n<p>Colors: Clear</p>\r\n\r\n<p>Product size: Diameter 9.84&rdquo;/25cm Height 14.17&rdquo;/36cm</p>\r\n\r\n<p>Package size: 330*270*145ml</p>\r\n\r\n<p>Layers: 1-3 Layers</p>\r\n\r\n<p>Occasion: Dressing table</p>\r\n\r\n<p>Package includes:1 x Cosmetics Organizer (Needs to be assembled)</p>\r\n', NULL, '', '1177', 0, NULL, '', '', 1, 'general', '2020-01-09 09:13:21', '2020-01-09 09:13:21', 0, '', '', '', '', '', '', '', '', '', '', 0),
(138, 'Digital Body Weight Scale, Glass Top, Large LCD Display, Precision Measurements (Round)', 'digital-body-weight-scale-glass-top-large-lcd-display-precision-measurements-round', 1190, 0, '990', ' ', '<h2><strong>Glass Personal Weighing Scale</strong></h2>\r\n\r\n<h3>Specifications</h3>\r\n\r\n<p>✔ Weighing Scale</p>\r\n\r\n<p>✔&nbsp;Material: Glass</p>\r\n\r\n<p>✔&nbsp;Size:25x25</p>\r\n\r\n<p>✔ Edge tap</p>\r\n\r\n<p>✔ switch off/ Auto-off</p>\r\n\r\n<p>✔ maximum capacity : 200 kgs</p>\r\n\r\n<p>✔ 25mm thick</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1178', 0, NULL, '', '', 1, 'home', '2020-01-09 09:18:08', '2020-01-09 09:18:08', 0, '', '', '', '', '', '', '', '', '', '', 0),
(139, 'Easy Dough Maker / Atta Maker', 'easy-dough-maker-atta-maker', 700, 0, '550', ' ', '<p>✔ রুটি তৈরির জন্য আটা/ময়দা ময়ান করার উৎকৃস্ট যন্ত্র|<br />\r\n✔ হাতের কোন স্পর্শ ও পরিশ্রম ছাড়াই সম্পন্ন হবে আটার বল|<br />\r\n✔ ১:1:1 অনুপাতে পানি, তেল ও&nbsp; আটা মেশাতে হবে|<br />\r\n✔ ম্যাটেরিয়াল:উন্নত প্লাস্টিক|<br />\r\n✔ ব্যবহার করা সহজ</p>\r\n\r\n<p>✔ ১০০% কোয়ালিটি প্রডাক্ট</p>\r\n', NULL, '', '1180', 0, NULL, '', '5Ny5m0TdUNM', 1, 'general', '2020-01-09 09:22:19', '2020-01-09 09:22:19', 0, '', '', '', '', '', '', '', '', '', '', 0),
(140, 'Nima 2 in 1 Electric Spice Grinder & Juicer  Mini Juicer Mini Blender', 'nima-2-in-1-electric-spice-grinder--juicer--mini-juicer-mini-blender', 1190, 0, '950', ' ', '', NULL, '', '1181', 0, NULL, '', '', 1, 'general', '2020-01-09 09:43:29', '2020-01-09 09:43:29', 0, '', '', '', '', '', '', '', '', '', '', 0),
(141, 'M3 Smart Fitness Wristband Bracelet / Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones', 'm3-smart-fitness-wristband-bracelet--fitness-tracker-heart-rate-monitor-smart-reminder-for-iphone-android-phones', 790, 0, '390', ' স্বাস্থ্য সচেতনদের জন্য খুবই সুন্দর একটি পণ্য', '<p>✔ অত্যাধুনিক ডিজাইনের একটি স্মার্ট ঘড়ি/ব্যান্ড</p>\r\n\r\n<p>✔ অত্যন্ত কমদামের মধ্যে এই ডিভাইসটি আপনার অনেকগুলো কাজ সহজ করে দিবে</p>\r\n\r\n<p>✔ এটি দ্বারা আপনি আপনার প্রতিদিন কতটুকু/কদম/কত কিলোমিটার হেঁটেছন তার রেকর্ড দেখতে পাবেন</p>\r\n\r\n<p>✔ আপনার আজকের হাটার মাধ্যমে আপনি কতটুকু ক্যালরী বার্ন করেছেন তা দেখতে পাবেন</p>\r\n\r\n<p>✔ আপনার হার্টরেইট কত চলছে এই মুহুর্তে তা চেক করতে পারবেন</p>\r\n\r\n<p>✔ আপনার এই মুহুর্তে ব্লাড প্রেসারের কি অবস্থা তা চেক করতে পারবেন মুহুর্তের মধ্যেই</p>\r\n\r\n<p>✔ আপনার Facebook, Tweeter, Whatsapp, Line আরো সব Social Media গুলোর Notification দেখতে পাবেন এই ডিভাইসে পেয়ে যাবেন</p>\r\n\r\n<p>✔ সবচেয়ে মজার ব্যাপার হচ্ছে - এই ডিভাইসটিকে আপনি আপনার স্মার্টফোন থেকে কন্ট্রোল করতে পারবেন।</p>\r\n\r\n<p>✔ আরো অনেক সুন্দর সুন্দর অপশন পাবেন এই ডিভাইসটিতে</p>\r\n', NULL, '', '1182', 0, NULL, '', '', 1, 'hotsell', '2020-01-09 09:45:24', '2020-01-09 09:45:24', 0, '', '', '', '', '', '', '', '', '', '', 0),
(142, 'Xiaomi Mi Band 3 OLED Smart Fitness Wristband Bracelet / Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones', 'xiaomi-mi-band-3-oled-smart-fitness-wristband-bracelet--fitness-tracker-heart-rate-monitor-smart-reminder-for-iphone-android-phones', 2799, 0, '2200', ' ', '<p>✔ অত্যাধুনিক ডিজাইনের একটি স্মার্ট ঘড়ি/ব্যান্ড</p>\r\n\r\n<p>✔ অত্যন্ত কমদামের মধ্যে এই ডিভাইসটি আপনার অনেকগুলো কাজ সহজ করে দিবে</p>\r\n\r\n<p>✔ এটি দ্বারা আপনি আপনার প্রতিদিন কতটুকু/কদম/কত কিলোমিটার হেঁটেছন তার রেকর্ড দেখতে পাবেন</p>\r\n\r\n<p>✔ আপনার আজকের হাটার মাধ্যমে আপনি কতটুকু ক্যালরী বার্ন করেছেন তা দেখতে পাবেন</p>\r\n\r\n<p>✔ আপনার হার্টরেইট কত চলছে এই মুহুর্তে তা চেক করতে পারবেন</p>\r\n\r\n<p>✔ আপনার এই মুহুর্তে ব্লাড প্রেসারের কি অবস্থা তা চেক করতে পারবেন মুহুর্তের মধ্যেই</p>\r\n\r\n<p>✔ আপনার Facebook, Tweeter, Whatsapp, Line আরো সব Social Media গুলোর Notification দেখতে পাবেন এই ডিভাইসে পেয়ে যাবেন</p>\r\n\r\n<p>✔ সবচেয়ে মজার ব্যাপার হচ্ছে - এই ডিভাইসটিকে আপনি আপনার স্মার্টফোন থেকে কন্ট্রোল করতে পারবেন।</p>\r\n\r\n<p>✔ আরো অনেক সুন্দর সুন্দর অপশন পাবেন এই ডিভাইসটিতে</p>\r\n\r\n<p>✔ Display Size: 0.78 inch</p>\r\n\r\n<p>✔ Connectivity: Bluetooth 4.2</p>\r\n\r\n<p>✔ Waterproof: Yes</p>\r\n\r\n<p>✔ Screen type: OLED</p>\r\n\r\n<p>✔ Compatible OS: Android, IOS</p>\r\n\r\n<p>✔ Battery Capacity: 110 mAh</p>\r\n\r\n<p>✔ Standby time: 20 days</p>\r\n\r\n<p>✔ Charging Time: About 2 Hours</p>\r\n', NULL, '', '1183', 0, NULL, '', '', 1, 'home', '2020-01-09 09:47:36', '2020-01-09 09:47:36', 0, '', '', '', '', '', '', '', '', '', '', 0),
(143, 'TWS I11 Wireless Bluetooth Headset with Charging Box Sports Running Ear Plugs Hanging Ears Wearing Earphones', 'tws-i11-wireless-bluetooth-headset-with-charging-box-sports-running-ear-plugs-hanging-ears-wearing-earphones', 1300, 0, '990', ' ', '<p>✔ অত্যাধুনিক ডিজাইনের একটি ওয়ারলেস হেডফোন</p>\r\n\r\n<p>✔ এটি Bluetooth এর মাধ্যমে কানেক্ট হবে আপনার ফোনের সাথে</p>\r\n\r\n<p>✔ সুপার স্টাইলিশ ডিজাইনের এই ডিভাইসটি আপনার লুকই বদলে দিবে।</p>\r\n\r\n<p>✔ একবার Charge করলে ৩-৪ ঘন্টা continue ব্যবহার করতে পারবেন। Standby Mode এ&nbsp; চলবে ১২০ ঘন্টা</p>\r\n\r\n<p>✔ এর স্টাইলিশ Charger, সাউন্ড কোয়ালিটি আপনার মন কেড়ে নিবে।</p>\r\n\r\n<p>✔ Noise reduce করার জন্য এটিতে রয়েছে Powerful noise de-noising circuit</p>\r\n\r\n<p>✔ এর সাথে দেয়া আছে 300mh এর একটি charging box, যা দ্বারা আপনি ৩ থেকে ৫ বার হেডফোনটিকে chage করে নিতে পারবেন। তার মানে হচ্ছে আপনি কোন লম্বা সফরে গেলেও charging এর কোন সমস্যা হবে না।</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Driver: 15mm</p>\r\n\r\n<p>Impedance: 9 OHM</p>\r\n\r\n<p>Bluetooth version: Bluetooth 5.0</p>\r\n\r\n<p>Output power: 40mW;Battery capacity 45MAH , charging box is 300mh .</p>\r\n\r\n<p>Bluetooth distance: 10 meters</p>\r\n\r\n<p>Frequency response: 20-20000Hz</p>\r\n\r\n<p>Operating voltage range: 3.0V-4.2V</p>\r\n\r\n<p>Powerful noise de-noising circuit (active noise reduction)</p>\r\n\r\n<p>Charging time about 1-2 hours .</p>\r\n\r\n<p>Talk time is about 2-3 hours (a pair of earphones use together ),music time about 2-3 hours (a pair of earphones use together ) , Charging box can charge for the earphons about 3-5 times.</p>\r\n\r\n<p>Standby time is about 120 hours.</p>\r\n', NULL, '', '1184', 0, NULL, '', '', 1, 'home', '2020-01-09 10:00:04', '2020-01-09 10:00:04', 0, '', '', '', '', '', '', '', '', '', '', 0),
(144, 'Remax RB-S8 Sports Bluetooth Headset wireless earbuds Sport Stereo Earphone Magnetic Charge with hd Mic Hands-free Call ', 'remax-rb-s8-sports-bluetooth-headset-wireless-earbuds-sport-stereo-earphone-magnetic-charge-with-hd-mic-hands-free-call-', 2200, 0, '1750', ' ', '<p>✔ সুপার স্টাইলিশ ডিজাইনের ওয়ারলেস হেডফোন যার ডিজাইন/লুক আপনার মন কেড়ে নিবে।</p>\r\n\r\n<p>✔ এটি Bluetooth এর মাধ্যমে কানেক্ট হবে আপনার ফোনের সাথে</p>\r\n\r\n<p>✔ একবার Charge করলে ৬-৭ ঘন্টা continue ব্যবহার করতে পারবেন।</p>\r\n\r\n<p>✔ হেডফোনটির সাউন্ড কোয়ালিটি আসলেই অসাধারন।</p>\r\n\r\n<p>Bluetooth V5.0</p>\r\n\r\n<p>Built-in 160mAh Rechargeable Battery</p>\r\n\r\n<p>Bluetooth Frequency Band: 2.4GHz-2.48GHz</p>\r\n\r\n<p>Bluetooth Communication Range: 10m</p>\r\n\r\n<p>Speaker Diameter: 10mm</p>\r\n\r\n<p>Sensitivity: 105dB&plusmn;3dB</p>\r\n\r\n<p>Impedance: 16&Omega;</p>\r\n\r\n<p>Transmission Range: 50-10000Hz&nbsp;</p>\r\n\r\n<p>Working Voltage: 3.7V</p>\r\n\r\n<p>Rated Output Power: 3.5mW</p>\r\n\r\n<p>Output Power: 5mW</p>\r\n\r\n<p>Charging Time: About 2 Hours</p>\r\n\r\n<p>Phone/Music Time: About 7 Hours</p>\r\n', NULL, '', '1185', 0, NULL, '', '', 1, 'home', '2020-01-09 10:01:41', '2020-01-09 10:01:41', 0, '', '', '', '', '', '', '', '', '', '', 0),
(145, 'Remax RB-S8 HIFI wireless Bluetooth Headphones earbuds Hands-free Wireless Neckband Noise Cancelling Earphone Magnetic Earbuds Sweatproof Earphones 7-9 Hrs Playtime for Running Gym Workout w/Mic', 'remax-rb-s8-hifi-wireless-bluetooth-headphones-earbuds-hands-free-wireless-neckband-noise-cancelling-earphone-magnetic-earbuds-sweatproof-earphones-7-9-hrs-playtime-for-running-gym-workout-wmic', 1850, 0, '1690', ' ', '<p>✔ সুপার স্টাইলিশ ডিজাইনের ওয়ারলেস হেডফোন যার ডিজাইন/লুক আপনার মন কেড়ে নিবে।</p>\r\n\r\n<p>✔ এটি Bluetooth এর মাধ্যমে কানেক্ট হবে আপনার ফোনের সাথে</p>\r\n\r\n<p>✔ একবার Charge করলে ৬-৭ ঘন্টা continue ব্যবহার করতে পারবেন।</p>\r\n\r\n<p>✔ হেডফোনটির সাউন্ড কোয়ালিটি আসলেই অসাধারন।</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>High-Quality Sound</p>\r\n\r\n<p>Bluetooth Version: V4.1</p>\r\n\r\n<p>Transmission Protocol: A2DP/AVRCP</p>\r\n\r\n<p>Transmission Distance: 10m</p>\r\n\r\n<p>Driver Unit: 10mm</p>\r\n\r\n<p>Battery Capacity: 100mAh</p>\r\n\r\n<p>Mic Snesitivity: -43dB+/-2dB</p>\r\n\r\n<p>Bluetooth Frequency: 2.4GHz-2.48GHz</p>\r\n', NULL, '', '1186', 0, NULL, '', '', 1, 'home', '2020-01-09 10:02:58', '2020-01-09 10:02:58', 0, '', '', '', '', '', '', '', '', '', '', 0),
(146, 'BOYA BY-M1DM Dual Clip Microphone for Interview 2 Person Recording Live Videos Camera smartphone iPhone Canon DSLR PK Rode', 'boya-by-m1dm-dual-clip-microphone-for-interview-2-person-recording-live-videos-camera-smartphone-iphone-canon-dslr-pk-rode', 2250, 0, '1890', ' ', '<p>✔ মোবাইল, অডিও রেকর্ডার, কম্পিউটার, ক্যামেরা, ল্যাপট, এ ব্যাবহার করা যাবে এই মাইক্রোফোনটি ।</p>\r\n\r\n<p>✔ এর সাথে দেয়া কেবলটির দৈর্ঘ্য ৪ মিটার।</p>\r\n\r\n<p>✔ এর মধ্যে ২টি ক্লিপ মাইক্রোফোন থাকায় যে কোন ইন্টারভিউ, টকশো যাতীয় কাজে ব্যবহার করা যাবে।</p>\r\n\r\n<p>✔ সুদৃশ্য ব্যাগ থাকায় গুছিয়ে রাখা যাবে খুব সহজেই এবং পকেটে নিয়ে যে কোন জায়গায় বহন করা যাবে ।</p>\r\n\r\n<p>✔ যে কোন এম্প্লীফায়ারে ব্যাবহার করতে পারবেন।</p>\r\n\r\n<p>✔ এটি যে কোন মাইকের মেশিনে/ এমপ্লিফায়ারে ও ব্যবহার করা যাবে।</p>\r\n', NULL, '', '1187', 0, NULL, '', '', 1, 'home', '2020-01-09 10:05:28', '2020-01-09 10:05:28', 0, '', '', '', '', '', '', '', '', '', '', 0),
(147, 'Sardine F1 TWS Aluminium Wireless Bluetooth Speaker with Charging Dock 3D Stereo Subwoofer Bass Speaker for smartphone hands-free Mic Portable Loudspeaker', 'sardine-f1-tws-aluminium-wireless-bluetooth-speaker-with-charging-dock-3d-stereo-subwoofer-bass-speaker-for-smartphone-hands-free-mic-portable-loudspeaker', 2890, 0, '1990', ' ', '<p>✔ ছোট প্যাকেটে বড় ধামাকা &ndash; এই বাক্যটি সঠিকভাবে প্রয়োগ করা যাবে এই স্পিকারটিতে (true stereo)</p>\r\n\r\n<p>✔ খুবই স্টাইটিশ ডিজাইনের এই ছোট্ট দুটি স্পিকার আমার মিউজিকের জগতকে করে তুলবে মোহনীয়। কারন এর সাউন্ড কোয়ালিটি বড় বড় স্পিকারকেও হার মানাবে। স্পিকারদুটিতে আপনি শুনতে পাবেন real stereo sound.</p>\r\n\r\n<p>✔ সম্পূর্ণ এর মাধ্যমে এটি যুক্ত হবে আপনার যে কোন ডিজিটাল গ্যাজেটের সাথে।</p>\r\n\r\n<p>✔ সবচেয়ে মজার বিষয় এর charging system টাও সম্পূর্ন তারবিহীন। এর সাথে দেয়া একটি প্লেটের মধ্যে বসিয়ে দিলে স্পিকারগুলো চার্জ হয়ে যাবে খুব সহজে। Charging এর সময় মহোনীয় LED light এর আলোয় আপনার Desktop টি হয়ে উঠবে মোহনীয়।</p>\r\n\r\n<p>✔ একবার full charge করলে খুব সহজেই চালাতে পারবেন ২-৪ ঘন্টা</p>\r\n\r\n<p>Material: Aluminum Alloy Shell + ABS + Silica gel</p>\r\n\r\n<p>Playback time: 2-4 hours</p>\r\n\r\n<p>Speaker size: 49.3*46mm</p>\r\n\r\n<p>Support Hand-free (with MIC)</p>\r\n\r\n<p>Output: 3W*2</p>\r\n\r\n<p>Impedance: 4 Ohm</p>\r\n\r\n<p>External USB 5V supply</p>\r\n\r\n<p>Battery: 400mAh</p>\r\n\r\n<p>Distortion: 0.3%</p>\r\n\r\n<p>SNR: &gt;=85db</p>\r\n\r\n<p>Bluetooth solution: JL4.2 + EDR</p>\r\n\r\n<p>Speaker: 40mm 4Ohm, 3W</p>\r\n\r\n<p>✔ Package Include:</p>\r\n\r\n<ul>\r\n	<li>2 x Bluetooth speakers</li>\r\n	<li>1 x User manual</li>\r\n	<li>1 x charging dock</li>\r\n</ul>\r\n\r\n<p>1 x Micro USB cable</p>\r\n', NULL, '', '1188', 0, NULL, '', '', 1, 'home', '2020-01-09 10:08:30', '2020-01-09 10:08:30', 0, '', '', '', '', '', '', '', '', '', '', 0),
(148, 'T6 Portable Adjustable Laptop Table/stand for Notebook MacBook Ergonomic TV Bed Lap Stand Up Sitting with Pad Side Mount', 't6-portable-adjustable-laptop-tablestand-for-notebook-macbook-ergonomic-tv-bed-lap-stand-up-sitting-with-pad-side-mount', 1990, 0, '1690', ' ', '<p>✔ পোর্টেবল ল্যাপটপ টেবিল<br />\r\n✔ কম্প্যাক্ট ডিজাইন,লাইটওয়েট এন্ড ডিওর্যাবল<br />\r\n✔ পোর্টেবল,যেকোন জায়গায় বহন করে নেয়া যাবে<br />\r\n✔ ফ্লেক্সিবল: অ্যাডজাস্টেবল হাইট এন্ড এঙ্গেল<br />\r\n✔ অটো লক ডিজাইন<br />\r\n✔ বিল্ট ইন ২ টি USB পাওয়ার্ড কুলার ফ্যান<br />\r\n✔ ট্রে সাইজঃ ২৭.৫ সেমি উইডথ, ৪৩ সেমি লেন্থ<br />\r\n✔ ম্যাক্সিমাম হাইটঃ ৪৮ সেমি<br />\r\n✔ ৩৬০&deg; রোটেটিং অ্যালুমিনিয়াম লেগ<br />\r\n✔ ম্যাটেরিয়ালঃ অ্যালুমিনিয়াম<br />\r\n✔ সর্বোচ্চ লোডঃ ১৫ কেজি<br />\r\n✔ নেট ওয়েটঃ ২.৫ কেজি</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1189', 0, NULL, '', '', 1, 'home', '2020-01-09 10:13:46', '2020-01-09 10:13:46', 0, '', '', '', '', '', '', '', '', '', '', 0),
(149, 'Silicone Gloves Magic Silicone Dish Washing Glove Household Scrubber Rubber Kitchen Cleaning Tool Kitchen Gloves ', 'silicone-gloves-magic-silicone-dish-washing-glove-household-scrubber-rubber-kitchen-cleaning-tool-kitchen-gloves-', 650, 0, '400', ' ', '<p>✔ এটি থালাবাসন ধোবার সময় হাতে এক্সট্রা গ্রিপ আনে ফলে থালাবাসন হাত থেকে পড়ে ভেঙ্গে যাওয়ার সম্ভবনা নেই।</p>\r\n\r\n<p>&nbsp;✔ সাবান, ভিম, ভিক্সল ও কাপড় কাঁচা ডিটারজেন্টে থাকা ক্ষতিকারক ক্যামিকেল হতে আপনার হাতকে রক্ষা করে&nbsp;<br />\r\n✔ এটি দ্বারা থালা-বাসন, হাড়ি-পাতিল, বেসিন, সিংক, কমোড, ফ্লোর, টাইলস সবকিছুর সহজেই পরিষ্কার করতে পারবেন হাতের কোন ক্ষতি না করেই।</p>\r\n\r\n<p>✔ এটি হাই গ্রেডের সিলিকন দ্বারা তৈরী হওয়ার অনেক দিন ব্যবহার করতে পারবেন।</p>\r\n\r\n<p>✔ এটি দিয়ে আপনি গরম জিনিস ও ধরতে পারবেন কোন সমস্যা ছাড়াই।</p>\r\n\r\n<p>✔ কালার: Random</p>\r\n', NULL, '', '1191', 0, NULL, '', '', 1, 'general', '2020-01-09 10:15:54', '2020-01-09 10:15:54', 0, '', '', '', '', '', '', '', '', '', '', 0),
(150, 'Xiaomi MI WiFi Repeater Universal Router 300Mbps - WIFI Range Extender', 'xiaomi-mi-wifi-repeater-universal-router-300mbps---wifi-range-extender', 990, 0, '750', ' ', '<p>MI repeater 2 এর মাধ্যমে ওয়াইফাই সিগন্যাল ১০০০ স্কয়ার ফিট পর্যন্ত বাড়াতে পারবেন, আর এটা যেখানে কম পক্ষে ২ দাগ সিগন্যাল যেখানে পাওয়া যায় সেখানে সেট করতে হবে এবং যেকোনো রাউটারের সাথে ব্যাবহার করা যাবে।</p>\r\n\r\n<p>Type: WiFi Amplifier</p>\r\n\r\n<p>Dimensions: 12.00&times;3.00&times;9.00 cm</p>\r\n\r\n<p>Material: ABS Plastic</p>\r\n\r\n<p>Transmission speed: 300 Мбит/c</p>\r\n\r\n<p>Antennas: 4 PCB</p>\r\n\r\n<p>USB: 2.0</p>\r\n\r\n<p>USB rotation angle: 180&deg;</p>\r\n', NULL, '', '1193', 0, NULL, '', '', 1, 'home', '2020-01-09 10:32:03', '2020-01-09 10:32:03', 0, '', '', '', '', '', '', '', '', '', '', 0),
(151, 'Broadcasting Studio Microphone Mic Stand Adjustable Boom Studio Scissor Arm Mount Shock for Mounting On table (for Blue Yeti Snowball Microphone and Blue Yeti Nano)', 'broadcasting-studio-microphone-mic-stand-adjustable-boom-studio-scissor-arm-mount-shock-for-mounting-on-table-for-blue-yeti-snowball-microphone-and-blue-yeti-nano', 990, 0, '', ' ', '<p>✔ Alloy Aluminum construction; Sturdy and Durable; Load Capacity up to 2.2 pounds/1 kilogram; Sturdy and durable</p>\r\n\r\n<p>✔ Adjust the suitable angle and height to show your perfect voice; Can be mounted on the announcers&#39; table with the Table Mounting Clamp</p>\r\n\r\n<p>✔ Folding type, convenient to carry anywhere; Completely flexible, firmly attach the microphone anywhere</p>\r\n\r\n<p>✔ Suitable for any stores, families, stages, studios, broadcasting and TV stations, etc;</p>\r\n\r\n<h3><strong>Note: Microphone, table, pop filter, cable and microphone clip are not included</strong></h3>\r\n', NULL, '', '1194', 0, NULL, '', '', 1, 'home', '2020-01-12 02:00:40', '2020-01-12 02:00:40', 0, '', '', '', '', '', '', '', '', '', '', 0),
(152, 'Professional Pop Filter For Microphone With Adjustable Arm, Double Mesh Screen Windscreen Studio', 'professional-pop-filter-for-microphone-with-adjustable-arm-double-mesh-screen-windscreen-studio', 1490, 0, '700', ' ', '<p>✔ <strong>Two-screen Pop Filters :</strong> The first screen blocks air blasts ; The gap in between then disperses any remaining air pressure, so by the time it passes the second screen, the blast is easily contained.</p>\r\n\r\n<p>✔ <strong>Adjustable Gooseneck :</strong> The metal gooseneck holder fully supports the filter&#39;s weight and keep it in place. You can adjust the angle and distance between the screen and the microphone.</p>\r\n\r\n<p>✔ <strong>Universal Compability :</strong> Adjustable screw rotating clamp with scratch-proof gripper can secure to MOST tubular mounting booms or mic stands (Maximum diameter: 1.6inches)</p>\r\n\r\n<p>✔ <strong>Easy Mount &amp; Demount :</strong> Swivel mount for easy installation.</p>\r\n\r\n<p><strong>Note : Microphone, Mic Stand and Shock Mount are sold separately, NOT included.</strong></p>\r\n', NULL, '', '1195', 0, NULL, '', '', 1, 'home', '2020-01-12 02:06:52', '2020-01-12 02:06:52', 0, '', '', '', '', '', '', '', '', '', '', 0),
(153, 'BM100 High Performance Condenser Microphone For YouTube Studio Radio Broadcasting Singing Recording With Shock Mount Kit', 'bm100-high-performance-condenser-microphone-for-youtube-studio-radio-broadcasting-singing-recording-with-shock-mount-kit', 2790, 0, '2550', ' ', '<p>Condenser Microphone</p>\r\n\r\n<p>✔ Material: Plastic shell</p>\r\n\r\n<p>✔ Size: diameter 44mm X height 153mm (exclude size of windshield sponge)</p>\r\n\r\n<p>✔ CPU: intelP4 1.6GHz</p>\r\n\r\n<p>✔ Power supply: USB DC5V 1A</p>\r\n\r\n<p>✔ about 3m cable with 3.5mm audio&nbsp;jack &amp;USB connector</p>\r\n\r\n<p>✔ Frequency response: 30Hz=20KHz</p>\r\n\r\n<p>✔ Signal to noise ratio: 70db</p>\r\n\r\n<p>✔ Sound volume: Adjustable</p>\r\n\r\n<p>✔ Sensitivity: 25mv/Pa(-32db+2db)</p>\r\n\r\n<h3><strong>Key Features of BM-100Fx:</strong></h3>\r\n\r\n<p>✔ Echo function:&nbsp;with built-in Reverb chip. Adjust the reverb knob on the microphone to add perfect reverb effect. No need for the sound a card.</p>\r\n\r\n<p>✔ Noise isolation: minimizes&nbsp;background noise&nbsp;and isolates the main sound source</p>\r\n\r\n<p>✔ With professional amplifier chip, adjustable sound volume.</p>\r\n\r\n<p>✔ 3m cable length with 3.5mm audio&nbsp;jack &amp; USB interface</p>\r\n\r\n<p>✔ 3.5mm computer microphone input jack.</p>\r\n\r\n<p>✔ USB interface (DC5V 1A)&nbsp;power supply</p>\r\n\r\n<p>✔ Comes with a desktop stand, and an anti-wind sponge cap</p>\r\n', NULL, '', '1196', 0, NULL, '', '', 1, 'home', '2020-01-12 03:56:49', '2020-01-12 03:56:49', 0, '', '', '', '', '', '', '', '', '', '', 0);
INSERT INTO `product` (`product_id`, `product_title`, `product_name`, `product_price`, `purchase_price`, `discount_price`, `product_summary`, `product_description`, `product_specification`, `product_terms`, `sku`, `product_stock`, `product_of_size`, `product_color`, `product_video`, `status`, `product_type`, `created_time`, `modified_time`, `folder`, `feasured_image`, `galary_image_6`, `galary_image_1`, `galary_image_2`, `galary_image_3`, `galary_image_4`, `galary_image_5`, `seo_title`, `seo_keywords`, `seo_content`, `stock_alert`) VALUES
(154, 'New Vacuum Cleaner Blowing and Sucking Dual Purpose (Jk-8) 8 Multi-functional Portable Vacuum Cleaner', 'new-vacuum-cleaner-blowing-and-sucking-dual-purpose-jk-8-8-multi-functional-portable-vacuum-cleaner', 2200, 0, '', ' ', '<p>✔ Dual purpose JK8 vacuum cleaner (1000W)</p>\r\n\r\n<p>✔ Accessories: Flexible vacuum snout with crevice nozzle, floor kit, small and large brush, shoulder strap</p>\r\n\r\n<p>✔ Conveniently light and compact: 30 X 14 X 23.5 cm</p>\r\n\r\n<p>✔ Permanent vacuum filter</p>\r\n\r\n<p>✔ No exhaust, low noise</p>\r\n\r\n<p>✔ Easy to clean</p>\r\n\r\n<p>✔ Vertical stand (space saving)</p>\r\n', NULL, '<p>\r\n</p><p>আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) এস এ পরিবহন,\r\nজননী, সুন্দরবন ও করোতোয়া কুরিয়ারের\r\nমাধ্যমে ডেলিভারি করে থাকি।<br>\r\n<br>\r\n✔ ঢাকার\r\nমধ্যে হোম ডেলিভারি চার্জ ১০০টাকা, যা পন্য বুঝে\r\nনেয়ার সময় পরিশোধ করতে হবে। </p>\r\n\r\n✔ ঢাকার সিটির বাহিরে ডেলিভারী চার্জ ১৫০ টাকা। এক্ষেত্রে পণ্যের সম্পূর্ণ \r\nমূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি কনফার্ম করতে হবে। অবশিষ্ট মূল্য\r\n কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে। \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br><p></p>', '1197', 0, NULL, '', '', 1, 'home', '2020-01-12 04:04:27', '2020-01-12 04:04:27', 0, '', '', '', '', '', '', '', '', '', '', 0),
(155, '3MP Panoramic WiFi Camera HD VR CAM 360 Degrees - Infrared Night Vision Camera', '3mp-panoramic-wifi-camera-hd-vr-cam-360-degrees---infrared-night-vision-camera', 2500, 0, '', ' ', '', NULL, '', '1200', 0, NULL, '', '', 1, 'home', '2020-01-12 04:08:49', '2020-01-12 04:08:49', 0, '', '', '', '', '', '', '', '', '', '', 0),
(156, 'Hi quality Rechargeable LED Headlight dual light zoom headlamp for cycling bike riding', 'hi-quality-rechargeable-led-headlight-dual-light-zoom-headlamp-for-cycling-bike-riding', 1190, 0, '', ' ', '<p>✔&nbsp; সুপার ব্রাইট LED Headlamp &nbsp;যা ক্যাম্পিং, সাইকেলিং, ক্লাইম্বিং, নাইট ওয়াকিং -এর জন্য আদর্শ</p>\r\n\r\n<p>✔ অন্ধকারে পথ চলতে এটি সহায়ক একটি পণ্য। ধরা যাক আপনি অন্ধকারে পথ চলছেন হাত দুটিতে রয়েছে বাজার বা আপনি সাইকলে চালাচ্ছেন বা বাইক চালাচ্ছেন, হাতে লাইট ধরে রাখার কোন সুযোগ নেই, সেক্ষেপে এটি হবে আপনার জন্য উপকারী একটি জিনিস। কারন এটি মাথাতে লাগাতে হয়, টুপির মত করে।</p>\r\n\r\n<p>✔ মাথার সামনের দিকে মেইন লাইনটি থাকবে আর মাথার পেছনে ছোট একটি লাল কালারের ইন্টকেটর থাকবে যা পিছনের দিকের সিগনালের কাজ করবে। এতে করে অন্ধকারে পথ চলা সহজ হয়ে যাবে।</p>\r\n\r\n<p>✔ এটি rechargeable battery দ্বারা পরিচালিত। এর মধ্যে mah এর দুইটি ব্যাটারী রয়েছে এর মধ্যে যা সহজেই charge করে নিতে পারবেন।</p>\r\n\r\n<p>✔ একবার charge করলে ১০ ঘন্টা জ্বালাতে পারবেন।</p>\r\n\r\n<p>✔ Headlamp টিকে adjust করতে পারবেন 90 degree পর্যন্ত</p>\r\n\r\n<p>✔ এর মাঝে রয়েছে ৪টি লাইট মুড- (১) খুবই ব্রাইট (২) তুলনামূলক কম ব্রাইট (৩) যা সিগলান দেয়ার জন্য ব্যবহার করতে পারবেন (৪) এই মুডটি আপনাকে ঘন কুয়াশার মধ্যে পথ চলতে সাহায্য করবে। কুয়াশার মধ্যেও আপনি সবকিছু ক্লিয়ার দেখতে পারবেন। আরো যে কাজটি এই মুড দ্বারা হবে তা হচ্ছে &ndash; এটি দ্বারা যে কোন সিক্রেট প্রিন্টিং এর watermark দেখতে পারবেন- যেমন জাল টাকা, জাল passport, জাল Licence ইত্যাদি সনাক্ত করতে পারবেন।</p>\r\n\r\n<p>✔ এটির সাথে আছে চার্জার , ব্যাটারি ও মাউন্ট ক্যাবল ।</p>\r\n\r\n<p>✔ ম্যাক্সিমাম আউটপুট: 5000 লুমেন ।</p>\r\n', NULL, '', '1201', 0, NULL, '', '', 1, 'home', '2020-01-12 04:10:39', '2020-01-12 04:10:39', 0, '', '', '', '', '', '', '', '', '', '', 0),
(157, 'Shure SM-959 Professional wired Dynamic Microphone, best for youtube video', 'shure-sm-959-professional-wired-dynamic-microphone-best-for-youtube-video', 950, 0, '', ' ', '', NULL, '', '1203', 0, NULL, '', '', 1, 'general', '2020-01-12 04:13:53', '2020-01-12 04:13:53', 0, '', '', '', '', '', '', '', '', '', '', 0),
(158, 'Google Chromecast Full HD Smart TV Device, Wireless WiFi Display Dongle, Android System Supports Google Chrome, HDMI 1080P Digital TV Receiver Adapter', 'google-chromecast-full-hd-smart-tv-device-wireless-wifi-display-dongle-android-system-supports-google-chrome-hdmi-1080p-digital-tv-receiver-adapter', 1990, 0, '', ' ', '', NULL, '', '1204', 0, NULL, '', '', 1, 'general', '2020-01-12 04:16:02', '2020-01-12 04:16:02', 0, '', '', '', '', '', '', '', '', '', '', 0),
(159, 'Uniross Multi USB Chargeing Station 6.8A built in IC for auto detection to recognize most smartphones, built in voltage stabilizer ', 'uniross-multi-usb-chargeing-station-68a-built-in-ic-for-auto-detection-to-recognize-most-smartphones-built-in-voltage-stabilizer-', 990, 0, '', ' ', '', NULL, '', '1205', 0, NULL, '', '', 1, 'general', '2020-01-12 04:16:52', '2020-01-12 04:16:52', 0, '', '', '', '', '', '', '', '', '', '', 0),
(160, 'ZOOM H1n Crystal Clear Digital Audio voice Recorder, Stereo Microphone for Recording Interview', 'zoom-h1n-crystal-clear-digital-audio-voice-recorder-stereo-microphone-for-recording-interview', 16000, 0, '12000', ' ', '<h2>Zoom H1n Audio Recorder in Bangladesh</h2>\r\n\r\n<p>✔ Streamlined Body with matte finish and newly designed protective mic enclosure</p>\r\n\r\n<p>✔ Built-in stereo condenser microphones in 90-Degree x/Y format</p>\r\n\r\n<p>✔ One-touch button controls.Battery life (alkaline batteries): Approximately 10 hours (continuous recording time using built-in mic, 44.1 kHz/16-bit)</p>\r\n\r\n<p>✔ Localized and intuitive menus for easy operation.Input impedance: 2 k&Omega;</p>\r\n\r\n<p>✔ Playback Speed Control, Voice Emphasize Filter, and Stereo overdubbing functions</p>\r\n', NULL, '', '1206', 0, NULL, '', '', 1, 'home', '2020-01-12 04:21:55', '2020-01-12 04:21:55', 0, '', '', '', '', '', '', '', '', '', '', 0),
(161, 'Zoom H6 portable professional handheld digital recorder 6-Track audio recorder for interview', 'zoom-h6-portable-professional-handheld-digital-recorder-6-track-audio-recorder-for-interview', 36000, 0, '31500', ' ', '<p>✔ Direct recording to SD cards up to 128GB.Display 2.0-Inch full color LCD (320 x 240 pixels)</p>\r\n\r\n<p>✔ Gain knobs, pads, and Phantom power for each input. Maximum sound pressure input: 122 dB SPL</p>\r\n\r\n<p>✔ Newly redesigned preamps with an ultra-low noise floor, up to 24-bit/96kHz audio in WAV or MP3 format</p>\r\n\r\n<p>✔ Mountable directly to DSLR or camcorder with optional hs-01 Hot shoe mount adapter. Multichannel and stereo USB Audio Interface for PC/Mac/iPad</p>\r\n\r\n<p>✔ Includes: Owners manual, xyh-6 x/Y capsule, msh-6 MS capsule, AA size LR6 battery x4, USB cable, sponge windscreen, Cubase LE software, case</p>\r\n', NULL, '', '1207', 0, NULL, '', '', 1, 'home', '2020-01-12 04:27:18', '2020-01-12 04:27:18', 0, '', '', '', '', '', '', '', '', '', '', 0),
(162, 'Zoom H2n Handy Portable Digital Audio Recorder / Stereo microphone for Interview', 'zoom-h2n-handy-portable-digital-audio-recorder--stereo-microphone-for-interview', 1900, 0, '17500', ' ', '<p>✔ Over 20 hours of operation using two standard AA batteries</p>\r\n\r\n<p>✔ Key Control, A-B Repeat, File Dividing, Normalize, MP3 Post-Encode, Marker and Surround Mixer</p>\r\n\r\n<p>✔ Additional functions include Lo-cut Filter, Compressor/Limiter, Auto Gain, Pre-Rec, Auto-Rec, Tuner, Metronome, Variable Speed Playback</p>\r\n\r\n<p>✔ Records in WAV up to 24-bit/96kHz and MP3 up to 320kbps</p>\r\n\r\n<p>✔ File types supported: MAV,MP3</p>\r\n', NULL, '', '1208', 0, NULL, '', '', 1, 'home', '2020-01-12 04:31:11', '2020-01-12 04:31:11', 0, '', '', '', '', '', '', '', '', '', '', 0),
(163, 'DJI Osmo Pocket 3-axis stabilized handheld camera 4K 60fps Video', 'dji-osmo-pocket-3-axis-stabilized-handheld-camera-4k-60fps-video', 35000, 0, '32900', ' ', '<p>✔ <strong>Lightweight and Portable:</strong> It is the smallest 3-axis stabilized handheld camera DJI has ever designed, the compact and intelligent Osmo Pocket turns any moment into a cinematic memory.</p>\r\n\r\n<p>✔ <strong>3-Axis Mechanical Gimbal:</strong> The Osmo Pocket camera is equipped with a remarkable 3-axis stabilized gimbal and a new algorithm that ensures a control accuracy of &plusmn;0.005&deg; and maximum control speed of 120&deg;/s.</p>\r\n\r\n<p>✔ <strong>Amazingly Powerful Performance:</strong> Osmo Pocket take photos in stunning details, thanks to a 1/2.3-inch sensor, 80&deg; FOV, and f/2.0 aperture. It can also shoot 4K/60fps video at 100Mbps and photos at 12 MP with a pixel size of 1.55 &mu;m for footage worth sharing every time.</p>\r\n\r\n<p>✔ <strong>DJI Mimo:</strong> Osmo Pocket is meant for anyone with a story to tell, which is why we developed DJI Mimo. This dedicated app expands your imagination with editing tools and opens the door to a community that inspires your own visual storytelling.</p>\r\n', NULL, '', '1209', 0, NULL, '', '', 1, 'home', '2020-01-12 04:36:52', '2020-01-12 04:36:52', 0, '', '', '', '', '', '', '', '', '', '', 0),
(164, 'Rode VideoMic Camera Mount Shotgun Microphone with Rycote Lyre Shock Mount', 'rode-videomic-camera-mount-shotgun-microphone-with-rycote-lyre-shock-mount', 8500, 0, '7500', ' ', '<p>✔ Compact size and lightweight - only 80mm (3&rsquo;) long and 42gm (1.5oz)</p>\r\n\r\n<p>✔ All-metal microphone body</p>\r\n\r\n<p>✔ No battery required (powered by camera plug-in power - min 3V)</p>\r\n\r\n<p>✔ Rycote Lyre shock mount included</p>\r\n\r\n<p>✔ Deluxe furry windshield included</p>\r\n\r\n<p>✔ Designed and manufactured in Australia</p>\r\n', NULL, '', '1210', 0, NULL, '', '', 1, 'home', '2020-01-12 04:46:51', '2020-01-12 04:46:51', 0, '', '', '', '', '', '', '', '', '', '', 0),
(165, 'Rode VideoMic Pro+ plus Shot gun On-Camera Shotgun Condenser Microphone with Shockmount', 'rode-videomic-pro-plus-shot-gun-on-camera-shotgun-condenser-microphone-with-shockmount', 26000, 0, '24000', ' ', '<p>✔ Still with the best-in-class Rycote Lyre suspension system onboard, the VideoMic Pro+ improves on the existing VideoMic Pro capsule/line tube and windshield, plus boasts a host of new features.</p>\r\n\r\n<p>✔ Automatic Power Function (with plug-in power availability) is perfect for the run-and-gun shooter, automatically turning the microphone off when unplugged from the camera.</p>\r\n\r\n<p>✔ Built-in Battery Door makes replacing the battery a breeze - plus it won&#39;t get lost.</p>\r\n\r\n<p>✔ VideoMic Pro+ can be powered by the all-new and included R&Oslash;DE LB-1 Lithium-Ion Rechargeable Battery, 2 x AA Batteries or continuously via Micro USB.</p>\r\n\r\n<p>✔ Digital Switching - will ensure the user has ultimate capture of the audio signal at the source, reducing post production and editing times.</p>\r\n', NULL, '', '1211', 0, NULL, '', '', 1, 'home', '2020-01-12 04:50:42', '2020-01-12 04:50:42', 0, '', '', '', '', '', '', '', '', '', '', 0),
(166, 'Rode NTG2 Multi-Powered Short Shotgun Condenser Microphone (Battery or Phantom Powered)', 'rode-ntg2-multi-powered-short-shotgun-condenser-microphone-battery-or-phantom-powered', 22000, 0, '19990', ' ', '<p><strong>ENSURE YOU BUY GENUINE R&Oslash;DE PRODUCTS! </strong></p>\r\n\r\n<p>✔&nbsp;Lightweight condenser shotgun microphone, designed for professional applications within the film, video, television and production industries</p>\r\n\r\n<p>✔ Broadcast sound quality; Low noise circuitry; Low handling noise</p>\r\n\r\n<p>✔ Includes mic clip, wind shield and zip case</p>\r\n', NULL, '', '1212', 0, NULL, '', '', 1, 'home', '2020-01-12 04:54:50', '2020-01-12 04:54:50', 0, '', '', '', '', '', '', '', '', '', '', 0),
(167, 'Rode NTG4+ Supercardioid Condenser Shotgun Microphone with Digital Switches', 'rode-ntg4-supercardioid-condenser-shotgun-microphone-with-digital-switches', 25000, 0, '23500', ' ', '<p>✔ A broadcast-quality directional condenser microphone designed for premium audio recording in a versatile range of applications</p>\r\n\r\n<p>✔ The included MicroUSB cable makes charging simple and convenient; the mic can be charged via PC, power-brick or even your car</p>\r\n\r\n<p>✔ Control the in-built high-pass filter, pad and high frequency boost using convenient digital switching on the microphone body</p>\r\n', NULL, '', '1213', 0, NULL, '', '', 1, 'home', '2020-01-12 04:57:34', '2020-01-12 04:57:34', 0, '', '', '', '', '', '', '', '', '', '', 0),
(168, 'Boom Microphone- BOYA BY-HM100 Handheld Dynamic Microphone Xlr Long Handle Aluminum Body mic For Interviews News Gathering Presentation Speech', 'boom-microphone--boya-by-hm100-handheld-dynamic-microphone-xlr-long-handle-aluminum-body-mic-for-interviews-news-gathering-presentation-speech', 6500, 0, '4900', ' ', '<p>✔ Boya Boom Microphone- Handheld dynamic mic with XLR connector,</p>\r\n\r\n<p>✔ NO extra battery needed or phantom power.</p>\r\n\r\n<p>✔ Isolated capsule reduces handling noise and makes the sound more clear.</p>\r\n\r\n<p>✔ Durable aluminum alloy body and extra long handle.</p>\r\n\r\n<p>✔ Ideal for&nbsp;interviews, presentation, etc.</p>\r\n\r\n<p>✔ Comes with a pouch for convenient storage and carry.</p>\r\n\r\n<p>Without XLR Cable</p>\r\n', NULL, '', '1214', 0, NULL, '', '', 1, 'home', '2020-01-12 05:00:36', '2020-01-12 05:00:36', 0, '', '', '', '', '', '', '', '', '', '', 0),
(169, 'BOYA BY-MM1 Microphone For YouTube Vlogging Facebook Livestream Video Recording Mini Mic for DJI Osmo Action/Osmo Pocket/iPhone Huawei Smartphone and DSLR Cameras', 'boya-by-mm1-microphone-for-youtube-vlogging-facebook-livestream-video-recording-mini-mic-for-dji-osmo-actionosmo-pocketiphone-huawei-smartphone-and-dslr-cameras', 2500, 0, '1900', ' ', '<p>✔&nbsp;<strong>Wide Adaptability:</strong> With both TRS cable and TRRS output cable included, it compatible with iPhone, Android smartphones, cameras, camcorders, audio recorders, PCs, and other audio/video recording devices.</p>\r\n\r\n<p>✔ <strong>Strong:</strong> With rugged metal construction, this microphone can last a long time, better than the cheap plastic competitors.</p>\r\n\r\n<p>✔ <strong>Anti-shock:</strong> The included ANTI-SHOCK mount can effectively reduce unwanted vibration, cable and handling noise; thus can give your video a professional sound and can potentially reduce you post-production audio editing work.</p>\r\n\r\n<p>✔ <strong>Plug &amp; Play:</strong> Since there is no battery required in this microphone, you can just plug and play; no need to worry the battery status and complex hookup and paring process.</p>\r\n\r\n<p>✔&nbsp;<strong>BUY WITHOUT WORRY:</strong> Your purchase will be covered by 1 year Manufacture warranty.</p>\r\n', NULL, '', '1215', 0, NULL, '', '', 1, 'home', '2020-01-12 05:04:34', '2020-01-12 05:04:34', 0, '', '', '', '', '', '', '', '', '', '', 0),
(170, 'BOYA BY-WFM12 VHF Wireless Lavalier Microphone System 12 Channel Super-Cardioid for DSLR Camcorder Audio Recorder Tablet PC Smartphone Presentation Interview Filmmaking Real Time Monitor', 'boya-by-wfm12-vhf-wireless-lavalier-microphone-system-12-channel-super-cardioid-for-dslr-camcorder-audio-recorder-tablet-pc-smartphone-presentation-interview-filmmaking-real-time-monitor', 9500, 0, '7900', ' ', '<p>✔ Compatible for Smartphone, Tablet, DSLR, Camcorder, Audio Recorder, PC etc.</p>\r\n\r\n<p>✔ 12 switchable channels to keep you free from interference,High-band VHF operation for superior sound</p>\r\n\r\n<p>✔ Volume control wheel, Detachable and flexible antenna with rotating 360&deg; function</p>\r\n\r\n<p>✔ Operation range up to 40m (131 feet) away without obstacles,Powered by two AA size alkaline batteries for both Receiver and Transmitter</p>\r\n\r\n<p>✔ One Year BOYA Warranty</p>\r\n', NULL, '', '1216', 0, NULL, '', '', 1, 'home', '2020-01-12 05:09:43', '2020-01-12 05:09:43', 0, '', '', '', '', '', '', '', '', '', '', 0),
(173, 'Boya Lavalier Wireless Microphone BY-WM5 Portable Transmitter Set Microphones For DSLR Camera Camcorder Audio Recorder Mic', 'boya-lavalier-wireless-microphone-by-wm5-portable-transmitter-set-microphones-for-dslr-camera-camcorder-audio-recorder-mic', 8000, 0, '6500', ' ', '<p>✔ Original Boya Wireless Microphone</p>\r\n\r\n<p>✔ Excellent sound quality, great portability, easy to setup</p>\r\n\r\n<p>✔ Compatible with DSLR cameras, camcorders, audio recorder, Smart phones etc.</p>\r\n\r\n<p>✔ Approximate 50m(164 ft.) operation range</p>\r\n\r\n<p>✔ Compact, lightweight, high performance, two way communication system</p>\r\n\r\n<p>✔ Experience more freedom of movement while recording</p>\r\n', NULL, '', '1221', 0, NULL, '', '', 1, 'home', '2020-01-12 06:03:31', '2020-01-12 06:03:31', 0, '', '', '', '', '', '', '', '', '', '', 0),
(174, 'Havit M60 Mini Microphone - Black', 'havit-m60-mini-microphone---black', 350, 0, NULL, NULL, '<p>✔ High-quality mic, perfect voice recorder.</p>\r\n\r\n<p>✔ Competable with smartphone, PC, Camera etc</p>\r\n\r\n<p>✔ 3.5mm stereo-track plug</p>\r\n\r\n<p>✔ Frequency response: 20Hz-16KHz.</p>', NULL, NULL, '1222', 0, NULL, '', NULL, 1, 'home', '2020-06-08 04:27:07', '2020-06-08 04:27:07', 0, '', '', '', '', '', '', '', NULL, NULL, NULL, 0),
(175, 'HAVIT HV-M80 Budget Friendly Desk Microphone for PC', 'havit-hv-m80-budget-friendly-desk-microphone-for-pc', 700, 0, '450', ' ', '<p>✔ 80-degree change to the side.</p>\r\n\r\n<p>✔ Frequency response 30Hz-15KHz</p>\r\n\r\n<p>✔ Impedance Sensitivity -58db</p>\r\n\r\n<p>✔ Noise reduct design of the microphone create a clearer voice.</p>\r\n', NULL, '', '1223', 0, NULL, '', '', 1, 'home', '2020-01-12 06:17:07', '2020-01-12 06:17:07', 0, '', '', '', '', '', '', '', '', '', '', 0),
(176, 'Ahuja UTP-30 Lavaliers clip Microphone with long cable (6m) / clip microphone for Interviews and Recordings', 'ahuja-utp-30-lavaliers-clip-microphone-with-long-cable-6m--clip-microphone-for-interviews-and-recordings', 800, 0, '', ' ', '<p>✔ Brand: Ahuja</p>\r\n\r\n<p>✔ Type: Lavaliers</p>\r\n\r\n<p>✔ Purpose: Interviews and Recordings</p>\r\n\r\n<p>✔ Model Name:&nbsp;UTP-30&nbsp;</p>\r\n', NULL, '', '1226', 0, NULL, '', '', 1, 'home', '2020-01-12 06:20:25', '2020-01-12 06:20:25', 0, '', '', '', '', '', '', '', '', '', '', 0),
(177, 'BM800 Microphone- High Performance Condenser Microphone For YouTube Studio, Radio Braodcasting, Singing Recording With Shock Mount Kit', 'bm800-microphone--high-performance-condenser-microphone-for-youtube-studio-radio-braodcasting-singing-recording-with-shock-mount-kit', 4000, 0, '2000', ' ', '<p>✔ The Set Includes: (1)Black Professional Condenser Microphone + (1)Microphone Shock Mount + (1)Ball-type Anti-wind Foam Cap + (1)Microphone&nbsp;Cable.</p>\r\n\r\n<p>✔ This professional condenser microphone adopts the exacting complete electronic circuit control. Capture rich, full-bodied sound from sources that are directly in front of the mic.</p>\r\n\r\n<p>✔ The shock mount can effectively reduce handling noise. Good cardioid pickup output and high sensitivity</p>\r\n\r\n<p>✔ The ball-type anti-wind foam cap can protect microphone against wind interference and singers&#39; spit.</p>\r\n\r\n<h3><strong>Specification:</strong></h3>\r\n\r\n<p>✔ Sensitivity: 45dB&plusmn;1dB</p>\r\n\r\n<p>✔ Electrical current: 3mA</p>\r\n\r\n<p>✔ Polar Pattern: Uni-directional</p>\r\n\r\n<p>✔ Load impedance: &ge;1000 &Omega;</p>\r\n\r\n<p>✔ Equivalent Noise level: 16dBA</p>\r\n\r\n<p>✔ Frequency Response: 20Hz-20kHz</p>\r\n\r\n<p>✔ Output Impedance:1500&Omega;&plusmn;30%(at 1kHz)</p>\r\n\r\n<p>✔ Microphone output interface: 3.5mm</p>\r\n\r\n<h3>✔ <strong>Use of voltage: 48V phantom power supply (Not Included in this package)</strong></h3>\r\n\r\n<p>✔ Wire: 3.5 inserted audio interface, 3 meters long</p>\r\n\r\n<p>✔ Microphone Material: Steel net + Zinc alloy hand holding part</p>\r\n', NULL, '', '1227', 0, NULL, '', '', 1, 'home', '2020-01-12 06:40:26', '2020-01-12 06:40:26', 0, '', '', '', '', '', '', '', '', '', '', 0),
(178, '1 Channel 48V Phantom Power Supply For Condenser Microphone / Low-noise For Audio Condenser Microphone Recording Equipment / 5 feet USB Cable XLR 3Pin Microphone Cable for Any Condenser Microphone', '1-channel-48v-phantom-power-supply-for-condenser-microphone--low-noise-for-audio-condenser-microphone-recording-equipment--5-feet-usb-cable-xlr-3pin-microphone-cable-for-any-condenser-microphone', 3500, 0, '2500', ' ', '<p>✔ Material: Metal housing</p>\r\n\r\n<p>✔ Color: Black</p>\r\n\r\n<p>✔ Size: 100*90*41mm</p>\r\n\r\n<p>✔ Channel: Single Channel</p>\r\n\r\n<p>✔ Input Voltage: 5 Volts</p>\r\n\r\n<p>It delivers reliable 48V phantom power for condenser microphones in a compact, durable, metal housing.&nbsp;</p>\r\n\r\n<p>Enjoy ultra low-noise audio performance and full-frequency response.</p>\r\n\r\n<p>Simple plugin, turn the device on and you are&nbsp;ready to go.</p>\r\n\r\n<h3><strong>Package included:</strong></h3>\r\n\r\n<p>1 x 48V Phantom Power</p>\r\n\r\n<p>1 x USB Cable</p>\r\n', NULL, '', '1228', 0, NULL, '', '', 1, 'home', '2020-01-12 06:43:39', '2020-01-12 06:43:39', 0, '', '', '', '', '', '', '', '', '', '', 0),
(179, 'BOYA BY-VM600 Cardioid Directional Condenser Microphone Mic For DSLR Camera Video camera', 'boya-by-vm600-cardioid-directional-condenser-microphone-mic-for-dslr-camera-video-camera', 4200, 0, '3600', '  ', '<p>✔ Direction shotgun-style microphone</p>\r\n\r\n<p>✔ Well rejecting unwanted background noise&nbsp;</p>\r\n\r\n<p>✔ Premium microphone for clear audio</p>\r\n\r\n<p>✔ The powered design maximizes sound quality</p>\r\n\r\n<p>✔ Built-in shock mount minimizes unwanted&nbsp;vibrations to the microphone&nbsp;</p>\r\n\r\n<p>✔ Acoustic Principle: Line plug gradient</p>\r\n\r\n<p>✔ Frequency Response: 35-18000Hz</p>\r\n\r\n<p>✔ Sensitivity: -38dB+/-1dB / 0dB=1V/Pa</p>\r\n\r\n<p>✔ Signal to Noise Ratio: 78dB</p>\r\n\r\n<p>✔ Power Supply: 1.5V battery</p>\r\n\r\n<p>✔ PAD Switch: 0dB, +10dB</p>\r\n', NULL, '', '1229', 0, NULL, '', '', 1, 'home', '2020-01-18 03:45:53', '2020-01-18 03:45:53', 0, '', '', '', '', '', '', '', '', '', '', 0),
(180, 'BOYA BY-DM1 Professional Lightning Lavalier clip Microphone for iPhone iPad Mini iPad Pro iPad Air 2 iPod', 'boya-by-dm1-professional-lightning-lavalier-clip-microphone-for-iphone-ipad-mini-ipad-pro-ipad-air-2-ipod', 5500, 0, '4950', ' ', '<p>✔ BY-DM1 is new released from BOYA, a professional lapel microphone for iPhone, iPAD, iPOD TOUCH etc</p>\r\n\r\n<p>✔ Captures clear, high-quality sound and directly connects to any iOS device equipment with a Lightning connector</p>\r\n\r\n<p>✔ 6m (20&rsquo;) long cable allows you to comfortably adapt to various situations</p>\r\n\r\n<p>✔ No need of extra lightning cable, just plug and play, easy to use</p>\r\n\r\n<p>✔ Includes Mic Clip, carrying Pouch and wind screen, all-metal construction</p>\r\n\r\n<p>✔ Frequency response: 30Hz-20KHz</p>\r\n\r\n<p>✔ Sensitivity: -42+/-3DB(@1KHz,0db=1v/pa)</p>\r\n\r\n<p>✔ Sampling frequency: 44.1kHz/48KHz</p>\r\n\r\n<p>✔ Power Requirements: Supplied by ios device</p>\r\n\r\n<p>✔ Capsule Diameter: 6.5mm(0.26&quot;)</p>\r\n\r\n<p>✔ Gain: 0-35dB&nbsp; &nbsp; &nbsp;&nbsp;</p>\r\n', NULL, '', '1230', 0, NULL, '', '', 1, 'general', '2020-01-12 06:58:32', '2020-01-12 06:58:32', 0, '', '', '', '', '', '', '', '', '', '', 0),
(181, 'ZOMEI 18 inch Premium Quality LED Ring Light Full Set With Stand And Carry Bag / 50W 5500K Lighting Kit with Color Filter, Hot Shoe Adapter for Lighting for Makeup Camera Smartphone YouTube Video Shooting', 'zomei-18-inch-premium-quality-led-ring-light-full-set-with-stand-and-carry-bag--50w-5500k-lighting-kit-with-color-filter-hot-shoe-adapter-for-lighting-for-makeup-camera-smartphone-youtube-video-shooting', 10000, 0, '6900', ' ', '<h2><strong>Original Zomei Premium Quality LED Ring Light</strong></h2>\r\n\r\n<p>✔ <strong>Enhance facial features under constant lighting;</strong> Make your eyes brighter and draw the others&#39; attention instantly. In most cases, there are shadows on our face when we are taking photos or shooting videos. ZOMEi ring light can provide 360-degree soft light, effectively eliminating shadows, light up your face!</p>\r\n\r\n<p>✔ <strong>Best Partner for YouTubers:</strong>&nbsp;It&#39;s perfect for professional makeup artists, YouTube content creators, professional tattoo artists, video bloggers, hair stylists/salons/colorists. We use the thickest filter to make the light softer. When taking photos or shooting videos, it can eliminate shadows and creates a charming eye!</p>\r\n\r\n<p>✔ <strong>Wide Application and Easy to Carry:</strong> The stand can be 360-degree panning, you can choose any angle as you want. The maximum height of the stand can reach to 78.8 inches. The outer diameter is 18 inches and the inner diameter is 11.8 inches. It can support different equipment such as DSLR cameras, mirrorless cameras, smart phones, make up mirrors, etc. There are two phone holders for you to capture different kinds of video shooting. And you can also take this ring light with the travel bag where</p>\r\n\r\n<p>✔ <strong>Extral Color Filters &amp; Dimming Ring Light:</strong> Color temperature and brightness of this ring light can be adjusted easily. You can adjust the brightness directly by rotating the knob on the back of the light. Install the orange color filter to switch color temperature. The color temperature ranges 3300K- 5500K, the maximum power is 48W and the brightness can reach 4800LM.</p>\r\n\r\n<p>✔ Comes with full Accessories set &amp; Carry case</p>\r\n', NULL, '', '1231', 0, NULL, '', '', 1, 'home', '2020-01-12 07:16:50', '2020-01-12 07:16:50', 0, '', '', '', '', '', '', '', '', '', '', 0),
(185, 'hot product of romjan', 'hot-product-of-romjan', NULL, NULL, '150', '50', '50', NULL, '50', '2020', 50, NULL, NULL, '50', 1, 'general', '2020-05-20 12:27:33', '2020-05-20 12:27:33', 185, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '50', '50', '50', 50),
(186, 'hot product romjan', 'hot-product-romjan', NULL, NULL, '1500', '50', '50', NULL, '50', '2020', 50, NULL, NULL, '50', 1, 'general', '2020-05-20 12:29:28', '2020-05-20 12:29:28', 186, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '50', '50', '50', 50),
(188, 'new', 'new', NULL, NULL, '555', '50', '50', NULL, '50', '555', 555, NULL, NULL, '555', 1, 'general', '2020-05-20 12:36:24', '2020-05-20 12:36:24', 188, '188.03-44-02-07-10-2019-14910507_1085776081536990_58939388760083820_n.jpg', NULL, NULL, NULL, NULL, NULL, NULL, '50', '50', '50', 55),
(189, 'sujon product price', 'sujon-product-price', NULL, NULL, '666', NULL, NULL, NULL, NULL, '555', 555, NULL, NULL, NULL, 1, 'general', '2020-05-20 18:42:26', '2020-05-20 18:42:26', 189, '189.1573378123gf-min-min.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(195, 'new product of sujon new product of sujon new product of sujon new product of sujon new product of sujon', 'new-product-of-sujon', 25, 25, NULL, NULL, NULL, NULL, NULL, '25', NULL, NULL, NULL, NULL, 1, 'general', '2020-06-28 18:23:25', '2020-06-28 18:23:25', 191, '195.25.5.3.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(196, 'ecomerce first product of sujon', 'ecomerce-first-product-of-sujon', 5, 5, '5', NULL, NULL, NULL, NULL, '1', 5, NULL, NULL, NULL, 1, 'general', '2020-05-21 06:35:32', '2020-05-21 06:35:32', 196, '196.537.jpg', NULL, '40.180.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(197, 'product image 2', 'product-image-2', 55, 55, '555', NULL, NULL, NULL, NULL, '55', NULL, NULL, NULL, NULL, 1, 'general', '2020-06-11 13:44:29', '2020-06-11 13:44:29', 197, '197.2-1_b77ada4c.jpg', NULL, '62.2-1_b77ada4c-208x185.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(198, 'new price product', 'new-price-product', 12546, 12254, '541', NULL, NULL, NULL, NULL, '1254', NULL, NULL, NULL, NULL, 1, 'general', '2020-06-12 10:03:03', '2020-06-12 10:03:03', 198, '198.1-273x273.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(199, 'Hot product of banglades', 'hot-product-of-banglades', 1000, 500, '800', 'queick overview', 'none', NULL, 'yes', '123', 50, NULL, NULL, 'hhhh', 1, 'general', '2020-06-11 11:45:13', '2020-06-11 11:45:13', 199, '199.1205.2.jpg', '58.104 copy.jpg', '68.322.jpg', '71.2-1_b77ada4c.jpg', '33.104.jpg', '76.7-273x273.jpg', '57.4-tap-3509.jpg', 'title', 'Meta Keywords', 'Meta description', 20),
(220, 'BM100FX High Performance Condenser Microphone For YouTube Studio, Radio Braodcasting, Singing Recording With Mini Tripod, Pop filter & Studio Microphone Stand', 'bm100fx-high-performance-condenser-microphone-for-youtube-studio-radio-braodcasting-singing-recording-with-mini-tripod-pop-filter--studio-microphone-stand', 3500, 0, '2200', ' ', '<p>✔&nbsp;The BM-100FX microphone has a built-in excellent reverb chip, which truly realizes hardware reverberation. By adjusting the reverb knob on the microphone, you can add the perfect reverb effect for singing</p>\r\n\r\n<p>✔ Professional pre-amplifier chip, which can be controlled by the knob to amplify the volume output of the microphone by 25 times, and the sound of the condenser microphone with integrated sound card is no longer small.</p>\r\n\r\n<p>✔ No driver installation, no tedious debugging, even the inexperienced user can use BM-100FX for fast recording</p>\r\n\r\n<p>✔ USB terminal is used for power supply, without the assistance of 48V phantom power supply equipment such as mixer, speakerphone, etc.</p>\r\n\r\n<p>✔ The audio cable plug is directly designed as a standard 3.5mm computer microphone input interface, without conversion, plug and play, equipped with simple desktop stand and windproof sponge and other accessories, complete supporting, more convenient to use</p>\r\n\r\n<p>✔ Comes with a desktop stand, and an anti-wind sponge cap</p>\r\n', NULL, '', '1218', 0, NULL, '', '', 1, 'home', '2020-01-12 05:33:55', '2020-01-12 05:33:55', 0, '', '', '', '', '', '', '', '', '', '', 0),
(223, 'BOYA BY-BM2021 Cardioid On Camera Shotgun Microphone with 3.5mm TRS TRRS Cable Connector / Microphone for Camcorder Smartphone DSLR ', 'boya-by-bm2021-cardioid-on-camera-shotgun-microphone-with-35mm-trs-trrs-cable-connector--microphone-for-camcorder-smartphone-dslr-', 4000, 0, '3550', ' ', '<p>✔ Compatible to smartphone, DSLR cameras, camcorders, PC etc</p>\r\n\r\n<p>✔ Powered by smartphone, tablets, camera/ no extra battery needed</p>\r\n\r\n<p>✔&nbsp;Reinforced ABS construction, super lightweight</p>\r\n\r\n<p>✔ 3.5mm TRS &amp; TRRS output cable both included</p>\r\n\r\n<p>✔ Foam windshield included</p>\r\n', NULL, '', '1217', 0, NULL, '', '', 1, 'home', '2020-01-12 05:13:08', '2020-01-12 05:13:08', 0, '', '', '', '', '', '', '', '', '', '', 0),
(237, 'hot product romjan', 'hot-product-romjanes', NULL, NULL, '1500', '50', '50', NULL, '50', 'dddd', 50, NULL, NULL, NULL, 1, 'general', '2020-05-20 12:32:46', '2020-05-20 12:32:46', 187, '187.01.png', NULL, NULL, NULL, NULL, NULL, NULL, '50', '50', '50', 50),
(239, 'ehhf product preice', 'ehhf-product-preice', 400, 555, '600', NULL, NULL, NULL, NULL, '521', 5, NULL, NULL, NULL, 1, 'general', '2020-06-11 11:44:46', '2020-06-11 11:44:46', 238, '239.Chrysanthemum.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5),
(240, 'sumon product', 'sumon-product', 444, 44, '44', NULL, NULL, NULL, NULL, '3333', 44, NULL, NULL, NULL, 1, 'general', '2020-06-24 03:58:52', '2020-06-24 03:58:52', 240, '240.1578586554Silicone Gloves Magic Silicone Dish Washing Glove Household Scrubber Rubber Kitchen Cleaning Tool Kitchen Gloves 1191-3.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 44),
(241, 'webp imageproduct', 'webp-imageproduct-', 44, 44, '44', NULL, NULL, NULL, NULL, '44', 12, NULL, NULL, NULL, 1, 'general', '2020-06-24 13:45:49', '2020-06-24 13:45:49', 241, '241.bengal-meat-beef-keema-net-weight-50-gm-1-kg.webp', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 12),
(242, 'web p 2', 'web-p-2', 33, 33, '33', NULL, NULL, NULL, NULL, '333', 44, NULL, NULL, NULL, 1, 'general', '2020-06-24 14:00:44', '2020-06-24 14:00:44', 242, '242.Hydrangeas.webp', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 44),
(252, 'best watch collection', 'best-watch-collection', 33, 333, '33', NULL, NULL, NULL, NULL, '353', 55, NULL, NULL, '55', 1, 'general', '2020-06-28 17:52:34', '2020-06-28 17:52:34', 243, '252.PicsArt_07-28-10.52.37.jpg', NULL, '70.Chrysanthemum.jpg', '15.Hydrangeas.jpg', '40.Jellyfish.jpg', NULL, NULL, NULL, NULL, NULL, 55),
(253, 'hot product of sujon ali', 'hot-product-of-sujon-ali', 3, 3, '3', NULL, NULL, NULL, NULL, '333', 3, NULL, NULL, NULL, 1, 'general', '2020-06-28 17:56:50', '2020-06-28 17:56:50', 253, '253.Hydrangeas.jpg', NULL, '23.Tulips.jpg', '27.Chrysanthemum.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(254, 'sujon product sujon productsujon productsujon productsujon productsujon productsujon productsujon productsujon produc tsujon productsujon productsujon product', 'sujon-product-', 44, 44, '44', NULL, NULL, NULL, NULL, '4', 44, NULL, NULL, NULL, 1, 'general', '2020-06-29 20:51:33', '2020-06-29 20:51:33', 254, '254.1.jpg', '55.pusti-soybean-oil-poly-1-ltr.webp', '12.148695190-104223920-1587807276.jpg', '67.bdee521159bb-1.jpg', '56.Huawei-F3161.jpg', '73.PicsArt_12-04-06.12.31_thumb.jpg', '58.yNTUsICJnIjogMjU1LCAiYiI6IDI1NSwgImFscGh.jpg', NULL, NULL, NULL, 44);

-- --------------------------------------------------------

--
-- Table structure for table `product_category_relation`
--

CREATE TABLE `product_category_relation` (
  `product_category_relation_id` bigint(250) NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `category_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product_category_relation`
--

INSERT INTO `product_category_relation` (`product_category_relation_id`, `product_id`, `category_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 7),
(4, 1, 9),
(5, 2, 1),
(6, 2, 2),
(7, 2, 7),
(8, 2, 9),
(9, 3, 1),
(10, 3, 2),
(11, 3, 7),
(12, 3, 9),
(13, 4, 4),
(14, 4, 7),
(15, 5, 4),
(16, 5, 7),
(17, 6, 1),
(18, 6, 4),
(19, 6, 7),
(20, 7, 4),
(21, 7, 7),
(22, 7, 9),
(23, 8, 4),
(24, 8, 7),
(25, 8, 9),
(26, 8, 11),
(27, 9, 4),
(28, 9, 7),
(29, 9, 9),
(30, 9, 11),
(31, 10, 1),
(32, 11, 1),
(33, 11, 2),
(34, 12, 1),
(35, 12, 3),
(36, 12, 7),
(37, 12, 10),
(38, 13, 1),
(39, 13, 2),
(40, 13, 7),
(41, 13, 11),
(42, 14, 7),
(43, 14, 8),
(44, 14, 10),
(45, 15, 1),
(46, 15, 5),
(47, 15, 7),
(48, 16, 1),
(49, 16, 5),
(50, 16, 7),
(51, 17, 1),
(52, 17, 2),
(53, 17, 7),
(54, 17, 8),
(55, 18, 1),
(56, 18, 2),
(57, 18, 3),
(58, 18, 7),
(59, 19, 1),
(60, 19, 2),
(61, 19, 7),
(62, 19, 9),
(63, 20, 1),
(64, 20, 3),
(65, 20, 7),
(66, 20, 10),
(67, 21, 1),
(68, 21, 3),
(69, 21, 5),
(70, 21, 7),
(71, 21, 10),
(72, 22, 1),
(73, 22, 3),
(74, 22, 7),
(75, 22, 10),
(76, 23, 7),
(77, 23, 9),
(78, 23, 11),
(79, 24, 4),
(80, 24, 7),
(81, 24, 9),
(82, 24, 11),
(83, 25, 4),
(84, 25, 7),
(85, 25, 9),
(86, 25, 11),
(87, 26, 4),
(88, 26, 7),
(89, 26, 9),
(90, 26, 11),
(91, 27, 1),
(92, 27, 3),
(93, 27, 5),
(94, 27, 7),
(95, 28, 1),
(96, 28, 3),
(97, 28, 5),
(98, 28, 7),
(99, 29, 1),
(100, 29, 3),
(101, 29, 5),
(102, 29, 7),
(103, 30, 1),
(104, 30, 2),
(105, 30, 4),
(106, 30, 7),
(107, 30, 11),
(108, 31, 1),
(109, 31, 3),
(110, 31, 5),
(111, 31, 7),
(112, 31, 8),
(113, 32, 1),
(114, 32, 2),
(115, 32, 7),
(116, 33, 1),
(117, 33, 4),
(118, 33, 7),
(119, 33, 11),
(120, 34, 1),
(121, 34, 5),
(122, 34, 7),
(123, 35, 3),
(124, 35, 5),
(125, 35, 7),
(126, 36, 7),
(127, 36, 9),
(128, 36, 11),
(129, 37, 7),
(130, 37, 9),
(131, 37, 11),
(132, 38, 1),
(133, 38, 3),
(134, 38, 7),
(135, 38, 10),
(136, 39, 2),
(137, 39, 4),
(138, 39, 7),
(139, 39, 11),
(140, 40, 7),
(141, 41, 2),
(142, 41, 7),
(143, 41, 11),
(144, 42, 1),
(145, 42, 2),
(146, 42, 7),
(147, 42, 9),
(148, 43, 3),
(149, 43, 7),
(150, 43, 10),
(151, 44, 5),
(152, 44, 7),
(153, 44, 9),
(154, 44, 11),
(155, 45, 1),
(156, 45, 7),
(157, 45, 11),
(158, 46, 7),
(159, 46, 9),
(160, 46, 11),
(161, 47, 7),
(162, 47, 11),
(163, 48, 4),
(164, 48, 7),
(165, 49, 7),
(166, 49, 11),
(167, 50, 2),
(168, 50, 7),
(169, 51, 4),
(170, 51, 7),
(171, 51, 11),
(172, 52, 1),
(173, 52, 7),
(174, 53, 7),
(175, 53, 11),
(176, 54, 1),
(177, 54, 2),
(178, 54, 7),
(179, 55, 1),
(180, 55, 2),
(181, 55, 7),
(182, 56, 2),
(183, 56, 5),
(184, 56, 7),
(185, 57, 1),
(186, 57, 4),
(187, 57, 7),
(188, 57, 11),
(189, 58, 1),
(190, 58, 2),
(191, 58, 7),
(192, 58, 11),
(193, 59, 1),
(194, 59, 4),
(195, 59, 7),
(196, 59, 11),
(197, 60, 1),
(198, 60, 2),
(199, 60, 7),
(200, 60, 11),
(201, 61, 2),
(202, 61, 3),
(203, 61, 7),
(204, 61, 10),
(205, 62, 2),
(206, 62, 7),
(207, 63, 2),
(208, 63, 7),
(209, 63, 8),
(210, 63, 11),
(211, 64, 2),
(212, 64, 4),
(213, 64, 7),
(214, 64, 11),
(215, 65, 1),
(216, 65, 7),
(217, 65, 13),
(218, 66, 1),
(219, 66, 2),
(220, 66, 7),
(221, 66, 13),
(222, 67, 1),
(223, 67, 2),
(224, 67, 4),
(225, 67, 7),
(226, 67, 11),
(227, 68, 4),
(228, 68, 7),
(229, 68, 11),
(230, 68, 12),
(231, 69, 1),
(232, 69, 2),
(233, 69, 4),
(234, 69, 7),
(235, 69, 11),
(236, 70, 1),
(237, 70, 3),
(238, 70, 7),
(239, 70, 10),
(240, 71, 4),
(241, 71, 7),
(242, 71, 11),
(243, 72, 3),
(244, 72, 7),
(245, 73, 3),
(246, 73, 7),
(247, 74, 3),
(248, 74, 7),
(249, 75, 7),
(250, 75, 9),
(251, 75, 11),
(252, 76, 4),
(253, 76, 7),
(254, 76, 11),
(255, 77, 7),
(256, 77, 9),
(257, 77, 11),
(258, 78, 1),
(259, 78, 4),
(260, 78, 7),
(261, 78, 11),
(262, 79, 7),
(263, 79, 9),
(264, 79, 11),
(265, 80, 7),
(266, 80, 11),
(267, 81, 1),
(268, 81, 2),
(269, 81, 7),
(270, 82, 1),
(271, 82, 7),
(272, 83, 1),
(273, 83, 4),
(274, 83, 7),
(275, 83, 11),
(276, 84, 1),
(277, 84, 2),
(278, 84, 7),
(279, 84, 9),
(280, 84, 11),
(281, 85, 1),
(282, 85, 7),
(283, 85, 9),
(284, 85, 11),
(285, 86, 7),
(286, 86, 9),
(287, 86, 11),
(288, 87, 3),
(289, 87, 7),
(290, 87, 10),
(291, 88, 3),
(292, 88, 7),
(293, 89, 3),
(294, 89, 7),
(295, 90, 4),
(296, 90, 7),
(297, 90, 9),
(298, 90, 11),
(299, 91, 1),
(300, 91, 2),
(301, 91, 4),
(302, 91, 7),
(303, 91, 11),
(304, 92, 4),
(305, 92, 5),
(306, 92, 7),
(307, 92, 11),
(308, 93, 1),
(309, 93, 2),
(310, 93, 7),
(311, 93, 11),
(312, 94, 1),
(313, 94, 4),
(314, 94, 7),
(315, 94, 11),
(316, 95, 1),
(317, 95, 4),
(318, 95, 7),
(319, 95, 11),
(320, 96, 1),
(321, 96, 2),
(322, 96, 7),
(323, 96, 11),
(324, 97, 7),
(325, 97, 9),
(326, 97, 11),
(327, 98, 3),
(328, 98, 7),
(329, 98, 10),
(330, 98, 11),
(331, 99, 3),
(332, 99, 7),
(333, 99, 10),
(334, 99, 11),
(335, 100, 3),
(336, 100, 7),
(337, 100, 10),
(338, 100, 11),
(339, 101, 1),
(340, 101, 4),
(341, 101, 7),
(342, 101, 11),
(343, 102, 7),
(344, 102, 9),
(345, 102, 11),
(346, 103, 1),
(347, 103, 2),
(348, 103, 7),
(349, 103, 10),
(350, 103, 11),
(351, 104, 1),
(352, 104, 4),
(353, 104, 7),
(354, 104, 11),
(355, 105, 1),
(356, 105, 4),
(357, 105, 7),
(358, 105, 11),
(359, 106, 4),
(360, 106, 7),
(361, 106, 11),
(362, 107, 4),
(363, 107, 7),
(364, 107, 11),
(365, 108, 4),
(366, 108, 7),
(367, 108, 11),
(368, 109, 4),
(369, 109, 7),
(370, 109, 11),
(371, 110, 4),
(372, 110, 7),
(373, 110, 11),
(374, 111, 1),
(375, 111, 7),
(376, 111, 9),
(377, 111, 11),
(378, 112, 5),
(379, 112, 7),
(380, 112, 11),
(381, 113, 4),
(382, 113, 5),
(383, 113, 7),
(384, 113, 11),
(385, 114, 1),
(386, 114, 4),
(387, 114, 7),
(388, 114, 11),
(389, 115, 7),
(390, 115, 11),
(391, 116, 1),
(392, 116, 2),
(393, 116, 7),
(394, 116, 11),
(395, 117, 1),
(396, 117, 7),
(397, 118, 1),
(398, 118, 7),
(399, 118, 13),
(400, 119, 4),
(401, 119, 7),
(402, 119, 11),
(403, 120, 1),
(404, 120, 4),
(405, 120, 7),
(406, 120, 11),
(407, 121, 1),
(408, 121, 4),
(409, 121, 7),
(410, 121, 11),
(411, 122, 1),
(412, 122, 4),
(413, 122, 7),
(414, 122, 11),
(415, 123, 1),
(416, 123, 4),
(417, 123, 7),
(418, 123, 11),
(419, 124, 5),
(420, 124, 7),
(421, 125, 1),
(422, 125, 2),
(423, 125, 3),
(424, 125, 7),
(425, 125, 10),
(426, 125, 11),
(427, 126, 7),
(428, 126, 11),
(429, 127, 1),
(430, 127, 2),
(431, 127, 5),
(432, 127, 7),
(433, 127, 8),
(434, 128, 3),
(435, 128, 7),
(436, 128, 10),
(437, 129, 3),
(438, 129, 7),
(439, 129, 10),
(440, 130, 3),
(441, 130, 7),
(442, 130, 10),
(443, 131, 3),
(444, 131, 7),
(445, 131, 10),
(446, 132, 3),
(447, 132, 7),
(448, 132, 10),
(449, 132, 11),
(450, 133, 3),
(451, 133, 7),
(452, 133, 10),
(453, 133, 11),
(454, 134, 1),
(455, 134, 7),
(456, 134, 11),
(457, 135, 7),
(458, 135, 9),
(459, 135, 11),
(460, 136, 3),
(461, 136, 7),
(462, 136, 10),
(463, 136, 11),
(464, 137, 3),
(465, 137, 7),
(466, 137, 10),
(467, 137, 11),
(468, 138, 3),
(469, 138, 5),
(470, 138, 7),
(471, 138, 10),
(472, 138, 11),
(473, 139, 4),
(474, 139, 7),
(475, 139, 11),
(476, 140, 1),
(477, 140, 4),
(478, 140, 7),
(479, 140, 11),
(480, 141, 1),
(481, 141, 2),
(482, 141, 7),
(483, 142, 1),
(484, 142, 2),
(485, 142, 5),
(486, 142, 7),
(487, 143, 1),
(488, 143, 2),
(489, 143, 7),
(490, 144, 1),
(491, 144, 2),
(492, 144, 7),
(493, 145, 1),
(494, 145, 2),
(495, 145, 7),
(496, 146, 7),
(497, 146, 13),
(498, 147, 1),
(499, 147, 2),
(500, 147, 7),
(501, 148, 1),
(502, 148, 7),
(503, 148, 11),
(504, 149, 4),
(505, 149, 7),
(506, 149, 11),
(507, 150, 1),
(508, 150, 2),
(509, 150, 7),
(510, 151, 1),
(511, 151, 13),
(512, 152, 1),
(513, 152, 13),
(514, 153, 1),
(515, 153, 2),
(516, 153, 13),
(517, 154, 1),
(518, 154, 7),
(519, 154, 11),
(520, 155, 1),
(521, 155, 2),
(522, 155, 7),
(523, 155, 12),
(524, 156, 1),
(525, 156, 7),
(526, 156, 11),
(527, 156, 12),
(528, 157, 1),
(529, 157, 7),
(530, 157, 13),
(531, 158, 1),
(532, 158, 2),
(533, 158, 7),
(534, 158, 11),
(535, 159, 1),
(536, 159, 7),
(537, 159, 11),
(538, 160, 1),
(539, 160, 7),
(540, 160, 13),
(541, 161, 1),
(542, 161, 7),
(543, 161, 13),
(544, 162, 1),
(545, 162, 7),
(546, 162, 13),
(547, 163, 1),
(548, 163, 2),
(549, 163, 7),
(550, 163, 13),
(551, 164, 1),
(552, 164, 7),
(553, 164, 13),
(554, 165, 1),
(555, 165, 7),
(556, 165, 13),
(557, 166, 1),
(558, 166, 7),
(559, 166, 13),
(560, 167, 1),
(561, 167, 7),
(562, 167, 13),
(563, 168, 1),
(564, 168, 7),
(565, 168, 13),
(566, 169, 1),
(567, 169, 7),
(568, 169, 13),
(569, 170, 1),
(570, 170, 7),
(571, 170, 13),
(572, 171, 1),
(573, 171, 7),
(574, 171, 13),
(575, 172, 1),
(576, 172, 7),
(577, 172, 13),
(578, 173, 1),
(579, 173, 7),
(580, 173, 13),
(581, 174, 1),
(582, 174, 7),
(583, 174, 13),
(584, 175, 1),
(585, 175, 7),
(586, 175, 13),
(587, 176, 1),
(588, 176, 7),
(589, 176, 13),
(590, 177, 1),
(591, 177, 7),
(592, 177, 13),
(593, 178, 1),
(594, 178, 7),
(595, 178, 13),
(596, 179, 1),
(597, 179, 7),
(598, 179, 13),
(599, 179, 14),
(600, 180, 1),
(601, 180, 7),
(602, 180, 13),
(603, 181, 1),
(604, 181, 7),
(605, 181, 13),
(606, 182, 1),
(607, 182, 2),
(608, 182, 7),
(609, 182, 11),
(610, 193, 1),
(613, 193, 2),
(611, 193, 14),
(612, 193, 21),
(614, 193, 22),
(615, 193, 23),
(616, 193, 24),
(617, 194, 1),
(618, 194, 14),
(619, 194, 21),
(687, 195, 65),
(623, 196, 1),
(624, 196, 14),
(674, 197, 65),
(676, 198, 65),
(673, 199, 65),
(672, 239, 65),
(677, 240, 65),
(678, 241, 58),
(679, 241, 65),
(680, 242, 65),
(681, 252, 65),
(682, 253, 65),
(688, 254, 65);

-- --------------------------------------------------------

--
-- Table structure for table `product_color`
--

CREATE TABLE `product_color` (
  `product_color_id` int(11) NOT NULL,
  `product_color_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product_color`
--

INSERT INTO `product_color` (`product_color_id`, `product_color_name`) VALUES
(1, 'Black'),
(2, 'Red'),
(3, 'Blue'),
(4, 'White');

-- --------------------------------------------------------

--
-- Table structure for table `product_size`
--

CREATE TABLE `product_size` (
  `product_size_id` int(25) NOT NULL,
  `name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product_size`
--

INSERT INTO `product_size` (`product_size_id`, `name`) VALUES
(1, '38'),
(2, '39'),
(3, '40'),
(4, '45');

-- --------------------------------------------------------

--
-- Table structure for table `product_specification`
--

CREATE TABLE `product_specification` (
  `specification_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT '0',
  `key` varchar(556) DEFAULT NULL,
  `value` varchar(556) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product_specification`
--

INSERT INTO `product_specification` (`specification_id`, `product_id`, `key`, `value`) VALUES
(1, 1, '', ''),
(2, 2, '', ''),
(3, 3, '', ''),
(4, 4, '', ''),
(5, 5, '', ''),
(6, 6, '', ''),
(7, 7, '', ''),
(8, 8, '', ''),
(9, 9, '', ''),
(11, 10, '', ''),
(12, 11, '', ''),
(14, 12, '', ''),
(15, 13, '', ''),
(17, 15, '', ''),
(18, 16, '', ''),
(19, 17, '', ''),
(20, 18, '', ''),
(22, 20, '', ''),
(23, 21, '', ''),
(24, 22, '', ''),
(25, 23, '', ''),
(26, 24, '', ''),
(27, 25, '', ''),
(28, 26, '', ''),
(29, 27, '', ''),
(30, 28, '', ''),
(31, 29, '', ''),
(32, 30, '', ''),
(33, 31, '', ''),
(34, 32, '', ''),
(35, 33, '', ''),
(36, 34, '', ''),
(37, 35, '', ''),
(38, 36, '', ''),
(39, 37, '', ''),
(40, 38, '', ''),
(41, 39, '', ''),
(42, 40, '', ''),
(43, 41, '', ''),
(44, 42, '', ''),
(45, 43, '', ''),
(46, 44, '', ''),
(47, 45, '', ''),
(48, 46, '', ''),
(49, 47, '', ''),
(50, 48, '', ''),
(51, 49, '', ''),
(52, 50, '', ''),
(53, 51, '', ''),
(54, 52, '', ''),
(55, 19, '', ''),
(56, 53, '', ''),
(57, 54, '', ''),
(58, 55, '', ''),
(59, 56, '', ''),
(60, 57, '', ''),
(61, 58, '', ''),
(62, 59, '', ''),
(63, 60, '', ''),
(64, 61, '', ''),
(65, 62, '', ''),
(67, 64, '', ''),
(68, 65, '', ''),
(69, 66, '', ''),
(70, 67, '', ''),
(71, 68, '', ''),
(72, 69, '', ''),
(73, 70, '', ''),
(74, 71, '', ''),
(75, 72, '', ''),
(76, 73, '', ''),
(77, 74, '', ''),
(78, 75, '', ''),
(79, 76, '', ''),
(80, 77, '', ''),
(81, 78, '', ''),
(82, 79, '', ''),
(83, 80, '', ''),
(84, 81, '', ''),
(85, 82, '', ''),
(86, 83, '', ''),
(87, 84, '', ''),
(88, 85, '', ''),
(89, 86, '', ''),
(90, 87, '', ''),
(91, 88, '', ''),
(92, 89, '', ''),
(93, 90, '', ''),
(94, 91, '', ''),
(95, 92, '', ''),
(96, 93, '', ''),
(97, 94, '', ''),
(98, 95, '', ''),
(99, 96, '', ''),
(100, 97, '', ''),
(101, 98, '', ''),
(102, 99, '', ''),
(103, 100, '', ''),
(104, 101, '', ''),
(105, 102, '', ''),
(106, 103, '', ''),
(108, 104, '', ''),
(109, 105, '', ''),
(110, 106, '', ''),
(111, 107, '', ''),
(112, 108, '', ''),
(113, 109, '', ''),
(114, 110, '', ''),
(115, 111, '', ''),
(116, 112, '', ''),
(117, 113, '', ''),
(118, 114, '', ''),
(119, 115, '', ''),
(120, 116, '', ''),
(121, 117, '', ''),
(122, 118, '', ''),
(123, 119, '', ''),
(124, 120, '', ''),
(125, 121, '', ''),
(126, 122, '', ''),
(127, 123, '', ''),
(128, 124, '', ''),
(129, 125, '', ''),
(130, 126, '', ''),
(132, 128, '', ''),
(133, 129, '', ''),
(134, 130, '', ''),
(135, 131, '', ''),
(136, 132, '', ''),
(137, 133, '', ''),
(138, 134, '', ''),
(139, 135, '', ''),
(140, 136, '', ''),
(141, 63, '', ''),
(142, 14, '', ''),
(143, 127, '', ''),
(144, 137, '', ''),
(145, 138, '', ''),
(146, 139, '', ''),
(147, 140, '', ''),
(148, 141, '', ''),
(149, 142, '', ''),
(150, 143, '', ''),
(151, 144, '', ''),
(152, 145, '', ''),
(153, 146, '', ''),
(154, 147, '', ''),
(155, 148, '', ''),
(156, 149, '', ''),
(157, 150, '', ''),
(158, 151, '', ''),
(159, 152, '', ''),
(160, 153, '', ''),
(161, 154, '', ''),
(162, 155, '', ''),
(163, 156, '', ''),
(164, 157, '', ''),
(165, 158, '', ''),
(166, 159, '', ''),
(167, 160, '', ''),
(168, 161, '', ''),
(169, 162, '', ''),
(170, 163, '', ''),
(171, 164, '', ''),
(172, 165, '', ''),
(173, 166, '', ''),
(174, 167, '', ''),
(175, 168, '', ''),
(176, 169, '', ''),
(177, 170, '', ''),
(178, 171, '', ''),
(179, 172, '', ''),
(180, 173, '', ''),
(181, 174, '', ''),
(182, 175, '', ''),
(183, 176, '', ''),
(184, 177, '', ''),
(185, 178, '', ''),
(187, 180, '', ''),
(188, 181, '', ''),
(189, 182, '', ''),
(190, 179, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `publicusers`
--

CREATE TABLE `publicusers` (
  `user_id` int(11) NOT NULL,
  `user_f_name` varchar(250) NOT NULL,
  `user_email` varchar(250) NOT NULL,
  `user_password` varchar(250) NOT NULL,
  `user_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 active 0 inactive',
  `user_mobile` varchar(250) NOT NULL,
  `user_address` varchar(250) NOT NULL,
  `user_l_name` varchar(250) NOT NULL,
  `affiliate_user` tinyint(4) NOT NULL,
  `created_date` varchar(255) NOT NULL,
  `affiliate_request_status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `publicusers`
--

INSERT INTO `publicusers` (`user_id`, `user_f_name`, `user_email`, `user_password`, `user_status`, `user_mobile`, `user_address`, `user_l_name`, `affiliate_user`, `created_date`, `affiliate_request_status`) VALUES
(39, 'sujon ali', 'admin@isolutionsbd.coms', '1', 1, '01738305670', '', '', 0, '2019-10-26 06:38 :01', 2),
(40, 'mitul ali', 'suzonice15@gmail.com', '1!@', 1, '01738305679', '', '', 0, '2019-11-10 08:26 :56', 0),
(41, 'Abdullah', 'ashrafabdullah@gmail.com', '2222222222kk', 1, '01975381009', '', '', 0, '2019-11-11 07:33 :42', 0),
(42, 'Ahsan Ullah', 'info@ekusheyshop.com', 'amisumon', 1, '01976266670', '', '', 0, '2019-11-12 11:13 :38', 0),
(43, 'Sumon', '', 'amisumon', 1, '01976266670', '', '', 0, '2019-11-12 11:21 :33', 0),
(49, 'ekusheyTeam', '  info@ekusheyshop.com', 'Ekushey123', 1, ' 01613955597', '', '', 0, '2019-11-14 09:12 :10', 0),
(50, 'Shihab Uddain', 'info@alom.com  ', '123456789', 1, ' 01708515811', 'Uttar Mohanpur , Bengali , Ullahpara Sirajganj', '', 0, '2019-11-14 12:44 :23', 0),
(51, 'cc', '', '123456788', 1, '01738305677', '', '', 0, '2019-11-16 07:21 :28', 0),
(52, 'summon', 'sdsafy@fjxdy .bb', '333333', 1, '01234521031', '', '', 0, '2019-11-18 04:25 :39', 0);

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `review_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(55) DEFAULT NULL,
  `comment` text,
  `rating` varchar(5) DEFAULT '1',
  `review_active` int(11) NOT NULL DEFAULT '0',
  `created_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`review_id`, `product_id`, `name`, `email`, `comment`, `rating`, `review_active`, `created_time`) VALUES
(1, 84, 'sujon', 'suzonice15@gmail.com', 'good', '5', 0, NULL),
(2, 84, 'mitul', 'fjjfjf@fmao.com', 'ok		', '3', 1, '2019-09-20 05:40:29'),
(3, 169, 'suzon', 'suzonice15@gmail.com', 'ttt', '5', 1, '2019-09-19 14:14:06'),
(4, 169, 'suzon', 'suzonice15@gmail.com', 'hh				', '5', 1, '2019-09-20 05:40:22'),
(5, 169, 'suzon', 'suzonice15@gmail.com', 'ok', '3', 1, '2019-09-19 14:17:05'),
(8, 180, 'sumon', 'suzonice15@gmail.com', 'ddd', '5', 0, '2019-09-20 09:42:36'),
(9, 167, 'mitul', 'suzonice1@gmal.com', 'hhh', '5', 0, '2019-09-20 16:28:07'),
(10, 169, 'raihan', 'mitul@gmail.com', 'ddd', '5', 1, '2019-09-20 16:30:26'),
(11, 169, 'abu', 'abu@gmail.com', 'ok\n', '5', 1, '2019-09-20 16:34:44'),
(12, 178, 'suzon', 'suzonice15@gmail.com', 'ok', '5', 1, '2019-09-22 09:57:49'),
(13, 178, 'mitul', 'suzonice15@gmail.com', 'nice		2e', '5', 1, '2019-10-10 02:13:18'),
(14, 167, 'Full HD 1080P স্পোর্টস অ্যাকশন ওয়াটারপ্রুফ ক্যামেরা 12MP - Black', 'anisurrups@gmail.com', 'kk		', '5', 1, '2019-11-18 05:24:57'),
(15, 186, 'Asia', 'anisur134@gmail.com', 'ok', '5', 1, '2019-10-17 13:45:07');

-- --------------------------------------------------------

--
-- Table structure for table `stock_product`
--

CREATE TABLE `stock_product` (
  `stock_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `stock_status` varchar(55) NOT NULL,
  `stock_qty` varchar(11) NOT NULL,
  `created_time` datetime NOT NULL,
  `modified_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tryorder`
--

CREATE TABLE `tryorder` (
  `tryorder_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `product_size` varchar(25) CHARACTER SET utf8 NOT NULL,
  `product_color` varchar(25) CHARACTER SET utf8 NOT NULL,
  `product_qnt` int(11) NOT NULL,
  `product_price` float NOT NULL,
  `product_image` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tryorder`
--

INSERT INTO `tryorder` (`tryorder_id`, `order_id`, `product_name`, `product_size`, `product_color`, `product_qnt`, `product_price`, `product_image`) VALUES
(273, 281, ' Arctic এয়ার কুলার আলট্রা', '', '', 1, 2500, 'http://localhost/sopnershop/uploads/20-24-04-05-09-2019-Ultra-New-Arctic-Air-Cooler_thumb.jpg'),
(274, 282, ' Arctic এয়ার কুলার আলট্রা', '', '', 1, 2500, 'http://localhost/sopnershop/uploads/20-24-04-05-09-2019-Ultra-New-Arctic-Air-Cooler_thumb.jpg'),
(272, 280, ' Arctic এয়ার কুলার আলট্রা', '', '', 1, 2500, 'http://localhost/sopnershop/uploads/20-24-04-05-09-2019-Ultra-New-Arctic-Air-Cooler_thumb.jpg'),
(271, 278, 'জাতীয় সংসদ ভবন রেপ্লিকা ভাস্কর্য', '', '', 1, 790, 'http://localhost/sopnershop/uploads/54-35-06-17-10-2019-assembly_thumb.jpg'),
(270, 275, 'WiFi IP Security Camera wireless CCTV Camera for home and office security', '', '', 1, 1990, 'http://localhost/sopnershop/uploads/1571830915wifi-ip-security-camera-wireless-cctv-camera-for-home-and-office-security 1001-7_thumb.jpg'),
(268, 271, 'Oma Fitness 1916 CAM ', '', '', 1, 100, 'http://localhost/sopnershop/uploads/10-26-06-17-10-2019-oma-fit_thumb.jpg'),
(269, 273, 'Liqua Gold Leaf ', '', '', 1, 190, 'http://localhost/sopnershop/uploads/12-56-05-17-10-2019-Liqua-Gold-Leaf_thumb.jpg'),
(267, 271, 'WiFi IP Security Camera wireless CCTV Camera for home and office security', '', '', 1, 1990, 'http://localhost/sopnershop/uploads/1571830915wifi-ip-security-camera-wireless-cctv-camera-for-home-and-office-security 1001-7_thumb.jpg'),
(266, 271, 'KONIYCOI KT-2100MV', '', '', 2, 2250, 'http://localhost/sopnershop/uploads/29-50-06-17-10-2019-head_thumb.jpg'),
(264, 271, 'Liqua Gold Leaf ', '', '', 1, 190, 'http://localhost/sopnershop/uploads/12-56-05-17-10-2019-Liqua-Gold-Leaf_thumb.jpg'),
(265, 271, 'জাতীয় সংসদ ভবন রেপ্লিকা ভাস্কর্য', '', '', 1, 100, 'http://localhost/sopnershop/uploads/54-35-06-17-10-2019-assembly_thumb.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `usermeta`
--

CREATE TABLE `usermeta` (
  `user_meta_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `meta_key` varchar(255) NOT NULL,
  `meta_value` longtext CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `category1`
--
ALTER TABLE `category1`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `courier`
--
ALTER TABLE `courier`
  ADD PRIMARY KEY (`courier_id`);

--
-- Indexes for table `homeslider`
--
ALTER TABLE `homeslider`
  ADD PRIMARY KEY (`homeslider_id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`media_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`newsletter_id`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`option_id`);

--
-- Indexes for table `order_data`
--
ALTER TABLE `order_data`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_category_relation`
--
ALTER TABLE `product_category_relation`
  ADD PRIMARY KEY (`product_category_relation_id`),
  ADD KEY `product_id` (`product_id`,`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=225;

--
-- AUTO_INCREMENT for table `category1`
--
ALTER TABLE `category1`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `courier`
--
ALTER TABLE `courier`
  MODIFY `courier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `homeslider`
--
ALTER TABLE `homeslider`
  MODIFY `homeslider_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `media_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=602;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `newsletter`
--
ALTER TABLE `newsletter`
  MODIFY `newsletter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `order_data`
--
ALTER TABLE `order_data`
  MODIFY `order_id` bigint(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=309;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=255;

--
-- AUTO_INCREMENT for table `product_category_relation`
--
ALTER TABLE `product_category_relation`
  MODIFY `product_category_relation_id` bigint(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=689;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
